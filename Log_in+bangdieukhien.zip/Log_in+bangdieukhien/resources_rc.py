# Resource object code (Python 3)
# Created by: object code
# Created by: The Resource Compiler for Qt version 6.10.2
# WARNING! All changes made in this file will be lost!

from PySide6 import QtCore

qt_resource_data = b"\
\x00\x00\x01\x94\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2224\
\x22 height=\x2224\x22 vi\
ewBox=\x220 0 24 24\
\x22 fill=\x22none\x22 st\
roke=\x22currentCol\
or\x22 stroke-width\
=\x222\x22 stroke-line\
cap=\x22round\x22 stro\
ke-linejoin=\x22rou\
nd\x22 class=\x22feath\
er feather-grid\x22\
><rect x=\x223\x22 y=\x22\
3\x22 width=\x227\x22 hei\
ght=\x227\x22></rect><\
rect x=\x2214\x22 y=\x223\
\x22 width=\x227\x22 heig\
ht=\x227\x22></rect><r\
ect x=\x2214\x22 y=\x2214\
\x22 width=\x227\x22 heig\
ht=\x227\x22></rect><r\
ect x=\x223\x22 y=\x2214\x22\
 width=\x227\x22 heigh\
t=\x227\x22></rect></s\
vg>\
\x00\x00\x01t\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2224\
\x22 height=\x2224\x22 vi\
ewBox=\x220 0 24 24\
\x22 fill=\x22none\x22 st\
roke=\x22currentCol\
or\x22 stroke-width\
=\x222\x22 stroke-line\
cap=\x22round\x22 stro\
ke-linejoin=\x22rou\
nd\x22 class=\x22feath\
er feather-shopp\
ing-bag\x22><path d\
=\x22M6 2L3 6v14a2 \
2 0 0 0 2 2h14a2\
 2 0 0 0 2-2V6l-\
3-4z\x22></path><li\
ne x1=\x223\x22 y1=\x226\x22\
 x2=\x2221\x22 y2=\x226\x22>\
</line><path d=\x22\
M16 10a4 4 0 0 1\
-8 0\x22></path></s\
vg>\
\x00\x00\x01\x86\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2224\
\x22 height=\x2224\x22 vi\
ewBox=\x220 0 24 24\
\x22 fill=\x22none\x22 st\
roke=\x22Blue\x22 stro\
ke-width=\x222\x22 str\
oke-linecap=\x22rou\
nd\x22 stroke-linej\
oin=\x22round\x22 clas\
s=\x22feather feath\
er-align-center\x22\
><line x1=\x2218\x22 y\
1=\x2210\x22 x2=\x226\x22 y2\
=\x2210\x22></line><li\
ne x1=\x2221\x22 y1=\x226\
\x22 x2=\x223\x22 y2=\x226\x22>\
</line><line x1=\
\x2221\x22 y1=\x2214\x22 x2=\
\x223\x22 y2=\x2214\x22></li\
ne><line x1=\x2218\x22\
 y1=\x2218\x22 x2=\x226\x22 \
y2=\x2218\x22></line><\
/svg>\
\x00\x00\x03\xf3\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2224\
\x22 height=\x2224\x22 vi\
ewBox=\x220 0 24 24\
\x22 fill=\x22none\x22 st\
roke=\x22currentCol\
or\x22 stroke-width\
=\x222\x22 stroke-line\
cap=\x22round\x22 stro\
ke-linejoin=\x22rou\
nd\x22 class=\x22feath\
er feather-setti\
ngs\x22><circle cx=\
\x2212\x22 cy=\x2212\x22 r=\x22\
3\x22></circle><pat\
h d=\x22M19.4 15a1.\
65 1.65 0 0 0 .3\
3 1.82l.06.06a2 \
2 0 0 1 0 2.83 2\
 2 0 0 1-2.83 0l\
-.06-.06a1.65 1.\
65 0 0 0-1.82-.3\
3 1.65 1.65 0 0 \
0-1 1.51V21a2 2 \
0 0 1-2 2 2 2 0 \
0 1-2-2v-.09A1.6\
5 1.65 0 0 0 9 1\
9.4a1.65 1.65 0 \
0 0-1.82.33l-.06\
.06a2 2 0 0 1-2.\
83 0 2 2 0 0 1 0\
-2.83l.06-.06a1.\
65 1.65 0 0 0 .3\
3-1.82 1.65 1.65\
 0 0 0-1.51-1H3a\
2 2 0 0 1-2-2 2 \
2 0 0 1 2-2h.09A\
1.65 1.65 0 0 0 \
4.6 9a1.65 1.65 \
0 0 0-.33-1.82l-\
.06-.06a2 2 0 0 \
1 0-2.83 2 2 0 0\
 1 2.83 0l.06.06\
a1.65 1.65 0 0 0\
 1.82.33H9a1.65 \
1.65 0 0 0 1-1.5\
1V3a2 2 0 0 1 2-\
2 2 2 0 0 1 2 2v\
.09a1.65 1.65 0 \
0 0 1 1.51 1.65 \
1.65 0 0 0 1.82-\
.33l.06-.06a2 2 \
0 0 1 2.83 0 2 2\
 0 0 1 0 2.83l-.\
06.06a1.65 1.65 \
0 0 0-.33 1.82V9\
a1.65 1.65 0 0 0\
 1.51 1H21a2 2 0\
 0 1 2 2 2 2 0 0\
 1-2 2h-.09a1.65\
 1.65 0 0 0-1.51\
 1z\x22></path></sv\
g>\
\x00\x00\x01o\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2224\
\x22 height=\x2224\x22 vi\
ewBox=\x220 0 24 24\
\x22 fill=\x22none\x22 st\
roke=\x22currentCol\
or\x22 stroke-width\
=\x222\x22 stroke-line\
cap=\x22round\x22 stro\
ke-linejoin=\x22rou\
nd\x22 class=\x22feath\
er feather-log-o\
ut\x22><path d=\x22M9 \
21H5a2 2 0 0 1-2\
-2V5a2 2 0 0 1 2\
-2h4\x22></path><po\
lyline points=\x221\
6 17 21 12 16 7\x22\
></polyline><lin\
e x1=\x2221\x22 y1=\x2212\
\x22 x2=\x229\x22 y2=\x2212\x22\
></line></svg>\
\x00\x00\x01<\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2224\
\x22 height=\x2224\x22 vi\
ewBox=\x220 0 24 24\
\x22 fill=\x22none\x22 st\
roke=\x22currentCol\
or\x22 stroke-width\
=\x222\x22 stroke-line\
cap=\x22round\x22 stro\
ke-linejoin=\x22rou\
nd\x22 class=\x22feath\
er feather-eye\x22>\
<path d=\x22M1 12s4\
-8 11-8 11 8 11 \
8-4 8-11 8-11-8-\
11-8z\x22></path><c\
ircle cx=\x2212\x22 cy\
=\x2212\x22 r=\x223\x22></ci\
rcle></svg>\
\x00\x00\x06\xd5\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 fill=\x22non\
e\x22 viewBox=\x220 0 \
24 24\x22 height=\x222\
4\x22 width=\x2224\x22>\x0a \
 <g id=\x22School\x22>\
\x0a    <path id=\x22U\
nion\x22 fill=\x22#000\
000\x22 d=\x22M11.6309\
 4.0703c0.2765 -\
0.10983 0.5904 -\
0.09095 0.8545 0\
.05566l8.9736 4.\
98536 0.9883 0.4\
9414 0.1211 0.07\
128c0.2679 0.184\
92 0.4316 0.4918\
6 0.4316 0.82326\
V17h-2v-5.8574l-\
2 1.1113V17c0 0.\
1552 -0.0361 0.3\
084 -0.1055 0.44\
73L18 17c0.8328 \
0.4164 0.8899 0.\
4457 0.8936 0.44\
82l-0.002 0.0039\
c-0.0008 0.0017 \
-0.0019 0.0039 -\
0.0029 0.0059 -0\
.0022 0.0042 -0.\
0049 0.0091 -0.0\
078 0.0146 -0.00\
6 0.0115 -0.0132\
 0.0261 -0.0225 \
0.043 -0.0186 0.\
0339 -0.0446 0.0\
782 -0.0772 0.13\
18 -0.0651 0.107\
4 -0.1594 0.2521\
 -0.2861 0.4209 \
-0.2531 0.3375 -\
0.6379 0.7772 -1\
.1826 1.2129C16.\
2105 20.1629 14.\
4929 21 12 21c-2\
.49292 0 -4.2104\
7 -0.8371 -5.312\
5 -1.7188 -0.544\
65 -0.4357 -0.92\
95 -0.8754 -1.18\
262 -1.2129 -0.1\
2665 -0.1688 -0.\
22094 -0.3135 -0\
.28613 -0.4209 -\
0.03257 -0.0536 \
-0.05852 -0.0979\
 -0.07715 -0.131\
8 -0.0093 -0.016\
9 -0.01646 -0.03\
15 -0.02246 -0.0\
43 -0.00292 -0.0\
055 -0.00566 -0.\
0104 -0.00781 -0\
.0146 -0.00102 -\
0.002 -0.00208 -\
0.0042 -0.00293 \
-0.0059l-0.00195\
 -0.0029c0.00369\
 -0.0025 0.06072\
 -0.0328 0.89355\
 -0.4492l-0.8945\
3 0.4473C5.03606\
 17.3084 5 17.15\
52 5 17v-4.7461L\
2.51465 10.874C2\
.1972 10.6976 2 \
10.3631 2 10c0.0\
0002 -0.36314 0.\
1972 -0.69767 0.\
51465 -0.87403l8\
.99995 -5.00001z\
m0.8545 11.8037c\
-0.2641 0.1466 -\
0.578 0.1655 -0.\
8545 0.0557l-0.1\
163 -0.0557L7 13\
.3652v3.3506c0.0\
2943 0.0438 0.06\
216 0.0969 0.104\
49 0.1533 0.1687\
6 0.225 0.44029 \
0.5355 0.83301 0\
.8496C8.71047 18\
.3371 9.99292 19\
 12 19c2.0071 0 \
3.2895 -0.6629 4\
.0625 -1.2813 0.\
3927 -0.3141 0.6\
642 -0.6246 0.83\
3 -0.8496 0.0423\
 -0.0564 0.0751 \
-0.1095 0.1045 -\
0.1533v-3.3506zM\
5.05859 10 12 13\
.8555 18.9414 10\
 12 6.14354z\x22 st\
roke-width=\x221\x22><\
/path>\x0a  </g>\x0a</\
svg>\
\x00\x00\x01\x90\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2224\
\x22 height=\x2224\x22 vi\
ewBox=\x220 0 24 24\
\x22 fill=\x22none\x22 st\
roke=\x22currentCol\
or\x22 stroke-width\
=\x222\x22 stroke-line\
cap=\x22round\x22 stro\
ke-linejoin=\x22rou\
nd\x22 class=\x22feath\
er feather-users\
\x22><path d=\x22M17 2\
1v-2a4 4 0 0 0-4\
-4H5a4 4 0 0 0-4\
 4v2\x22></path><ci\
rcle cx=\x229\x22 cy=\x22\
7\x22 r=\x224\x22></circl\
e><path d=\x22M23 2\
1v-2a4 4 0 0 0-3\
-3.87\x22></path><p\
ath d=\x22M16 3.13a\
4 4 0 0 1 0 7.75\
\x22></path></svg>\
\x00\x00\x01\x8f\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2224\
\x22 height=\x2224\x22 vi\
ewBox=\x220 0 24 24\
\x22 fill=\x22none\x22 st\
roke=\x22currentCol\
or\x22 stroke-width\
=\x222\x22 stroke-line\
cap=\x22round\x22 stro\
ke-linejoin=\x22rou\
nd\x22 class=\x22feath\
er feather-align\
-justify\x22><line \
x1=\x2221\x22 y1=\x2210\x22 \
x2=\x223\x22 y2=\x2210\x22><\
/line><line x1=\x22\
21\x22 y1=\x226\x22 x2=\x223\
\x22 y2=\x226\x22></line>\
<line x1=\x2221\x22 y1\
=\x2214\x22 x2=\x223\x22 y2=\
\x2214\x22></line><lin\
e x1=\x2221\x22 y1=\x2218\
\x22 x2=\x223\x22 y2=\x2218\x22\
></line></svg>\
\x00\x00\x019\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2224\
\x22 height=\x2224\x22 vi\
ewBox=\x220 0 24 24\
\x22 fill=\x22none\x22 st\
roke=\x22currentCol\
or\x22 stroke-width\
=\x222\x22 stroke-line\
cap=\x22round\x22 stro\
ke-linejoin=\x22rou\
nd\x22 class=\x22feath\
er feather-user\x22\
><path d=\x22M20 21\
v-2a4 4 0 0 0-4-\
4H8a4 4 0 0 0-4 \
4v2\x22></path><cir\
cle cx=\x2212\x22 cy=\x22\
7\x22 r=\x224\x22></circl\
e></svg>\
\x00\x00\x02n\
\x89\
PNG\x0d\x0a\x1a\x0a\x00\x00\x00\x0dIHDR\x00\
\x00\x000\x00\x00\x000\x08\x06\x00\x00\x00W\x02\xf9\x87\
\x00\x00\x025IDATx\x01\xd5\xc1\xb1k\xa3u\
\x18\x00\xe0\xc7\xf72\x14\xae\x1c\xa2K\x86\x0c\xceG\x87\
\x82\x87\x93\x83\xd0\x8e\x07\x1e\xb4\x90\xa1\xdf\x10qs\xd2\
E\x5c\xfc\x0b\x04\x97CD\xf4 \xc27Xhw9\
Z\xc1I\x17\xa1KQ\x1c%C\xc6\x1b2\x14\x09\xe2\
A;\xd4~o\xd2$G\xf3\xfd|\x9e\xd7\xb0\x89/\
0p\xe9;|\x82\xa9\xf9\x9e\xe0)z\xf8\x15\x1f\xe0\
\x0f\xf3u\xf1-\x1ec\x84\xcf1\xf4\x0a\xee\xe1K|\
\x84\x0e:x\x07\xf7\xf1\xdcl\x8fp\x8a\x07.\xf5\xf0\
\x18\xdf`j\xb6_\xf0\xaeK\x0f\xf0\x04\xbf\xe1O+\
\x0a|\xa8\xe9\xc0|\x95\xa6\xb7\xf0\x9e\xd9\x1eaK\xd3\
\xc7^A`CS\xd7|\xaf\xcbu-o\x07=+\
\x0a\xebs\x86\xb1\x5ceEa}\xa68\x94;\xb0\xa2\
\xb0^C\xb9-l[AX\xaf3\x9c\xcb\x0d\xac \
\xac_-\xd7G\xc7\x92\xc2\xfa\xd5r]\xecZRX\
\xbf\x11N\xe5*K\x0a\xed\xa8\xe5\xf6\xb0i\x09\xa1\x1d\
G\xb8\xd0\xb4\x81}K\x08\xed\x98\xe0X\xae\xb2\x84\xd0\
\x9eZn\x07=\x0b\x0a\xed9\xc1X\xae\xb2\xa0\xd0\x9e\
)\x0e\xe5\x0e,(\xb4k(\xb7\x85m\x0b\x08\xed:\
\xc3\xb9\xdc\xc0\x02B\xfbj\xb9>:n\x11\xdaW\xcb\
u\xb1\xeb\x16\xa1}#\x9c\xcaUn\x11\xcaP\xcb\xed\
a\xd3\x1c\xa1\x0cG\xb8\xd0\xb4\x81}s\x842Lp\
,W\x99#\x94\xa3\x96\xdbA\xcf\x0c\xa1\x1c'\x18\xcb\
Uf\x08\xe5\x98\xe2P\xee\xc0\x0c\xa1,C\xb9-l\
K\x84\xb2\x9c\xe1\x5cn \x11\xcaS\xcb\xf5\xd1qC\
(O-\xd7\xc5\xae\x1bByF8\x95\xab\xdc\x10\xca\
T\xcb\xeda\xd35\xa1LG\xb8\xd0\xb4\x81}\xd7\x84\
2Mp,W\xb9&\x94\xab\x96\xdbA\xcf\x95P\xae\
\x13\x8c\xe5*WB\xb9\xa68\x94;p%\x94m(\
\xb7\x85m/\x85\xb2\x9d\xe1\x5cn\xe0\xa5P\xbeZ\xae\
\x8fN(_-\xd7\xc5n(\xdf\x08\xa7rU\xf8\x7f\
\xa8\xe5\xde\x0fL4\xbd0\xdfD\xee\x85\xbbq\x84\x0b\
M\xd3\xc0\xf7\x9a\x9e\x99\xef\x07L\xfd\xd7\x08?\xba\x1b\
\x13|\xa5\xe9\xd9=<\xc7\x9bx\x88\xbf\xf15>\xc5\
?f\xfb\x0b\xbf\xe3m\xbc\x81\x9f\xd1\xc7\xd8\xdd\xf9\x09\
\xf7\xf1\x10S<\xc5g\xff\x02\xb3bkVQ\xd0\xa8\
\xcd\x00\x00\x00\x00IEND\xaeB`\x82\
\x00\x00\x014\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2224\
\x22 height=\x2224\x22 vi\
ewBox=\x220 0 24 24\
\x22 fill=\x22none\x22 st\
roke=\x22currentCol\
or\x22 stroke-width\
=\x222\x22 stroke-line\
cap=\x22round\x22 stro\
ke-linejoin=\x22rou\
nd\x22 class=\x22feath\
er feather-searc\
h\x22><circle cx=\x221\
1\x22 cy=\x2211\x22 r=\x228\x22\
></circle><line \
x1=\x2221\x22 y1=\x2221\x22 \
x2=\x2216.65\x22 y2=\x221\
6.65\x22></line></s\
vg>\
\x00\x00\x01\x99\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2224\
\x22 height=\x2224\x22 vi\
ewBox=\x220 0 24 24\
\x22 fill=\x22none\x22 st\
roke=\x22currentCol\
or\x22 stroke-width\
=\x222\x22 stroke-line\
cap=\x22round\x22 stro\
ke-linejoin=\x22rou\
nd\x22 class=\x22feath\
er feather-globe\
\x22><circle cx=\x2212\
\x22 cy=\x2212\x22 r=\x2210\x22\
></circle><line \
x1=\x222\x22 y1=\x2212\x22 x\
2=\x2222\x22 y2=\x2212\x22><\
/line><path d=\x22M\
12 2a15.3 15.3 0\
 0 1 4 10 15.3 1\
5.3 0 0 1-4 10 1\
5.3 15.3 0 0 1-4\
-10 15.3 15.3 0 \
0 1 4-10z\x22></pat\
h></svg>\
\x00\x00\x01S\
<\
svg xmlns=\x22http:\
//www.w3.org/200\
0/svg\x22 width=\x2224\
\x22 height=\x2224\x22 vi\
ewBox=\x220 0 24 24\
\x22 fill=\x22none\x22 st\
roke=\x22currentCol\
or\x22 stroke-width\
=\x222\x22 stroke-line\
cap=\x22round\x22 stro\
ke-linejoin=\x22rou\
nd\x22 class=\x22feath\
er feather-book-\
open\x22><path d=\x22M\
2 3h6a4 4 0 0 1 \
4 4v14a3 3 0 0 0\
-3-3H2z\x22></path>\
<path d=\x22M22 3h-\
6a4 4 0 0 0-4 4v\
14a3 3 0 0 1 3-3\
h7z\x22></path></sv\
g>\
"

qt_resource_name = b"\
\x00\x05\
\x00o\xa6S\
\x00i\
\x00c\x00o\x00n\x00s\
\x00\x08\
\x08\xf7W\x07\
\x00g\
\x00r\x00i\x00d\x00.\x00s\x00v\x00g\
\x00\x10\
\x06\xc0\xab'\
\x00s\
\x00h\x00o\x00p\x00p\x00i\x00n\x00g\x00-\x00b\x00a\x00g\x00.\x00s\x00v\x00g\
\x00\x10\
\x06\xf8\x19\x87\
\x00a\
\x00l\x00i\x00g\x00n\x00-\x00c\x00e\x00n\x00t\x00e\x00r\x00.\x00s\x00v\x00g\
\x00\x0c\
\x0b\xdf,\xc7\
\x00s\
\x00e\x00t\x00t\x00i\x00n\x00g\x00s\x00.\x00s\x00v\x00g\
\x00\x0b\
\x06!\xeeG\
\x00l\
\x00o\x00g\x00-\x00o\x00u\x00t\x00.\x00s\x00v\x00g\
\x00\x07\
\x0c\xf8Z\x07\
\x00e\
\x00y\x00e\x00.\x00s\x00v\x00g\
\x008\
\x06=\xb9G\
\x00S\
\x00c\x00h\x00o\x00o\x00l\x00-\x00-\x00S\x00t\x00r\x00e\x00a\x00m\x00l\x00i\x00n\
\x00e\x00-\x00O\x00u\x00t\x00l\x00i\x00n\x00e\x00d\x00-\x00S\x00t\x00r\x00e\x00a\
\x00m\x00l\x00i\x00n\x00e\x00-\x00M\x00a\x00t\x00e\x00r\x00i\x00a\x00l\x00-\x00F\
\x00r\x00e\x00e\x00.\x00s\x00v\x00g\
\x00\x09\
\x0c\x96\xa3\xe7\
\x00u\
\x00s\x00e\x00r\x00s\x00.\x00s\x00v\x00g\
\x00\x11\
\x0b\xfbp\x07\
\x00a\
\x00l\x00i\x00g\x00n\x00-\x00j\x00u\x00s\x00t\x00i\x00f\x00y\x00.\x00s\x00v\x00g\
\
\x00\x08\
\x09\xc5UG\
\x00u\
\x00s\x00e\x00r\x00.\x00s\x00v\x00g\
\x00#\
\x04\xc0sG\
\x00M\
\x00e\x00d\x00i\x00a\x00-\x00L\x00i\x00b\x00r\x00a\x00r\x00y\x00-\x00-\x00S\x00t\
\x00r\x00e\x00a\x00m\x00l\x00i\x00n\x00e\x00-\x00M\x00i\x00c\x00r\x00o\x00.\x00p\
\x00n\x00g\
\x00\x0a\
\x08\x94m\xc7\
\x00s\
\x00e\x00a\x00r\x00c\x00h\x00.\x00s\x00v\x00g\
\x00\x09\
\x05\x88\x86\xa7\
\x00g\
\x00l\x00o\x00b\x00e\x00.\x00s\x00v\x00g\
\x00\x0d\
\x04\x8a\x93\xa7\
\x00b\
\x00o\x00o\x00k\x00-\x00o\x00p\x00e\x00n\x00.\x00s\x00v\x00g\
"

qt_resource_struct = b"\
\x00\x00\x00\x00\x00\x02\x00\x00\x00\x01\x00\x00\x00\x01\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00\x00\x00\x02\x00\x00\x00\x01\x00\x00\x00\x02\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x00\x00\x00\x02\x00\x00\x00\x0e\x00\x00\x00\x03\
\x00\x00\x00\x00\x00\x00\x00\x00\
\x00\x00\x02\x0a\x00\x00\x00\x00\x00\x01\x00\x00\x1b\xc8\
\x00\x00\x01\x9cW\xe4i\xf3\
\x00\x00\x01\x8c\x00\x00\x00\x00\x00\x01\x00\x00\x16\x81\
\x00\x00\x01\x9cX@\xf6\xee\
\x00\x00\x01\xf2\x00\x00\x00\x00\x00\x01\x00\x00\x1a+\
\x00\x00\x01\x9cW\xe5\xbf\xa3\
\x00\x00\x00\x90\x00\x00\x00\x00\x00\x01\x00\x00\x08\x91\
\x00\x00\x01\x9cX\x09\xfbE\
\x00\x00\x00\xc0\x00\x00\x00\x00\x00\x01\x00\x00\x0bD\
\x00\x00\x01\x9cW\xef\x83\xda\
\x00\x00\x00&\x00\x00\x00\x00\x00\x01\x00\x00\x01\x98\
\x00\x00\x01\x9cW\xe5\x85\xec\
\x00\x00\x00L\x00\x00\x00\x00\x00\x01\x00\x00\x03\x10\
\x00\x00\x01\x9cWjf\xfc\
\x00\x00\x01\xd8\x00\x00\x00\x00\x00\x01\x00\x00\x18\xf3\
\x00\x00\x01\x9cW\xe6,l\
\x00\x00\x00\x10\x00\x00\x00\x00\x00\x01\x00\x00\x00\x00\
\x00\x00\x01\x9cW\xe42\x9a\
\x00\x00\x01v\x00\x00\x00\x00\x00\x01\x00\x00\x15D\
\x00\x00\x01\x9cW\xe6\xcd\xf8\
\x00\x00\x00r\x00\x00\x00\x00\x00\x01\x00\x00\x04\x9a\
\x00\x00\x01\x9cX\x09\xea}\
\x00\x00\x01N\x00\x00\x00\x00\x00\x01\x00\x00\x13\xb1\
\x00\x00\x01\x9cW\xe3,m\
\x00\x00\x016\x00\x00\x00\x00\x00\x01\x00\x00\x12\x1d\
\x00\x00\x01\x9cW\xe6\xd3\xc4\
\x00\x00\x00\xac\x00\x00\x00\x00\x00\x01\x00\x00\x0a\x04\
\x00\x00\x01\x9cW\xe4\xd1\xa9\
"

def qInitResources():
    QtCore.qRegisterResourceData(0x03, qt_resource_struct, qt_resource_name, qt_resource_data)

def qCleanupResources():
    QtCore.qUnregisterResourceData(0x03, qt_resource_struct, qt_resource_name, qt_resource_data)

qInitResources()
