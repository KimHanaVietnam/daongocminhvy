import sys
import json

from PySide6.QtWidgets import (
    QApplication,
    QWidget,
    QMessageBox,
    QTableWidgetItem,
    QAbstractItemView,
    QVBoxLayout
)
from PySide6.QtGui import QColor

from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure

from index import Ui_Form


class App(QWidget):
    def __init__(self):
        super().__init__()

        self.ui = Ui_Form()
        self.ui.setupUi(self)

        # ================= LOGIN =================
        self.ui.stackedWidget.setCurrentIndex(0)
        self.ui.nhap_mk.setEchoMode(self.ui.nhap_mk.EchoMode.Password)
        self.ui.log_in.clicked.connect(self.handle_login)

        # ================= TABLE =================
        self.setup_table()

        # ================= SEARCH =================
        self.ui.lineEdit.textChanged.connect(self.search_table)

        # ================= SIDEBAR =================
        self.ui.pushButton_2.clicked.connect(lambda: self.ui.stackedWidget_2.setCurrentIndex(0))
        self.ui.pushButton_7.clicked.connect(lambda: self.ui.stackedWidget_2.setCurrentIndex(1))
        self.ui.pushButton_9.clicked.connect(lambda: self.ui.stackedWidget_2.setCurrentIndex(2))
        self.ui.pushButton_8.clicked.connect(lambda: self.ui.stackedWidget_2.setCurrentIndex(3))
        self.ui.pushButton_10.clicked.connect(lambda: self.ui.stackedWidget_2.setCurrentIndex(4))

        # ================= CHART =================
        self.init_charts()

    # =====================================================
    # TABLE
    # =====================================================

    def setup_table(self):
        table = self.ui.transferTable

        table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        table.setSelectionBehavior(QAbstractItemView.SelectRows)

        table.setStyleSheet("""
        QTableWidget {
            background-color: #F5F5F5;
            color: black;
            gridline-color: #CCCCCC;
            font-size: 14px;
        }

        QHeaderView::section {
            background-color: black;
            color: white;
            font-weight: bold;
            padding: 5px;
        }
        """)

    # =====================================================
    # LOGIN
    # =====================================================

    def handle_login(self):
        email = self.ui.nhap_tk.text().strip()
        password = self.ui.nhap_mk.text().strip()

        try:
            with open("data/users.json", "r", encoding="utf-8") as f:
                data = json.load(f)

            for user in data.get("users", []):
                if user.get("email") == email and user.get("password") == password:
                    self.ui.label_9.setText(f"Hello, {user.get('name', '')}")
                    self.ui.stackedWidget.setCurrentIndex(1)
                    self.refresh_dashboard()
                    return

            QMessageBox.warning(self, "Lỗi", "Sai tài khoản hoặc mật khẩu")

        except Exception as e:
            QMessageBox.critical(self, "Lỗi", str(e))

    # =====================================================
    # LOAD TABLE
    # =====================================================

    def load_table(self):
        with open("data/borrow_record.json", "r", encoding="utf-8") as f:
            data = json.load(f)

        records = data.get("borrow_record", [])
        table = self.ui.transferTable
        table.setRowCount(len(records))

        keys = ["id", "student_id", "book_id",
                "borrow_date", "due_date", "status"]

        for row, record in enumerate(records):
            for col, key in enumerate(keys):
                value = record.get(key, "")
                item = QTableWidgetItem(str(value))

                if key == "status":
                    if value == "borrowing":
                        item.setBackground(QColor("#FFD166"))
                    elif value == "overdue":
                        item.setBackground(QColor("#EF476F"))
                        item.setForeground(QColor("white"))
                    elif value == "returned":
                        item.setBackground(QColor("#06D6A0"))

                table.setItem(row, col, item)

    # =====================================================
    # SEARCH
    # =====================================================

    def search_table(self, text):
        text = text.lower()
        table = self.ui.transferTable

        for row in range(table.rowCount()):
            match = False
            for col in range(table.columnCount()):
                item = table.item(row, col)
                if item and text in item.text().lower():
                    match = True
            table.setRowHidden(row, not match)

    # =====================================================
    # DASHBOARD
    # =====================================================

    def refresh_dashboard(self):
        self.load_table()

        with open("data/borrow_record.json", "r", encoding="utf-8") as f:
            data = json.load(f)

        records = data.get("borrow_record", [])

        borrowing = sum(1 for r in records if r.get("status") == "borrowing")
        overdue = sum(1 for r in records if r.get("status") == "overdue")
        returned = sum(1 for r in records if r.get("status") == "returned")

        # Cập nhật card
        self.ui.label_51.setText(f"Borrowing : {borrowing}")
        self.ui.label_53.setText(f"Overdue : {overdue}")
        self.ui.label_55.setText(f"Already returned : {returned}")

        # Cập nhật chart
        self.update_charts(borrowing, overdue, returned)

    # =====================================================
    # CHART
    # =====================================================

    def init_charts(self):
        # Bar chart
        self.bar_fig = Figure(figsize=(4, 3))
        self.bar_canvas = FigureCanvas(self.bar_fig)
        layout1 = QVBoxLayout(self.ui.ch_left_2)
        layout1.addWidget(self.bar_canvas)

        # Line chart
        self.line_fig = Figure(figsize=(4, 3))
        self.line_canvas = FigureCanvas(self.line_fig)
        layout2 = QVBoxLayout(self.ui.ch_right_2)
        layout2.addWidget(self.line_canvas)

    def update_charts(self, borrowing, overdue, returned):
        categories = ["Borrowing", "Overdue", "Returned"]
        values = [borrowing, overdue, returned]

        # ===== Bar chart =====
        self.bar_fig.clear()
        ax1 = self.bar_fig.add_subplot(111)
        ax1.bar(categories, values)
        ax1.set_title("Borrow Status")
        self.bar_canvas.draw()

        # ===== Line chart =====
        self.line_fig.clear()
        ax2 = self.line_fig.add_subplot(111)
        ax2.plot(categories, values, marker="o")
        ax2.set_title("Borrow Trend")
        self.line_canvas.draw()


# =====================================================
# RUN
# =====================================================

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = App()
    window.show()
    sys.exit(app.exec())
