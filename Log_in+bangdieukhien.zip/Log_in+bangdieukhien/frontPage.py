import sys
import json
from PySide6.QtWidgets import (
    QApplication, QMainWindow,
    QMessageBox, QTableWidgetItem, QVBoxLayout
)
from PySide6.QtGui import QColor
from PySide6.QtCore import QTimer

from index import Ui_Form

from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure


class App(QMainWindow):
    def __init__(self):
        super().__init__()

        self.ui = Ui_Form()
        self.ui.setupUi(self)

        self.setWindowTitle("UEL Library")

        # ===== LƯU USER ĐĂNG NHẬP =====
        self.current_user = None

        # ================= LOGIN =================
        self.ui.stackedWidget.setCurrentIndex(0)
        self.ui.nhap_mk.setEchoMode(self.ui.nhap_mk.EchoMode.Password)
        self.ui.log_in.clicked.connect(self.handle_login)

        # ================= SIDEBAR =================
        self.ui.pushButton_2.clicked.connect(lambda: self.ui.stackedWidget_2.setCurrentIndex(0))
        self.ui.pushButton_7.clicked.connect(lambda: self.ui.stackedWidget_2.setCurrentIndex(1))
        self.ui.pushButton_9.clicked.connect(lambda: self.ui.stackedWidget_2.setCurrentIndex(2))
        self.ui.pushButton_8.clicked.connect(lambda: self.ui.stackedWidget_2.setCurrentIndex(3))
        self.ui.pushButton_10.clicked.connect(lambda: self.ui.stackedWidget_2.setCurrentIndex(4))

        # ================= SEARCH =================
        self.ui.lineEdit.textChanged.connect(self.search_table)

        # ================= AUTO REFRESH =================
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.refresh_dashboard)
        self.timer.start(3000)

    # ================= LOGIN =================

    def handle_login(self):
        email = self.ui.nhap_tk.text().strip()
        password = self.ui.nhap_mk.text().strip()

        try:
            with open("data/users.json", "r", encoding="utf-8") as f:
                users = json.load(f)["users"]
        except Exception:
            QMessageBox.critical(self, "Lỗi", "Không đọc được file users.json")
            return

        for user in users:
            if user["email"] == email and user["password"] == password:
                self.current_user = user
                self.ui.stackedWidget.setCurrentIndex(1)
                self.update_welcome_label()
                self.refresh_dashboard()
                return

        QMessageBox.warning(self, "Lỗi", "Sai tài khoản hoặc mật khẩu")

    # ================= HELLO USER =================

    def update_welcome_label(self):
        if not self.current_user:
            return

        # Tự động hỗ trợ nhiều key name khác nhau
        name = (
            self.current_user.get("name")
            or self.current_user.get("fullname")
            or self.current_user.get("username")
            or ""
        )

        self.ui.label_9.setText(f"Hello {name}")

    # ================= DASHBOARD =================

    def load_dashboard_cards(self):
        try:
            with open("data/books.json", "r", encoding="utf-8") as f:
                books = json.load(f)["books"]

            with open("data/students.json", "r", encoding="utf-8") as f:
                students = json.load(f)["students"]

            with open("data/borrow_record.json", "r", encoding="utf-8") as f:
                records = json.load(f)["borrow_record"]
        except Exception:
            return

        total_books = len(books)
        total_students = len(students)
        borrowing = sum(1 for r in records if r["status"] == "borrowing")
        overdue = sum(1 for r in records if r["status"] == "overdue")

        # ===== MAP ĐÚNG UI index.py =====
        self.ui.label_12.setText(str(total_books))
        self.ui.label_50.setText(str(total_students))
        self.ui.label_49.setText(str(borrowing))
        self.ui.label_48.setText(str(overdue))

    # ================= TABLE =================

    def load_transfer_data(self):
        try:
            with open("data/borrow_record.json", "r", encoding="utf-8") as f:
                records = json.load(f)["borrow_record"]
        except Exception:
            return

        headers = ["id", "student_id", "book_id",
                   "borrow_date", "due_date", "status"]

        self.ui.transferTable.setColumnCount(len(headers))
        self.ui.transferTable.setHorizontalHeaderLabels(headers)
        self.ui.transferTable.setRowCount(len(records))

        for row, record in enumerate(records):
            for col, key in enumerate(headers):
                item = QTableWidgetItem(str(record.get(key, "")))

                if key == "status":
                    status = record.get(key)
                    if status == "overdue":
                        item.setBackground(QColor(255, 150, 150))
                    elif status == "returned":
                        item.setBackground(QColor(150, 255, 150))
                    else:
                        item.setBackground(QColor(255, 255, 180))

                self.ui.transferTable.setItem(row, col, item)

        self.ui.transferTable.resizeColumnsToContents()

    # ================= SEARCH =================

    def search_table(self, text):
        for row in range(self.ui.transferTable.rowCount()):
            match = False
            for col in range(self.ui.transferTable.columnCount()):
                item = self.ui.transferTable.item(row, col)
                if item and text.lower() in item.text().lower():
                    match = True
                    break
            self.ui.transferTable.setRowHidden(row, not match)

    # ================= CHART =================

    def init_chart_layout(self):
        self.bar_layout = self.ui.ch_left_2.layout()
        self.line_layout = self.ui.ch_right_2.layout()

        if self.bar_layout is None:
            self.bar_layout = QVBoxLayout(self.ui.ch_left_2)

        if self.line_layout is None:
            self.line_layout = QVBoxLayout(self.ui.ch_right_2)

    def clear_layout(self, layout):
        while layout.count():
            child = layout.takeAt(0)
            if child.widget():
                child.widget().deleteLater()

    # ================= BAR CHART =================

    def draw_bar_chart(self):
        self.clear_layout(self.bar_layout)

        with open("data/borrow_record.json", "r", encoding="utf-8") as f:
            records = json.load(f)["borrow_record"]

        days = ["T2", "T3", "T4", "T5", "T6", "T7", "CN"]
        borrow = [0] * 7
        returned = [0] * 7

        for r in records:
            try:
                day_index = int(r["borrow_date"].split("-")[-1]) % 7
            except Exception:
                continue

            if r["status"] == "borrowing":
                borrow[day_index] += 1
            elif r["status"] == "returned":
                returned[day_index] += 1

        fig = Figure(figsize=(4, 3))
        canvas = FigureCanvas(fig)
        ax = fig.add_subplot(111)

        x = range(len(days))
        ax.bar(x, borrow, width=0.4, label="Mượn")
        ax.bar([i + 0.4 for i in x], returned, width=0.4, label="Trả")

        ax.set_xticks([i + 0.2 for i in x])
        ax.set_xticklabels(days)
        ax.set_title("Thống kê Mượn / Trả")
        ax.legend()

        fig.tight_layout()
        self.bar_layout.addWidget(canvas)

    # ================= LINE CHART =================

    def draw_line_chart(self):
        self.clear_layout(self.line_layout)

        with open("data/borrow_record.json", "r", encoding="utf-8") as f:
            records = json.load(f)["borrow_record"]

        days = ["T2", "T3", "T4", "T5", "T6", "T7", "CN"]
        visits = [0] * 7

        for r in records:
            try:
                day_index = int(r["borrow_date"].split("-")[-1]) % 7
            except Exception:
                continue

            visits[day_index] += 1

        fig = Figure(figsize=(4, 3))
        canvas = FigureCanvas(fig)
        ax = fig.add_subplot(111)

        ax.plot(days, visits, marker="o")
        ax.set_title("Lượt truy cập hệ thống")

        fig.tight_layout()
        self.line_layout.addWidget(canvas)

    # ================= REFRESH =================

    def refresh_dashboard(self):
        if self.ui.stackedWidget.currentIndex() != 1:
            return

        self.load_dashboard_cards()
        self.load_transfer_data()
        self.init_chart_layout()
        self.draw_bar_chart()
        self.draw_line_chart()


# ================= RUN =================

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = App()
    window.show()
    sys.exit(app.exec())
