import json
import os

from PySide6.QtWidgets import QMainWindow, QMessageBox
from login import Ui_LoginWindow


class LoginWindow(QMainWindow):
    def __init__(self, main_window_class):
        super().__init__()
        self.ui = Ui_LoginWindow()
        self.ui.setupUi(self)

        self.MainWindowClass = main_window_class
        self.USERS_JSON = os.path.join(
            os.path.dirname(os.path.abspath(__file__)), "data", "users.json"
        )


        self.ui.dang_nhap.clicked.connect(self._on_login)
        self.ui.nhap_id.returnPressed.connect(self._on_login)
        self.ui.nhap_mk.returnPressed.connect(self._on_login)

    #Đọc danh sách user#
    def _load_users(self):
        try:
            with open(self.USERS_JSON, "r", encoding="utf-8") as f:
                return json.load(f).get("users", [])
        except Exception as e:
            print(f"[AUTH] Không đọc được users.json: {e}")
            return []

    #Kiểm tra tài khoản#
    def xac_thuc(self, email_or_id, password, role):
        key = email_or_id.strip().lower()
        for u in self._load_users():
            email = (u.get("email") or u.get("emal") or "").lower()
            uid   = u.get("id", "").lower()
            if key in (email, uid) and u.get("password") == password:
                if u.get("role") == role:
                    return u
        return None

    #Xử lý nút đăng nhập#
    def _on_login(self):
        email    = self.ui.nhap_id.text().strip()
        password = self.ui.nhap_mk.text()
        role     = "admin" if self.ui.chon_role.currentIndex() == 0 else "student"

        if not email or not password:
            self.ui.lblError.setText("Vui lòng nhập đầy đủ email và mật khẩu!")
            return

        self.ui.dang_nhap.setEnabled(False)
        self.ui.dang_nhap.setText("Đang xác thực...")
        self.ui.lblError.setText("")

        try:
            user = self.xac_thuc(email, password, role)

            if user is None:
                self.ui.lblError.setText("Email/ID hoặc mật khẩu không đúng!")
                return

            if user.get("status") == "inactive":
                self.ui.lblError.setText("Tài khoản đã bị vô hiệu hóa!")
                return

            self._open_main(user) # ở đây tách hàm xử lý nút đăng nhập và việc mở trang giao diện người dùng

        except Exception as e:
            self.ui.lblError.setText(f"Lỗi hệ thống: {e}")
        finally:
            if self.isVisible():
                self.ui.dang_nhap.setEnabled(True)
                self.ui.dang_nhap.setText("ĐĂNG NHẬP")

    #Đăng nhập vào giao diện người dùng#
    def _open_main(self, user):
        if user.get("role") == "admin":
            self._main_win = self.MainWindowClass()
            self._main_win.setWindowTitle(
                f"UEL Library  —  {user.get('name', 'Admin')}"
            )
            self._main_win.show()
            self.close()
        else:
            QMessageBox.information(
                self, "Thông báo",
                f"Chào mừng {user.get('name', '')}!\n\n"
                "Giao diện sinh viên đang được phát triển.\n"
                "Hiện tại chỉ hỗ trợ đăng nhập Admin.",
            )
            self.ui.dang_nhap.setEnabled(True)
            self.ui.dang_nhap.setText("ĐĂNG NHẬP")
