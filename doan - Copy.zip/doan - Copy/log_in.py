import sys
import json
from PySide6.QtWidgets import QApplication, QWidget, QMessageBox
from index import Ui_Form


class MainApp(QWidget):
    def __init__(self):
        super().__init__()
        self.ui = Ui_Form()
        self.ui.setupUi(self)

        # Ẩn mật khẩu
        self.ui.nhap_mk.setEchoMode(self.ui.nhap_mk.EchoMode.Password)

        # Bắt sự kiện nút đăng nhập
        self.ui.log_in.clicked.connect(self.handle_login)

    def handle_login(self):
        email = self.ui.nhap_tk.text().strip()
        password = self.ui.nhap_mk.text().strip()

        if not email or not password:
            QMessageBox.warning(self, "Thiếu thông tin", "Vui lòng nhập đầy đủ email và mật khẩu!")
            return

        try:
            with open("data/users.json", "r", encoding="utf-8") as file:
                data = json.load(file)
        except FileNotFoundError:
            QMessageBox.critical(self, "Lỗi", "Không tìm thấy file users.json")
            return

        for user in data["users"]:
            if user["email"] == email and user["password"] == password:

                if user["status"] != "active":
                    QMessageBox.warning(self, "Thông báo", "Tài khoản đã bị khóa!")
                    return

                # Đổi tên hiển thị trên màn hình chính
                self.ui.label_8.setText(f"Hello, {user['name']} !")

                # Chuyển sang màn hình chính 2
                self.ui.stackedWidget.setCurrentIndex(1)
                return

        QMessageBox.warning(self, "Sai thông tin", "Email hoặc mật khẩu không đúng!")


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainApp()
    window.show()
    sys.exit(app.exec())
