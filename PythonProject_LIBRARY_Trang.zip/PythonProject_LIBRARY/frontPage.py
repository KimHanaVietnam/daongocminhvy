import json
from PySide6.QtWidgets import QMainWindow, QTableWidgetItem, QVBoxLayout
from PySide6.QtGui import QColor
from PySide6.QtCore import QTimer
from index_ui import Ui_MainWindow

# ====== THÊM CHO CHART  ======
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
# ====================================================


class MySideBar(QMainWindow, Ui_MainWindow):
    def __init__(self):
        super().__init__()

        self.setupUi(self)
        self.setWindowTitle("UEL Library")

        # Sidebar navigation
        self.pushButton_2.clicked.connect(lambda: self.stackedWidget.setCurrentIndex(0))
        self.pushButton_7.clicked.connect(lambda: self.stackedWidget.setCurrentIndex(1))
        self.pushButton_9.clicked.connect(lambda: self.stackedWidget.setCurrentIndex(2))
        self.pushButton_8.clicked.connect(lambda: self.stackedWidget.setCurrentIndex(3))
        self.pushButton_10.clicked.connect(lambda: self.stackedWidget.setCurrentIndex(4))

        # ===== DASHBOARD =====
        self.load_dashboard_cards()

        # ===== TABLE =====
        self.load_transfer_data()
        self.lineEdit.textChanged.connect(self.search_table)

        # ===== CHART (SỐ TỪ JSON) =====
        self.init_chart_layout()
        self.draw_bar_chart()
        self.draw_line_chart()

        # ===== AUTO REFRESH =====
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.refresh_dashboard)
        self.timer.start(3000)  # 3 giây refresh

    # ================= DASHBOARD CARDS =================

    def load_dashboard_cards(self):
        with open("data/books.json", "r", encoding="utf-8") as f:
            books = json.load(f)["books"]

        with open("data/students.json", "r", encoding="utf-8") as f:
            students = json.load(f)["students"]

        with open("data/borrow_record.json", "r", encoding="utf-8") as f:
            records = json.load(f)["borrow_record"]

        total_books = len(books)
        total_students = len(students)
        borrowing = sum(1 for r in records if r["status"] == "borrowing")
        overdue = sum(1 for r in records if r["status"] == "overdue")

        # ----- GÁN LÊN CARD -----
        # ĐỔI TÊN QLabel cho khớp với index_ui.py
        self.label_6.setText(str(total_books))
        self.label_25.setText(str(total_students))
        self.label_24.setText(str(borrowing))
        self.label_23.setText(str(overdue))

    # ================= TRANSFER TABLE =================

    def load_transfer_data(self):
        with open("data/borrow_record.json", "r", encoding="utf-8") as f:
            records = json.load(f)["borrow_record"]

        headers = ["id", "student_id", "book_id",
                   "borrow_date", "due_date", "status"]

        self.transferTable.setColumnCount(len(headers))
        self.transferTable.setHorizontalHeaderLabels(headers)
        self.transferTable.setRowCount(len(records))

        for row, record in enumerate(records):
            for col, key in enumerate(headers):
                item = QTableWidgetItem(record[key])

                if key == "status":
                    if record[key] == "overdue":
                        item.setBackground(QColor(255, 150, 150))
                    elif record[key] == "returned":
                        item.setBackground(QColor(150, 255, 150))
                    else:
                        item.setBackground(QColor(255, 255, 180))

                self.transferTable.setItem(row, col, item)

        self.transferTable.resizeColumnsToContents()

    # ================= SEARCH =================

    def search_table(self, text):
        for row in range(self.transferTable.rowCount()):
            match = False
            for col in range(self.transferTable.columnCount()):
                item = self.transferTable.item(row, col)
                if text.lower() in item.text().lower():
                    match = True
                    break
            self.transferTable.setRowHidden(row, not match)

    # ================= CHART LAYOUT =================

    def init_chart_layout(self):
        # LẤY LAYOUT CÓ SẴN TỪ QT DESIGNER (KHÔNG TẠO MỚI)
        self.bar_layout = self.ch_left.layout()
        self.line_layout = self.ch_right.layout()

        # BẢO VỆ TRƯỜNG HỢP QUÊN SET LAYOUT
        if self.bar_layout is None:
            self.bar_layout = QVBoxLayout(self.ch_left)
        if self.line_layout is None:
            self.line_layout = QVBoxLayout(self.ch_right)

    def clear_layout(self, layout):
        while layout.count():
            child = layout.takeAt(0)
            if child.widget():
                child.widget().deleteLater()

    # ================= BAR CHART =================

    def draw_bar_chart(self):
        self.clear_layout(self.bar_layout)

        with open("data/borrow_record.json", "r", encoding="utf-8") as f:
            records = json.load(f)["borrow_record"]

        days = ["T2", "T3", "T4", "T5", "T6", "T7", "CN"]
        borrow = [0] * 7
        returned = [0] * 7

        for r in records:
            try:
                day_index = int(r["borrow_date"].split("-")[-1]) % 7
            except:
                continue

            if r["status"] == "borrowing":
                borrow[day_index] += 1
            elif r["status"] == "returned":
                returned[day_index] += 1

        fig = Figure(figsize=(4, 3))
        canvas = FigureCanvas(fig)
        ax = fig.add_subplot(111)

        x = range(len(days))
        ax.bar(x, borrow, width=0.4, label="Mượn")
        ax.bar([i + 0.4 for i in x], returned, width=0.4, label="Trả")

        ax.set_xticks([i + 0.2 for i in x])
        ax.set_xticklabels(days)
        ax.set_title("Thống kê Mượn / Trả")
        ax.legend()

        fig.tight_layout()
        self.bar_layout.addWidget(canvas)

    # ================= LINE CHART =================

    def draw_line_chart(self):
        self.clear_layout(self.line_layout)

        with open("data/borrow_record.json", "r", encoding="utf-8") as f:
            records = json.load(f)["borrow_record"]

        days = ["T2", "T3", "T4", "T5", "T6", "T7", "CN"]
        visits = [0] * 7

        for r in records:
            try:
                day_index = int(r["borrow_date"].split("-")[-1]) % 7
            except:
                continue

            visits[day_index] += 1

        fig = Figure(figsize=(4, 3))
        canvas = FigureCanvas(fig)
        ax = fig.add_subplot(111)

        ax.plot(days, visits, marker="o")
        ax.set_title("Lượt truy cập hệ thống")

        fig.tight_layout()
        self.line_layout.addWidget(canvas)

    # ================= AUTO REFRESH =================

    def refresh_dashboard(self):
        self.load_dashboard_cards()
        self.draw_bar_chart()
        self.draw_line_chart()
