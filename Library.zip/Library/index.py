# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'index.ui'
##
## Created by: Qt User Interface Compiler version 6.10.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QFrame, QGridLayout, QGroupBox,
    QHBoxLayout, QHeaderView, QLabel, QLineEdit,
    QMainWindow, QPushButton, QScrollArea, QSizePolicy,
    QSpacerItem, QStackedWidget, QTableWidget, QTableWidgetItem,
    QTextEdit, QVBoxLayout, QWidget)
import resources_rc

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(1228, 921)
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.icon_text_widget = QWidget(self.centralwidget)
        self.icon_text_widget.setObjectName(u"icon_text_widget")
        self.icon_text_widget.setGeometry(QRect(50, 20, 251, 841))
        self.icon_text_widget.setStyleSheet(u"background-color: rgb(74, 74, 74);")
        self.verticalLayout_3 = QVBoxLayout(self.icon_text_widget)
        self.verticalLayout_3.setSpacing(55)
        self.verticalLayout_3.setObjectName(u"verticalLayout_3")
        self.horizontalLayout = QHBoxLayout()
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.label_3 = QLabel(self.icon_text_widget)
        self.label_3.setObjectName(u"label_3")
        self.label_3.setMinimumSize(QSize(19, 0))
        font = QFont()
        font.setPointSize(14)
        font.setBold(True)
        self.label_3.setFont(font)
        self.label_3.setStyleSheet(u"QLabel {\n"
"    color: white;\n"
"}\n"
"")

        self.horizontalLayout.addWidget(self.label_3)


        self.verticalLayout_3.addLayout(self.horizontalLayout)

        self.label_8 = QLabel(self.icon_text_widget)
        self.label_8.setObjectName(u"label_8")
        self.label_8.setMaximumSize(QSize(250, 200))
        self.label_8.setPixmap(QPixmap(u"open-book.png"))
        self.label_8.setScaledContents(True)

        self.verticalLayout_3.addWidget(self.label_8)

        self.verticalLayout = QVBoxLayout()
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.pushButton_2 = QPushButton(self.icon_text_widget)
        self.pushButton_2.setObjectName(u"pushButton_2")
        self.pushButton_2.setStyleSheet(u"background-color: rgb(255, 255, 255);")
        icon = QIcon()
        icon.addFile(u":/icons/icons/grid.svg", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.pushButton_2.setIcon(icon)
        self.pushButton_2.setCheckable(True)
        self.pushButton_2.setAutoExclusive(False)

        self.verticalLayout.addWidget(self.pushButton_2)

        self.pushButton_7 = QPushButton(self.icon_text_widget)
        self.pushButton_7.setObjectName(u"pushButton_7")
        self.pushButton_7.setStyleSheet(u"background-color: rgb(255, 255, 255);")
        icon1 = QIcon()
        icon1.addFile(u":/icons/icons/book-open.svg", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.pushButton_7.setIcon(icon1)
        self.pushButton_7.setCheckable(True)
        self.pushButton_7.setAutoExclusive(False)

        self.verticalLayout.addWidget(self.pushButton_7)

        self.pushButton_9 = QPushButton(self.icon_text_widget)
        self.pushButton_9.setObjectName(u"pushButton_9")
        self.pushButton_9.setStyleSheet(u"background-color: rgb(255, 255, 255);")
        icon2 = QIcon()
        icon2.addFile(u":/icons/icons/eye.svg", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.pushButton_9.setIcon(icon2)
        self.pushButton_9.setCheckable(True)
        self.pushButton_9.setAutoExclusive(False)

        self.verticalLayout.addWidget(self.pushButton_9)

        self.pushButton_8 = QPushButton(self.icon_text_widget)
        self.pushButton_8.setObjectName(u"pushButton_8")
        self.pushButton_8.setStyleSheet(u"background-color: rgb(255, 255, 255);")
        icon3 = QIcon()
        icon3.addFile(u":/icons/icons/users.svg", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.pushButton_8.setIcon(icon3)
        self.pushButton_8.setCheckable(True)
        self.pushButton_8.setAutoExclusive(False)

        self.verticalLayout.addWidget(self.pushButton_8)

        self.pushButton_10 = QPushButton(self.icon_text_widget)
        self.pushButton_10.setObjectName(u"pushButton_10")
        self.pushButton_10.setStyleSheet(u"background-color: rgb(255, 255, 255);")
        icon4 = QIcon()
        icon4.addFile(u":/icons/icons/globe.svg", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.pushButton_10.setIcon(icon4)
        self.pushButton_10.setCheckable(True)
        self.pushButton_10.setAutoExclusive(False)

        self.verticalLayout.addWidget(self.pushButton_10)


        self.verticalLayout_3.addLayout(self.verticalLayout)

        self.verticalLayout_2 = QVBoxLayout()
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.pushButton_12 = QPushButton(self.icon_text_widget)
        self.pushButton_12.setObjectName(u"pushButton_12")
        self.pushButton_12.setStyleSheet(u"background-color: rgb(255, 255, 255);")
        icon5 = QIcon()
        icon5.addFile(u":/icons/icons/settings.svg", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.pushButton_12.setIcon(icon5)
        self.pushButton_12.setCheckable(True)
        self.pushButton_12.setAutoExclusive(True)

        self.verticalLayout_2.addWidget(self.pushButton_12)

        self.pushButton_11 = QPushButton(self.icon_text_widget)
        self.pushButton_11.setObjectName(u"pushButton_11")
        self.pushButton_11.setStyleSheet(u"background-color: rgb(255, 255, 255);")
        icon6 = QIcon()
        icon6.addFile(u":/icons/icons/log-out.svg", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.pushButton_11.setIcon(icon6)
        self.pushButton_11.setCheckable(True)
        self.pushButton_11.setAutoExclusive(True)

        self.verticalLayout_2.addWidget(self.pushButton_11)


        self.verticalLayout_3.addLayout(self.verticalLayout_2)

        self.layoutWidget = QWidget(self.centralwidget)
        self.layoutWidget.setObjectName(u"layoutWidget")
        self.layoutWidget.setGeometry(QRect(330, 20, 981, 801))
        self.verticalLayout_4 = QVBoxLayout(self.layoutWidget)
        self.verticalLayout_4.setObjectName(u"verticalLayout_4")
        self.verticalLayout_4.setContentsMargins(0, 0, 0, 0)
        self.header_widget = QWidget(self.layoutWidget)
        self.header_widget.setObjectName(u"header_widget")
        self.layoutWidget1 = QWidget(self.header_widget)
        self.layoutWidget1.setObjectName(u"layoutWidget1")
        self.layoutWidget1.setGeometry(QRect(20, 20, 409, 51))
        self.horizontalLayout_2 = QHBoxLayout(self.layoutWidget1)
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.horizontalLayout_2.setContentsMargins(0, 0, 0, 0)
        self.pushButton = QPushButton(self.layoutWidget1)
        self.pushButton.setObjectName(u"pushButton")
        icon7 = QIcon()
        icon7.addFile(u":/icons/icons/align-justify.svg", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.pushButton.setIcon(icon7)
        self.pushButton.setIconSize(QSize(29, 35))
        self.pushButton.setCheckable(True)

        self.horizontalLayout_2.addWidget(self.pushButton)

        self.label_2 = QLabel(self.layoutWidget1)
        self.label_2.setObjectName(u"label_2")
        font1 = QFont()
        font1.setPointSize(10)
        self.label_2.setFont(font1)
        self.label_2.setStyleSheet(u"color: rgb(135, 135, 135);")

        self.horizontalLayout_2.addWidget(self.label_2)

        self.label = QLabel(self.layoutWidget1)
        self.label.setObjectName(u"label")
        font2 = QFont()
        font2.setPointSize(15)
        self.label.setFont(font2)

        self.horizontalLayout_2.addWidget(self.label)

        self.layoutWidget2 = QWidget(self.header_widget)
        self.layoutWidget2.setObjectName(u"layoutWidget2")
        self.layoutWidget2.setGeometry(QRect(500, 0, 321, 81))
        self.horizontalLayout_3 = QHBoxLayout(self.layoutWidget2)
        self.horizontalLayout_3.setObjectName(u"horizontalLayout_3")
        self.horizontalLayout_3.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout_5 = QVBoxLayout()
        self.verticalLayout_5.setObjectName(u"verticalLayout_5")

        self.horizontalLayout_3.addLayout(self.verticalLayout_5)

        self.lineEdit = QLineEdit(self.layoutWidget2)
        self.lineEdit.setObjectName(u"lineEdit")
        self.lineEdit.setStyleSheet(u"QlineEdit{\n"
"  padding-left:20px;\n"
"  border:1px-solid gray;\n"
"  border-radius: 20px;\n"
"}")

        self.horizontalLayout_3.addWidget(self.lineEdit)

        self.widget = QWidget(self.layoutWidget2)
        self.widget.setObjectName(u"widget")

        self.horizontalLayout_3.addWidget(self.widget)

        self.label_5 = QLabel(self.layoutWidget2)
        self.label_5.setObjectName(u"label_5")
        self.label_5.setFont(font1)
        self.label_5.setStyleSheet(u"color: rgb(135, 135, 135);\n"
"color: rgb(0, 0, 0);")

        self.horizontalLayout_3.addWidget(self.label_5)

        self.label_4 = QLabel(self.layoutWidget2)
        self.label_4.setObjectName(u"label_4")
        self.label_4.setFont(font1)
        self.label_4.setStyleSheet(u"color: rgb(135, 135, 135);")
        self.label_4.setPixmap(QPixmap(u":/icons/icons/user.svg"))

        self.horizontalLayout_3.addWidget(self.label_4)

        self.stackedWidget = QStackedWidget(self.header_widget)
        self.stackedWidget.setObjectName(u"stackedWidget")
        self.stackedWidget.setGeometry(QRect(10, 130, 861, 681))
        self.stackedWidget.setMaximumSize(QSize(941, 741))
        self.stackedWidget.setStyleSheet(u"background-color: rgb(255, 255, 255);\n"
"QPushButton {\n"
"    background-color: #2563eb;\n"
"    color: white;\n"
"    border-radius: 10px;\n"
"    padding: 6px 12px;\n"
"    font-weight: bold;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #1e4fd6;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: #173ea8;\n"
"}")
        self.page = QWidget()
        self.page.setObjectName(u"page")
        self.page.setMaximumSize(QSize(841, 741))
        self.label_15 = QLabel(self.page)
        self.label_15.setObjectName(u"label_15")
        self.label_15.setGeometry(QRect(50, 160, 41, 31))
        self.label_15.setPixmap(QPixmap(u"C:/Users/PC/.designer/backup/icons/book.svg"))
        self.textEdit = QTextEdit(self.page)
        self.textEdit.setObjectName(u"textEdit")
        self.textEdit.setGeometry(QRect(30, 130, 151, 71))
        self.textEdit.setStyleSheet(u"background-color: rgb(0, 200, 200);")
        self.textEdit.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.textEdit.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.textEdit.setReadOnly(True)
        self.textEdit_2 = QTextEdit(self.page)
        self.textEdit_2.setObjectName(u"textEdit_2")
        self.textEdit_2.setGeometry(QRect(240, 130, 151, 71))
        self.textEdit_2.setStyleSheet(u"background-color: rgb(111, 180, 99);")
        self.textEdit_2.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.textEdit_2.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.textEdit_2.setReadOnly(True)
        self.textEdit_3 = QTextEdit(self.page)
        self.textEdit_3.setObjectName(u"textEdit_3")
        self.textEdit_3.setGeometry(QRect(650, 130, 151, 71))
        self.textEdit_3.setStyleSheet(u"background-color: rgb(195, 96, 16);")
        self.textEdit_3.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.textEdit_3.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.textEdit_3.setReadOnly(True)
        self.textEdit_4 = QTextEdit(self.page)
        self.textEdit_4.setObjectName(u"textEdit_4")
        self.textEdit_4.setGeometry(QRect(450, 130, 151, 71))
        self.textEdit_4.setStyleSheet(u"background-color: rgb(168, 109, 216);")
        self.textEdit_4.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.textEdit_4.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.textEdit_4.setReadOnly(True)
        self.label_18 = QLabel(self.page)
        self.label_18.setObjectName(u"label_18")
        self.label_18.setGeometry(QRect(470, 160, 41, 31))
        self.label_18.setPixmap(QPixmap(u"C:/Users/PC/.designer/backup/icons/clipboard.svg"))
        self.label_19 = QLabel(self.page)
        self.label_19.setObjectName(u"label_19")
        self.label_19.setGeometry(QRect(260, 160, 41, 31))
        self.label_19.setPixmap(QPixmap(u"C:/Users/PC/.designer/backup/icons/Student--Streamline-Phosphor.svg"))
        self.label_20 = QLabel(self.page)
        self.label_20.setObjectName(u"label_20")
        self.label_20.setGeometry(QRect(670, 160, 41, 31))
        self.label_20.setPixmap(QPixmap(u"C:/Users/PC/.designer/backup/icons/clock.svg"))
        self.label_21 = QLabel(self.page)
        self.label_21.setObjectName(u"label_21")
        self.label_21.setGeometry(QRect(50, 70, 701, 31))
        font3 = QFont()
        font3.setFamilies([u"Times New Roman"])
        font3.setPointSize(12)
        self.label_21.setFont(font3)
        self.label_22 = QLabel(self.page)
        self.label_22.setObjectName(u"label_22")
        self.label_22.setGeometry(QRect(50, 20, 291, 41))
        font4 = QFont()
        font4.setFamilies([u"Times New Roman"])
        font4.setPointSize(16)
        font4.setBold(True)
        self.label_22.setFont(font4)
        self.frame = QFrame(self.page)
        self.frame.setObjectName(u"frame")
        self.frame.setGeometry(QRect(10, 230, 851, 481))
        self.frame.setFrameShape(QFrame.StyledPanel)
        self.frame.setFrameShadow(QFrame.Raised)
        self.ch_left = QWidget(self.frame)
        self.ch_left.setObjectName(u"ch_left")
        self.ch_left.setGeometry(QRect(40, 40, 381, 391))
        self.ch_right = QWidget(self.frame)
        self.ch_right.setObjectName(u"ch_right")
        self.ch_right.setGeometry(QRect(450, 40, 371, 391))
        self.label_6 = QLabel(self.page)
        self.label_6.setObjectName(u"label_6")
        self.label_6.setGeometry(QRect(90, 160, 71, 31))
        self.label_6.setStyleSheet(u"background-color: rgb(255, 255, 255);")
        self.label_23 = QLabel(self.page)
        self.label_23.setObjectName(u"label_23")
        self.label_23.setGeometry(QRect(710, 160, 71, 31))
        self.label_23.setStyleSheet(u"background-color: rgb(255, 255, 255);")
        self.label_24 = QLabel(self.page)
        self.label_24.setObjectName(u"label_24")
        self.label_24.setGeometry(QRect(510, 160, 71, 31))
        self.label_24.setStyleSheet(u"background-color: rgb(255, 255, 255);")
        self.label_25 = QLabel(self.page)
        self.label_25.setObjectName(u"label_25")
        self.label_25.setGeometry(QRect(300, 160, 71, 31))
        self.label_25.setStyleSheet(u"background-color: rgb(255, 255, 255);")
        self.label_27 = QLabel(self.page)
        self.label_27.setObjectName(u"label_27")
        self.label_27.setGeometry(QRect(560, 20, 271, 41))
        self.label_27.setFont(font4)
        self.stackedWidget.addWidget(self.page)
        self.textEdit.raise_()
        self.label_15.raise_()
        self.textEdit_2.raise_()
        self.textEdit_3.raise_()
        self.textEdit_4.raise_()
        self.label_18.raise_()
        self.label_19.raise_()
        self.label_20.raise_()
        self.label_21.raise_()
        self.label_22.raise_()
        self.frame.raise_()
        self.label_6.raise_()
        self.label_23.raise_()
        self.label_24.raise_()
        self.label_25.raise_()
        self.label_27.raise_()
        self.page_3 = QWidget()
        self.page_3.setObjectName(u"page_3")
        self.page_3.setMaximumSize(QSize(841, 741))
        self.groupBox = QGroupBox(self.page_3)
        self.groupBox.setObjectName(u"groupBox")
        self.groupBox.setGeometry(QRect(10, 10, 811, 101))
        self.groupBox.setStyleSheet(u"background-color: rgb(251, 255, 206);")
        self.label_7 = QLabel(self.groupBox)
        self.label_7.setObjectName(u"label_7")
        self.label_7.setGeometry(QRect(30, 10, 391, 51))
        self.label_26 = QLabel(self.groupBox)
        self.label_26.setObjectName(u"label_26")
        self.label_26.setGeometry(QRect(30, 60, 541, 31))
        self.label_32 = QLabel(self.groupBox)
        self.label_32.setObjectName(u"label_32")
        self.label_32.setGeometry(QRect(670, 10, 101, 81))
        self.label_32.setMaximumSize(QSize(18000, 18000))
        self.label_32.setPixmap(QPixmap(u"C:/Users/PC/Downloads/book-stack.png"))
        self.label_32.setScaledContents(True)
        self.lineEdit_2 = QLineEdit(self.page_3)
        self.lineEdit_2.setObjectName(u"lineEdit_2")
        self.lineEdit_2.setGeometry(QRect(30, 130, 771, 61))
        self.lineEdit_2.setStyleSheet(u"background-color: rgb(220, 220, 220);")
        self.scrollArea = QScrollArea(self.page_3)
        self.scrollArea.setObjectName(u"scrollArea")
        self.scrollArea.setGeometry(QRect(10, 210, 811, 471))
        self.scrollArea.setWidgetResizable(True)
        self.scrollAreaWidgetContents = QWidget()
        self.scrollAreaWidgetContents.setObjectName(u"scrollAreaWidgetContents")
        self.scrollAreaWidgetContents.setGeometry(QRect(0, 0, 809, 469))
        self.verticalLayoutWidget = QWidget(self.scrollAreaWidgetContents)
        self.verticalLayoutWidget.setObjectName(u"verticalLayoutWidget")
        self.verticalLayoutWidget.setGeometry(QRect(10, 10, 791, 451))
        self.verticalLayout_6 = QVBoxLayout(self.verticalLayoutWidget)
        self.verticalLayout_6.setObjectName(u"verticalLayout_6")
        self.verticalLayout_6.setContentsMargins(0, 0, 0, 0)
        self.scrollArea.setWidget(self.scrollAreaWidgetContents)
        self.stackedWidget.addWidget(self.page_3)
        self.page_2 = QWidget()
        self.page_2.setObjectName(u"page_2")
        self.page_2.setStyleSheet(u"\n"
"QWidget { background-color:#f5f7fb; }\n"
"#cardFrame { background:white; border-radius:16px; }\n"
"QPushButton#addBtn { background:#2563eb; color:white; border-radius:8px; padding:8px 16px; }\n"
"QPushButton#pageActive { background:#2563eb; color:white; border-radius:6px; padding:4px 10px; }\n"
"QPushButton#pageBtn { background:#e5e7eb; border-radius:6px; padding:4px 10px; }\n"
" ")
        self.vboxLayout = QVBoxLayout(self.page_2)
        self.vboxLayout.setObjectName(u"vboxLayout")
        self.hboxLayout = QHBoxLayout()
        self.hboxLayout.setObjectName(u"hboxLayout")
        self.vboxLayout1 = QVBoxLayout()
        self.vboxLayout1.setObjectName(u"vboxLayout1")
        self.label1 = QLabel(self.page_2)
        self.label1.setObjectName(u"label1")

        self.vboxLayout1.addWidget(self.label1)

        self.label2 = QLabel(self.page_2)
        self.label2.setObjectName(u"label2")

        self.vboxLayout1.addWidget(self.label2)


        self.hboxLayout.addLayout(self.vboxLayout1)

        self.spacerItem = QSpacerItem(0, 0, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.hboxLayout.addItem(self.spacerItem)

        self.addBtn = QPushButton(self.page_2)
        self.addBtn.setObjectName(u"addBtn")

        self.hboxLayout.addWidget(self.addBtn)


        self.vboxLayout.addLayout(self.hboxLayout)

        self.cardFrame = QFrame(self.page_2)
        self.cardFrame.setObjectName(u"cardFrame")
        self.vboxLayout2 = QVBoxLayout(self.cardFrame)
        self.vboxLayout2.setObjectName(u"vboxLayout2")
        self.hboxLayout1 = QHBoxLayout()
        self.hboxLayout1.setObjectName(u"hboxLayout1")
        self.lineEdit1 = QLineEdit(self.cardFrame)
        self.lineEdit1.setObjectName(u"lineEdit1")

        self.hboxLayout1.addWidget(self.lineEdit1)

        self.spacerItem1 = QSpacerItem(0, 0, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.hboxLayout1.addItem(self.spacerItem1)

        self.xuat_excel = QPushButton(self.cardFrame)
        self.xuat_excel.setObjectName(u"xuat_excel")

        self.hboxLayout1.addWidget(self.xuat_excel)

        self.filter = QPushButton(self.cardFrame)
        self.filter.setObjectName(u"filter")

        self.hboxLayout1.addWidget(self.filter)


        self.vboxLayout2.addLayout(self.hboxLayout1)

        self.tableReaders = QTableWidget(self.cardFrame)
        if (self.tableReaders.columnCount() < 5):
            self.tableReaders.setColumnCount(5)
        __qtablewidgetitem = QTableWidgetItem()
        self.tableReaders.setHorizontalHeaderItem(0, __qtablewidgetitem)
        __qtablewidgetitem1 = QTableWidgetItem()
        self.tableReaders.setHorizontalHeaderItem(1, __qtablewidgetitem1)
        __qtablewidgetitem2 = QTableWidgetItem()
        self.tableReaders.setHorizontalHeaderItem(2, __qtablewidgetitem2)
        __qtablewidgetitem3 = QTableWidgetItem()
        self.tableReaders.setHorizontalHeaderItem(3, __qtablewidgetitem3)
        __qtablewidgetitem4 = QTableWidgetItem()
        self.tableReaders.setHorizontalHeaderItem(4, __qtablewidgetitem4)
        self.tableReaders.setObjectName(u"tableReaders")
        self.tableReaders.setColumnCount(5)

        self.vboxLayout2.addWidget(self.tableReaders)

        self.hboxLayout2 = QHBoxLayout()
        self.hboxLayout2.setObjectName(u"hboxLayout2")
        self.label3 = QLabel(self.cardFrame)
        self.label3.setObjectName(u"label3")

        self.hboxLayout2.addWidget(self.label3)

        self.spacerItem2 = QSpacerItem(0, 0, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.hboxLayout2.addItem(self.spacerItem2)

        self.pageBtn = QPushButton(self.cardFrame)
        self.pageBtn.setObjectName(u"pageBtn")

        self.hboxLayout2.addWidget(self.pageBtn)

        self.pageActive = QPushButton(self.cardFrame)
        self.pageActive.setObjectName(u"pageActive")

        self.hboxLayout2.addWidget(self.pageActive)

        self.pageBtn1 = QPushButton(self.cardFrame)
        self.pageBtn1.setObjectName(u"pageBtn1")

        self.hboxLayout2.addWidget(self.pageBtn1)


        self.vboxLayout2.addLayout(self.hboxLayout2)


        self.vboxLayout.addWidget(self.cardFrame)

        self.stackedWidget.addWidget(self.page_2)
        self.page_4 = QWidget()
        self.page_4.setObjectName(u"page_4")
        self.page_4.setMaximumSize(QSize(841, 741))
        self.transferTable = QTableWidget(self.page_4)
        if (self.transferTable.columnCount() < 6):
            self.transferTable.setColumnCount(6)
        __qtablewidgetitem5 = QTableWidgetItem()
        self.transferTable.setHorizontalHeaderItem(0, __qtablewidgetitem5)
        __qtablewidgetitem6 = QTableWidgetItem()
        self.transferTable.setHorizontalHeaderItem(1, __qtablewidgetitem6)
        __qtablewidgetitem7 = QTableWidgetItem()
        self.transferTable.setHorizontalHeaderItem(2, __qtablewidgetitem7)
        __qtablewidgetitem8 = QTableWidgetItem()
        self.transferTable.setHorizontalHeaderItem(3, __qtablewidgetitem8)
        __qtablewidgetitem9 = QTableWidgetItem()
        self.transferTable.setHorizontalHeaderItem(4, __qtablewidgetitem9)
        __qtablewidgetitem10 = QTableWidgetItem()
        self.transferTable.setHorizontalHeaderItem(5, __qtablewidgetitem10)
        self.transferTable.setObjectName(u"transferTable")
        self.transferTable.setGeometry(QRect(30, 250, 911, 481))
        self.transferTable.setStyleSheet(u"QHeaderView::section{\n"
"    font-weight: bold;\n"
"    background-color: black;\n"
"    color: white;\n"
"}\n"
"\n"
"QTableWidget{\n"
"    alternate-background-color: #B0EDFB;\n"
"    background-color: #F4F9FA;\n"
"}\n"
"")
        self.label_9 = QLabel(self.page_4)
        self.label_9.setObjectName(u"label_9")
        self.label_9.setGeometry(QRect(134, 75, 91, 51))
        self.label_9.setPixmap(QPixmap(u":/icons/icons/alert-circle.svg"))
        self.widget_2 = QWidget(self.page_4)
        self.widget_2.setObjectName(u"widget_2")
        self.widget_2.setGeometry(QRect(40, 70, 221, 101))
        self.widget_2.setStyleSheet(u"background-color: white;\n"
"background-color: rgb(187, 191, 255);\n"
"border-radius: 15px;\n"
"border: 1px solid #dddddd;\n"
"")
        self.label_11 = QLabel(self.widget_2)
        self.label_11.setObjectName(u"label_11")
        self.label_11.setGeometry(QRect(10, 30, 55, 31))
        self.label_11.setPixmap(QPixmap(u":/icons/icons/clock.svg"))
        self.label_14 = QLabel(self.widget_2)
        self.label_14.setObjectName(u"label_14")
        self.label_14.setGeometry(QRect(60, 30, 121, 31))
        self.label_14.setStyleSheet(u"font: 10pt \"MS Shell Dlg 2\";")
        self.widget_3 = QWidget(self.page_4)
        self.widget_3.setObjectName(u"widget_3")
        self.widget_3.setGeometry(QRect(300, 70, 221, 101))
        self.widget_3.setStyleSheet(u"background-color: white;\n"
"background-color: rgb(255, 135, 161);\n"
"border-radius: 15px;\n"
"border: 1px solid #dddddd;\n"
"")
        self.label_12 = QLabel(self.widget_3)
        self.label_12.setObjectName(u"label_12")
        self.label_12.setGeometry(QRect(10, 30, 55, 31))
        self.label_12.setPixmap(QPixmap(u":/icons/icons/alert-circle.svg"))
        self.label_16 = QLabel(self.widget_3)
        self.label_16.setObjectName(u"label_16")
        self.label_16.setGeometry(QRect(60, 40, 101, 16))
        self.label_16.setStyleSheet(u"font: 10pt \"MS Shell Dlg 2\";")
        self.widget_4 = QWidget(self.page_4)
        self.widget_4.setObjectName(u"widget_4")
        self.widget_4.setGeometry(QRect(550, 70, 221, 101))
        self.widget_4.setStyleSheet(u"background-color: white;\n"
"background-color: rgb(225, 253, 255);\n"
"border-radius: 15px;\n"
"border: 1px solid #dddddd;\n"
"")
        self.label_13 = QLabel(self.widget_4)
        self.label_13.setObjectName(u"label_13")
        self.label_13.setGeometry(QRect(10, 30, 55, 31))
        self.label_13.setPixmap(QPixmap(u":/icons/icons/thumbs-up.svg"))
        self.label_17 = QLabel(self.widget_4)
        self.label_17.setObjectName(u"label_17")
        self.label_17.setGeometry(QRect(50, 40, 171, 21))
        self.label_17.setStyleSheet(u"font: 10pt \"MS Shell Dlg 2\";")
        self.stackedWidget.addWidget(self.page_4)
        self.page_5 = QWidget()
        self.page_5.setObjectName(u"page_5")
        self.page_5.setMaximumSize(QSize(841, 741))
        self.scrollArea_2 = QScrollArea(self.page_5)
        self.scrollArea_2.setObjectName(u"scrollArea_2")
        self.scrollArea_2.setGeometry(QRect(0, 170, 841, 511))
        self.scrollArea_2.setWidgetResizable(True)
        self.scrollAreaWidgetContents_3 = QWidget()
        self.scrollAreaWidgetContents_3.setObjectName(u"scrollAreaWidgetContents_3")
        self.scrollAreaWidgetContents_3.setGeometry(QRect(0, 0, 839, 509))
        self.gridLayout = QGridLayout(self.scrollAreaWidgetContents_3)
        self.gridLayout.setObjectName(u"gridLayout")
        self.wid = QWidget(self.scrollAreaWidgetContents_3)
        self.wid.setObjectName(u"wid")
        self.verticalLayout_7 = QVBoxLayout(self.wid)
        self.verticalLayout_7.setObjectName(u"verticalLayout_7")
        self.ver = QVBoxLayout()
        self.ver.setObjectName(u"ver")

        self.verticalLayout_7.addLayout(self.ver)


        self.gridLayout.addWidget(self.wid, 0, 0, 1, 1)

        self.scrollArea_2.setWidget(self.scrollAreaWidgetContents_3)
        self.label_10 = QLabel(self.page_5)
        self.label_10.setObjectName(u"label_10")
        self.label_10.setGeometry(QRect(0, 10, 391, 41))
        self.label_28 = QLabel(self.page_5)
        self.label_28.setObjectName(u"label_28")
        self.label_28.setGeometry(QRect(0, 40, 431, 41))
        self.label_29 = QLabel(self.page_5)
        self.label_29.setObjectName(u"label_29")
        self.label_29.setGeometry(QRect(10, 120, 271, 51))
        self.btn_borrow = QPushButton(self.page_5)
        self.btn_borrow.setObjectName(u"btn_borrow")
        self.btn_borrow.setGeometry(QRect(610, 0, 211, 28))
        self.btn_borrow.setStyleSheet(u"QPushButton {\n"
"    background-color: #079DD9;\n"
"    color: white;\n"
"    border-radius: 10px;\n"
"    padding: 6px 12px;\n"
"    font-weight: bold;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #99D9F2;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: #80BDF2;\n"
"}")
        self.widget_5 = QWidget(self.page_5)
        self.widget_5.setObjectName(u"widget_5")
        self.widget_5.setGeometry(QRect(560, 40, 271, 121))
        self.widget_5.setStyleSheet(u"QWidget {\n"
"    background-color: #079DD9;\n"
"	color: white;\n"
"    border-radius: 20px;\n"
"}")
        self.label_30 = QLabel(self.widget_5)
        self.label_30.setObjectName(u"label_30")
        self.label_30.setGeometry(QRect(10, 10, 141, 21))
        self.label_31 = QLabel(self.widget_5)
        self.label_31.setObjectName(u"label_31")
        self.label_31.setGeometry(QRect(10, 30, 261, 41))
        self.btn_share = QPushButton(self.widget_5)
        self.btn_share.setObjectName(u"btn_share")
        self.btn_share.setGeometry(QRect(60, 80, 151, 28))
        self.btn_share.setStyleSheet(u"QPushButton {\n"
"    background-color: white;\n"
"    color: #079DD9;\n"
"    border-radius: 10px;\n"
"    padding: 6px 12px;\n"
"    font-weight: bold;\n"
"}\n"
"\n"
"QPushButton:hover{\n"
"    background-color: #E8F1FD;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: #BBD8F2;\n"
"}")
        icon8 = QIcon()
        iconThemeName = u"share"
        if QIcon.hasThemeIcon(iconThemeName):
            icon8 = QIcon.fromTheme(iconThemeName)
        else:
            icon8.addFile(u"C:/Users/PC/.designer/backup", QSize(), QIcon.Mode.Normal, QIcon.State.Off)

        self.btn_share.setIcon(icon8)
        self.stackedWidget.addWidget(self.page_5)
        self.stackedWidget.raise_()
        self.layoutWidget2.raise_()
        self.layoutWidget2.raise_()

        self.verticalLayout_4.addWidget(self.header_widget)

        MainWindow.setCentralWidget(self.centralwidget)
        self.layoutWidget2.raise_()
        self.icon_text_widget.raise_()

        self.retranslateUi(MainWindow)

        self.stackedWidget.setCurrentIndex(0)


        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"MainWindow", None))
        self.label_3.setText(QCoreApplication.translate("MainWindow", u"<html><head/><body><p align=\"center\"><span style=\" font-size:18pt;\">TH\u01af VI\u1ec6N UEL </span></p></body></html>", None))
        self.label_8.setText("")
        self.pushButton_2.setText(QCoreApplication.translate("MainWindow", u"B\u1ea3ng \u0111i\u1ec1u khi\u1ec3n", None))
        self.pushButton_7.setText(QCoreApplication.translate("MainWindow", u"Kho s\u00e1ch", None))
        self.pushButton_9.setText(QCoreApplication.translate("MainWindow", u"\u0110\u1ed9c gi\u1ea3 ", None))
        self.pushButton_8.setText(QCoreApplication.translate("MainWindow", u"M\u01b0\u1ee3n/ Tr\u1ea3 s\u00e1ch", None))
        self.pushButton_10.setText(QCoreApplication.translate("MainWindow", u"C\u1ed9ng \u0111\u1ed3ng", None))
        self.pushButton_12.setText("")
        self.pushButton_11.setText(QCoreApplication.translate("MainWindow", u"\u0110\u0102NG XU\u1ea4T", None))
        self.pushButton.setText("")
        self.label_2.setText(QCoreApplication.translate("MainWindow", u"Welcome to your page.", None))
        self.label.setText(QCoreApplication.translate("MainWindow", u"Hello, Everyone!", None))
        self.lineEdit.setPlaceholderText(QCoreApplication.translate("MainWindow", u"Search here....", None))
        self.label_5.setText(QCoreApplication.translate("MainWindow", u"Admin", None))
        self.label_4.setText("")
        self.label_15.setText("")
        self.textEdit.setHtml(QCoreApplication.translate("MainWindow", u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'MS Shell Dlg 2'; font-size:7.8pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"center\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:9pt; font-weight:600; color:#ffffff;\">T\u1ed5ng s\u1ed1 s\u00e1ch</span></p></body></html>", None))
        self.textEdit_2.setHtml(QCoreApplication.translate("MainWindow", u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'MS Shell Dlg 2'; font-size:7.8pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"center\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:9pt; font-weight:600; color:#ffffff;\">Sinh vi\u00ean \u0111\u0103ng k\u00ed</span></p></body></html>", None))
        self.textEdit_3.setHtml(QCoreApplication.translate("MainWindow", u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'MS Shell Dlg 2'; font-size:7.8pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"center\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:9pt; font-weight:600; color:#ffffff;\">Qu\u00e1 h\u1ea1n</span></p></body></html>", None))
        self.textEdit_4.setHtml(QCoreApplication.translate("MainWindow", u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'MS Shell Dlg 2'; font-size:7.8pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"center\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:9pt; font-weight:600; color:#ffffff;\">\u0110ang m\u01b0\u1ee3n</span></p></body></html>", None))
        self.label_18.setText("")
        self.label_19.setText("")
        self.label_20.setText("")
        self.label_21.setText(QCoreApplication.translate("MainWindow", u"<html><head/><body><p><span style=\" font-size:14pt; font-style:italic;\">Ch\u00e0o m\u1eebng b\u1ea1n tr\u1edf l\u1ea1i, \u0111\u00e2y l\u00e0 nh\u1eefng g\u00ec \u0111ang di\u1ec5n ra h\u00f4m nay!</span></p><p><span style=\" font-size:14pt;\"><br/></span></p></body></html>", None))
        self.label_22.setText(QCoreApplication.translate("MainWindow", u"<html><head/><body><p><span style=\" font-size:20pt;\">T\u1ed5ng quan h\u1ec7 th\u1ed1ng</span></p></body></html>", None))
        self.label_6.setText("")
        self.label_23.setText("")
        self.label_24.setText("")
        self.label_25.setText("")
        self.label_27.setText(QCoreApplication.translate("MainWindow", u"<html><head/><body><p><span style=\" font-size:20pt;\">Theo d\u00f5i s\u1ef1 ki\u1ec7n</span></p></body></html>", None))
        self.groupBox.setTitle("")
        self.label_7.setText(QCoreApplication.translate("MainWindow", u"<html><head/><body><p><span style=\" font-size:22pt; font-weight:600;\">Kho t\u00e0i li\u1ec7u tri th\u1ee9c </span></p></body></html>", None))
        self.label_26.setText(QCoreApplication.translate("MainWindow", u"<html><head/><body><p><span style=\" font-size:12pt; font-style:italic;\">Qu\u1ea3n l\u00fd v\u00e0 c\u1eadp nh\u1eadt danh m\u1ee5c s\u00e1ch trong h\u1ec7 th\u1ed1ng.</span></p></body></html>", None))
        self.label_32.setText("")
        self.lineEdit_2.setPlaceholderText(QCoreApplication.translate("MainWindow", u"T\u00ecm ki\u1ebfm theo ti\u00eau \u0111\u1ec1, t\u00e1c gi\u1ea3,...", None))
        self.label1.setStyleSheet(QCoreApplication.translate("MainWindow", u"font-size:22px; font-weight:600;", None))
        self.label1.setText(QCoreApplication.translate("MainWindow", u"Danh s\u00e1ch \u0111\u1ed9c gi\u1ea3", None))
        self.label2.setStyleSheet(QCoreApplication.translate("MainWindow", u"color:gray;", None))
        self.label2.setText(QCoreApplication.translate("MainWindow", u"Qu\u1ea3n l\u00fd th\u00f4ng tin v\u00e0 tr\u1ea1ng th\u00e1i \u0111\u1ed9c gi\u1ea3", None))
        self.addBtn.setText(QCoreApplication.translate("MainWindow", u"+ Th\u00eam \u0111\u1ed9c gi\u1ea3", None))
        self.lineEdit1.setPlaceholderText(QCoreApplication.translate("MainWindow", u"T\u00ecm theo m\u00e3 \u0111\u1ed9c gi\u1ea3 ho\u1eb7c t\u00ean...", None))
        self.xuat_excel.setText(QCoreApplication.translate("MainWindow", u"Xu\u1ea5t Excel", None))
        self.filter.setText(QCoreApplication.translate("MainWindow", u"B\u1ed9 l\u1ecdc", None))
        ___qtablewidgetitem = self.tableReaders.horizontalHeaderItem(0)
        ___qtablewidgetitem.setText(QCoreApplication.translate("MainWindow", u"H\u1ecd t\u00ean", None));
        ___qtablewidgetitem1 = self.tableReaders.horizontalHeaderItem(1)
        ___qtablewidgetitem1.setText(QCoreApplication.translate("MainWindow", u"M\u00e3", None));
        ___qtablewidgetitem2 = self.tableReaders.horizontalHeaderItem(2)
        ___qtablewidgetitem2.setText(QCoreApplication.translate("MainWindow", u"Email", None));
        ___qtablewidgetitem3 = self.tableReaders.horizontalHeaderItem(3)
        ___qtablewidgetitem3.setText(QCoreApplication.translate("MainWindow", u"Ng\u00e0y \u0111\u0103ng k\u00fd", None));
        ___qtablewidgetitem4 = self.tableReaders.horizontalHeaderItem(4)
        ___qtablewidgetitem4.setText(QCoreApplication.translate("MainWindow", u"Tr\u1ea1ng th\u00e1i", None));
        self.label3.setText(QCoreApplication.translate("MainWindow", u"Hi\u1ec3n th\u1ecb 5 tr\u00ean 120 \u0111\u1ed9c gi\u1ea3", None))
        self.pageBtn.setText(QCoreApplication.translate("MainWindow", u"Tr\u01b0\u1edbc", None))
        self.pageActive.setText(QCoreApplication.translate("MainWindow", u"1", None))
        self.pageBtn1.setText(QCoreApplication.translate("MainWindow", u"Sau", None))
        ___qtablewidgetitem5 = self.transferTable.horizontalHeaderItem(0)
        ___qtablewidgetitem5.setText(QCoreApplication.translate("MainWindow", u"id", None));
        ___qtablewidgetitem6 = self.transferTable.horizontalHeaderItem(1)
        ___qtablewidgetitem6.setText(QCoreApplication.translate("MainWindow", u"student_id", None));
        ___qtablewidgetitem7 = self.transferTable.horizontalHeaderItem(2)
        ___qtablewidgetitem7.setText(QCoreApplication.translate("MainWindow", u"book_id", None));
        ___qtablewidgetitem8 = self.transferTable.horizontalHeaderItem(3)
        ___qtablewidgetitem8.setText(QCoreApplication.translate("MainWindow", u"borrow_date", None));
        ___qtablewidgetitem9 = self.transferTable.horizontalHeaderItem(4)
        ___qtablewidgetitem9.setText(QCoreApplication.translate("MainWindow", u"due_date", None));
        ___qtablewidgetitem10 = self.transferTable.horizontalHeaderItem(5)
        ___qtablewidgetitem10.setText(QCoreApplication.translate("MainWindow", u"status", None));
        self.label_9.setText("")
        self.label_11.setText("")
        self.label_14.setText(QCoreApplication.translate("MainWindow", u"Borrowing : 3", None))
        self.label_12.setText("")
        self.label_16.setText(QCoreApplication.translate("MainWindow", u"Overdue : 3", None))
        self.label_13.setText("")
        self.label_17.setText(QCoreApplication.translate("MainWindow", u"Already returned : 4", None))
        self.label_10.setText(QCoreApplication.translate("MainWindow", u"<html><head/><body><p><span style=\" font-size:14pt; font-weight:600;\">Kh\u00f4ng gian chia s\u1ebb s\u00e1ch c\u00e1 nh\u00e2n</span></p></body></html>", None))
        self.label_28.setText(QCoreApplication.translate("MainWindow", u"<html><head/><body><p><span style=\" font-size:10pt; font-style:italic;\">N\u01a1i sinh vi\u00ean c\u00f3 th\u1ec3 cho m\u01b0\u1ee3n v\u00e0 trao \u0111\u1ed5i s\u00e1ch c\u00e1 nh\u00e2n</span></p></body></html>", None))
        self.label_29.setText(QCoreApplication.translate("MainWindow", u"<html><head/><body><p><span style=\" font-size:12pt; font-weight:600;\">S\u00e1ch c\u1ed9ng \u0111\u1ed3ng m\u1edbi nh\u1ea5t</span></p></body></html>", None))
        self.btn_borrow.setText(QCoreApplication.translate("MainWindow", u"\u0110\u0103ng k\u00fd cho m\u01b0\u1ee3n s\u00e1ch", None))
        self.label_30.setText(QCoreApplication.translate("MainWindow", u"<html><head/><body><p><span style=\" font-size:10pt; font-weight:600;\">Lan t\u1ecfa tri th\u1ee9c</span></p></body></html>", None))
        self.label_31.setText(QCoreApplication.translate("MainWindow", u"<html><head/><body><p align=\"justify\">Chia s\u1ebb cu\u1ed1n s\u00e1ch t\u00e2m \u0111\u1eafc c\u1ee7a b\u1ea1n v\u1edbi <br/>c\u1ed9ng \u0111\u1ed3ng sinh vi\u00ean \u0111\u1ec3 c\u00f9ng nhau ph\u00e1t tri\u1ec3n.</p></body></html>", None))
        self.btn_share.setText(QCoreApplication.translate("MainWindow", u"B\u1eaft \u0111\u1ea7u chia s\u1ebb", None))
    # retranslateUi

