import json
from PySide6.QtWidgets import QMainWindow, QTableWidgetItem, QVBoxLayout,QWidget, QLabel,QPushButton, QHBoxLayout, QMessageBox, QSizePolicy
from PySide6.QtGui import QColor, QPixmap
from PySide6.QtCore import QTimer,Qt
from index_ui import Ui_MainWindow
import os
from datetime import datetime, timedelta
# ====== THÊM CHO CHART  ======
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
# ====================================================
class MySideBar(QMainWindow, Ui_MainWindow):
    def __init__(self):
        super().__init__()
        self.cancel_time = None
        self.setupUi(self)
        self.setWindowTitle("UEL Library")
        self.load_books()
        # Sidebar navigation
        self.pushButton_2.clicked.connect(lambda: self.stackedWidget.setCurrentIndex(0))
        self.pushButton_7.clicked.connect(lambda: self.stackedWidget.setCurrentIndex(1))
        self.pushButton_9.clicked.connect(lambda: self.stackedWidget.setCurrentIndex(2))
        self.pushButton_8.clicked.connect(lambda: self.stackedWidget.setCurrentIndex(3))
        self.pushButton_10.clicked.connect(lambda: self.stackedWidget.setCurrentIndex(4))
        # ===== DASHBOARD =====
        self.load_dashboard_cards()
        # ===== TABLE =====
        self.load_transfer_data()
        self.lineEdit.textChanged.connect(self.search_table)
        # ===== CHART (SỐ TỪ JSON) =====
        self.init_chart_layout()
        self.draw_bar_chart()
        self.draw_line_chart()
        # ===== AUTO REFRESH =====
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.refresh_dashboard)
        self.timer.start(3000)  # 3 giây refresh

        self.load_community_books()
        self.lineEdit.textChanged.connect(self.filter_community_books)

    def filter_community_books(self, text):
        keyword = text.lower().strip()
        for card in self.community_cards:
            title = card.book["title"].lower()
            category = card.book["category"].lower()
            owner = card.book.get("owner_name", "").lower()
            if (keyword in title or
                    keyword in category or
                    keyword in owner):
                card.show()
            else:
                card.hide()

    def load_community_books(self):
        with open("data/users.json", "r", encoding="utf-8") as f:
            users = json.load(f)["users"]
        user_map = {u["id"]: u["name"] for u in users}
        with open("data/community_books.json", "r", encoding="utf-8") as f:
            books = json.load(f)["community_books"]
        self.community_cards = []
        for b in books:
            b["owner_name"] = user_map.get(b["owner"], b["owner"])
        layout = self.ver
        while layout.count():
            item = layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
            elif item.layout():
                while item.layout().count():
                    child = item.layout().takeAt(0)
                    if child.widget():
                        child.widget().deleteLater()
        layout.setSpacing(20)
        row_layout = None
        for i, book in enumerate(books):
            if i % 2 == 0:
                row_layout = QHBoxLayout()
                row_layout.setSpacing(20)
                layout.addLayout(row_layout)
            card = CommunityCard(book)
            self.community_cards.append(card)
            row_layout.addWidget(card)

    # ================= DASHBOARD CARDS =================

    def load_dashboard_cards(self):
        with open("data/books.json", "r", encoding="utf-8") as f:
            books = json.load(f)["books"]

        with open("data/students.json", "r", encoding="utf-8") as f:
            students = json.load(f)["students"]

        with open("data/borrow_record.json", "r", encoding="utf-8") as f:
            records = json.load(f)["borrow_record"]

        total_books = len(books)
        total_students = len(students)
        borrowing = sum(1 for r in records if r["status"] == "borrowing")
        overdue = sum(1 for r in records if r["status"] == "overdue")

        # ----- GÁN LÊN CARD -----
        # ĐỔI TÊN QLabel cho khớp với index_ui.py
        self.label_6.setText(str(total_books))
        self.label_25.setText(str(total_students))
        self.label_24.setText(str(borrowing))
        self.label_23.setText(str(overdue))

    # ================= TRANSFER TABLE =================

    def load_transfer_data(self):
        with open("data/borrow_record.json", "r", encoding="utf-8") as f:
            records = json.load(f)["borrow_record"]

        headers = ["id", "student_id", "book_id",
                   "borrow_date", "due_date", "status"]

        self.transferTable.setColumnCount(len(headers))
        self.transferTable.setHorizontalHeaderLabels(headers)
        self.transferTable.setRowCount(len(records))

        for row, record in enumerate(records):
            for col, key in enumerate(headers):
                item = QTableWidgetItem(record[key])

                if key == "status":
                    if record[key] == "overdue":
                        item.setBackground(QColor(255, 150, 150))
                    elif record[key] == "returned":
                        item.setBackground(QColor(150, 255, 150))
                    else:
                        item.setBackground(QColor(255, 255, 180))

                self.transferTable.setItem(row, col, item)

        self.transferTable.resizeColumnsToContents()

    # ================= SEARCH =================

    def search_table(self, text):
        for row in range(self.transferTable.rowCount()):
            match = False
            for col in range(self.transferTable.columnCount()):
                item = self.transferTable.item(row, col)
                if text.lower() in item.text().lower():
                    match = True
                    break
            self.transferTable.setRowHidden(row, not match)

    # ================= CHART LAYOUT =================

    def init_chart_layout(self):
        # LẤY LAYOUT CÓ SẴN TỪ QT DESIGNER (KHÔNG TẠO MỚI)
        self.bar_layout = self.ch_left.layout()
        self.line_layout = self.ch_right.layout()

        # BẢO VỆ TRƯỜNG HỢP QUÊN SET LAYOUT
        if self.bar_layout is None:
            self.bar_layout = QVBoxLayout(self.ch_left)
        if self.line_layout is None:
            self.line_layout = QVBoxLayout(self.ch_right)

    def clear_layout(self, layout):
        while layout.count():
            child = layout.takeAt(0)
            if child.widget():
                child.widget().deleteLater()

    # ================= BAR CHART =================

    def draw_bar_chart(self):
        self.clear_layout(self.bar_layout)

        with open("data/borrow_record.json", "r", encoding="utf-8") as f:
            records = json.load(f)["borrow_record"]

        days = ["T2", "T3", "T4", "T5", "T6", "T7", "CN"]
        borrow = [0] * 7
        returned = [0] * 7

        for r in records:
            try:
                day_index = int(r["borrow_date"].split("-")[-1]) % 7
            except:
                continue

            if r["status"] == "borrowing":
                borrow[day_index] += 1
            elif r["status"] == "returned":
                returned[day_index] += 1

        fig = Figure(figsize=(4, 3))
        canvas = FigureCanvas(fig)
        ax = fig.add_subplot(111)

        x = range(len(days))
        ax.bar(x, borrow, width=0.4, label="Mượn")
        ax.bar([i + 0.4 for i in x], returned, width=0.4, label="Trả")

        ax.set_xticks([i + 0.2 for i in x])
        ax.set_xticklabels(days)
        ax.set_title("Thống kê Mượn / Trả")
        ax.legend()

        fig.tight_layout()
        self.bar_layout.addWidget(canvas)

    # ================= LINE CHART =================

    def draw_line_chart(self):
        self.clear_layout(self.line_layout)

        with open("data/borrow_record.json", "r", encoding="utf-8") as f:
            records = json.load(f)["borrow_record"]

        days = ["T2", "T3", "T4", "T5", "T6", "T7", "CN"]
        visits = [0] * 7

        for r in records:
            try:
                day_index = int(r["borrow_date"].split("-")[-1]) % 7
            except:
                continue

            visits[day_index] += 1

        fig = Figure(figsize=(4, 3))
        canvas = FigureCanvas(fig)
        ax = fig.add_subplot(111)

        ax.plot(days, visits, marker="o")
        ax.set_title("Lượt truy cập hệ thống")

        fig.tight_layout()
        self.line_layout.addWidget(canvas)

    # ================= AUTO REFRESH =================

    def refresh_dashboard(self):
        self.load_dashboard_cards()
        self.draw_bar_chart()
        self.draw_line_chart()
#################PVy######################
    def load_books(self):
        with open("data/books.json", "r", encoding="utf-8") as f:
            books = json.load(f)["books"]

        layout = self.scrollAreaWidgetContents.layout()

        if layout is None:
            layout = QVBoxLayout(self.scrollAreaWidgetContents)
            self.scrollAreaWidgetContents.setLayout(layout)

        # Xóa item cũ
        while layout.count():
            child = layout.takeAt(0)
            if child.widget():
                child.widget().deleteLater()

        # Thêm item mới
        for book in books:
            item = bookItem(book)
            layout.addWidget(item)

        layout.addStretch()


class bookItem(QWidget):
    def __init__(self, book_data):
        super().__init__()

        self.setFixedHeight(120)
        self.setStyleSheet("""
            QWidget {
                background-color: white;
                border-radius: 10px;
            }
        """)

        main_layout = QHBoxLayout(self)
        main_layout.setContentsMargins(15, 10, 15, 10)
        main_layout.setSpacing(15)

        # ===== ẢNH BOOK =====
        self.image_label = QLabel()
        self.image_label.setFixedSize(80, 100)

        base_dir = os.path.dirname(os.path.abspath(__file__))
        image_path = os.path.join(base_dir, book_data.get("image", ""))

        print("Loading:", image_path)  # debug

        if os.path.exists(image_path) and book_data.get("image"):
            pixmap = QPixmap(image_path)

            if not pixmap.isNull():
                self.image_label.setPixmap(
                    pixmap.scaled(80, 100, Qt.KeepAspectRatio, Qt.SmoothTransformation)
                )
            else:
                self.image_label.setText("Invalid Image")
                self.image_label.setAlignment(Qt.AlignCenter)
        else:
            self.image_label.setText("No Image")
            self.image_label.setAlignment(Qt.AlignCenter)
        # ===== INFO =====
        info_layout = QVBoxLayout()
        info_layout.setSpacing(5)

        self.title = QLabel(book_data.get("title", "Unknown Title"))
        self.title.setStyleSheet("font-weight: bold; font-size: 14px;")

        self.author = QLabel("Author: " + book_data.get("author", "Unknown"))
        self.category = QLabel("Category: " + book_data.get("category", "Unknown"))

        # ===== STOCK INFO =====
        total_quantity = int(book_data.get("total_quantity", 0))
        available_quantity = int(book_data.get("available_quantity", 0))
        rate = float(book_data.get("rate", 0))

        self.total_label = QLabel(f"Total: {total_quantity}")
        self.available_label = QLabel(f"Available: {available_quantity}")
        self.rate_label = QLabel(f"Rating: {rate}")
        info_layout.addWidget(self.title)
        info_layout.addWidget(self.author)
        info_layout.addWidget(self.category)
        info_layout.addWidget(self.total_label)
        info_layout.addWidget(self.available_label)
        info_layout.addWidget(self.rate_label)
        main_layout.addWidget(self.image_label)
        main_layout.addLayout(info_layout)

#PHƯƠNG
# ================= COMMUNITY PAGE =================
class CommunityCard(QWidget):
    def __init__(self, book):
        super().__init__()
        self.book = book
        self.cancel_time = None
        self.setMinimumHeight(180)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        self.setStyleSheet("""
        QWidget{
            background: #F8FAFC;          
            border-radius:14px;
            border:1px solid #E5E7EB;
        }
        
        QPushButton{
            background-color: #079DD9;
            color: white;
            border-radius: 10px;
            padding: 8px 16px;
            font-weight: bold;
        }

        QPushButton:hover{
            background:#99D9F2;          
        }
        
        QPushButton:pressed {
            background-color: #80BDF2;
        }   
        
        QPushButton:disabled{
            background:#BDBDBD;          
        }
        """)
        main_layout = QHBoxLayout(self)
        main_layout.setContentsMargins(15,15,15,15)
        main_layout.setSpacing(15)

        img = QLabel()
        img.setFixedSize(100,140)
        base = os.path.dirname(os.path.abspath(__file__))
        path = os.path.join(base, book.get("image", ""))
        if os.path.exists(path):
            pix = QPixmap(path)
            img.setPixmap(pix.scaled(100, 140, Qt.KeepAspectRatio, Qt.SmoothTransformation))
        else:
            img.setText("Chưa có dữ liệu")
            img.setAlignment(Qt.AlignCenter)
        main_layout.addWidget(img)
        info_layout = QVBoxLayout()
        info_layout.setSpacing(6)
        category = QLabel(book["category"])
        category.setStyleSheet("""
                    background:#E8F1FD;             
                    padding:3px 8px;
                    border-radius:8px;
                    font-size:11px;
                """)
        title = QLabel(book["title"])
        title.setWordWrap(True)
        title.setStyleSheet("font-weight:700; font-size:14px;")
        owner = QLabel(f"Chủ sách: {book.get('owner_name', book['owner'])}")
        owner.setStyleSheet("color:#6B7280; font-size:12px;")

        info_layout.addWidget(category)
        info_layout.addWidget(title)
        info_layout.addWidget(owner)

        bottom_layout = QHBoxLayout()
        status_map = {
            "available": ("Còn sẵn", "#27AE60"),
            "requested": ("Đang yêu cầu", "#F2C94C"),
            "borrowed": ("Tạm hết", "#EB5757")
        }
        text, color = status_map.get(book["status"], ("?", "#999"))
        self.status_label = QLabel(text)
        self.status_label.setStyleSheet(f"""
            background:{color};
            color:white;
            padding:4px 10px;
            border-radius:8px;
            font-size:11px;
        """)

        self.borrow_btn = QPushButton("Mượn ngay")
        self.borrow_btn.setEnabled(book["status"] == "available")
        self.borrow_btn.clicked.connect(self.borrow_clicked)

        # ===== NÚT HỦY =====
        self.cancel_btn = QPushButton("Huỷ mượn")
        self.cancel_btn.setStyleSheet("""
            QPushButton {
                background-color: #EB5757;
                color: white;
                border-radius: 10px;
                padding: 8px 16px;
                font-weight: bold;
            }
        
            QPushButton:hover {
                background-color: #FF7B7B;   
            }
        
            QPushButton:pressed {
                background-color: #C0392B;   
            }
        """)
        self.cancel_btn.clicked.connect(self.cancel_request)
        self.cancel_btn.hide()
        bottom_layout.addWidget(self.status_label)
        bottom_layout.addStretch()
        bottom_layout.addWidget(self.borrow_btn)
        bottom_layout.addWidget(self.cancel_btn)
        info_layout.addLayout(bottom_layout)
        main_layout.addLayout(info_layout)

    def borrow_clicked(self):
        # ===== 1. Nếu đang ở trạng thái requested =====
        if self.book["status"] == "requested":
            QMessageBox.information(
                self,
                "Thông báo",
                "Bạn đã gửi yêu cầu rồi."
            )
            return
        # ===== 2. Nếu vừa huỷ trong 24h =====
        if self.cancel_time:
            if datetime.now() - self.cancel_time < timedelta(hours=24):
                QMessageBox.warning(
                    self,
                    "Không thể mượn",
                    "Bạn vừa huỷ yêu cầu.\nTrong 24 giờ không được mượn lại."
                )
                return
        # ===== 3. Cho phép gửi yêu cầu =====
        QMessageBox.information(
            self,
            "Mượn sách",
            f"Bạn đã gửi yêu cầu mượn:\n{self.book['title']}"
        )
        self.book["status"] = "requested"
        self.status_label.setText("Đang yêu cầu")
        self.status_label.setStyleSheet("""
            background:#F2C94C;
            color:white;
            padding:4px 10px;
            border-radius:8px;
            font-size:11px;
        """)
        self.cancel_btn.show()
    def cancel_request(self):
        reply = QMessageBox.question(
            self,
            "Xác nhận huỷ",
            "Bạn có chắc chắn huỷ?\nSau 24 giờ mới được yêu cầu lại.",
            QMessageBox.Ok | QMessageBox.Cancel
        )

        if reply == QMessageBox.Ok:
            self.book["status"] = "available"
            self.status_label.setText("Còn sẵn")
            self.status_label.setStyleSheet("""
                background:#27AE60;
                color:white;
                padding:4px 10px;
                border-radius:8px;
                font-size:11px;
            """)
            self.cancel_time = datetime.now()
            self.cancel_btn.hide()
        else:
            return


