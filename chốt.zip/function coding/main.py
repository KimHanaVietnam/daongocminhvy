import sys
from PySide6.QtWidgets import QApplication
from PySide6.QtGui import QFont

from dang_nhap import LoginWindow
from frontPage import MySideBar


def main():
    app = QApplication(sys.argv)
    window = LoginWindow(MySideBar)
    window.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
