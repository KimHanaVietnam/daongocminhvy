# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'login.ui'
##
## Created by: Qt User Interface Compiler version 6.10.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QComboBox, QHBoxLayout, QLabel,
    QLineEdit, QMainWindow, QPushButton, QSizePolicy,
    QSpacerItem, QVBoxLayout, QWidget)

class Ui_LoginWindow(object):
    def setupUi(self, LoginWindow):
        if not LoginWindow.objectName():
            LoginWindow.setObjectName(u"LoginWindow")
        LoginWindow.resize(900, 620)
        self.centralwidget = QWidget(LoginWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.leftPanel = QWidget(self.centralwidget)
        self.leftPanel.setObjectName(u"leftPanel")
        self.leftPanel.setGeometry(QRect(0, 0, 420, 620))
        self.leftPanel.setStyleSheet(u"background-color: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #6b3fa0, stop:0.5 #7c4daa, stop:1 #9b6fc4);")
        self.leftContent = QWidget(self.leftPanel)
        self.leftContent.setObjectName(u"leftContent")
        self.leftContent.setGeometry(QRect(30, 0, 360, 620))
        self.leftVLayout = QVBoxLayout(self.leftContent)
        self.leftVLayout.setSpacing(16)
        self.leftVLayout.setObjectName(u"leftVLayout")
        self.leftVLayout.setContentsMargins(0, 80, 0, 60)
        self.nhom_4 = QLabel(self.leftContent)
        self.nhom_4.setObjectName(u"nhom_4")
        self.nhom_4.setStyleSheet(u"color: white; font-size: 22pt; font-weight: bold; background: transparent;")
        self.nhom_4.setAlignment(Qt.AlignCenter)

        self.leftVLayout.addWidget(self.nhom_4)

        self.spacerItem = QSpacerItem(20, 20, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.leftVLayout.addItem(self.spacerItem)

        self.Icon = QLabel(self.leftContent)
        self.Icon.setObjectName(u"Icon")
        self.Icon.setStyleSheet(u"color: white; font-size: 64px; background: transparent;")
        self.Icon.setAlignment(Qt.AlignCenter)

        self.leftVLayout.addWidget(self.Icon)

        self.ten_he_thong = QLabel(self.leftContent)
        self.ten_he_thong.setObjectName(u"ten_he_thong")
        self.ten_he_thong.setStyleSheet(u"color: white; font-size: 18px; font-weight: bold; background: transparent;")
        self.ten_he_thong.setAlignment(Qt.AlignCenter)
        self.ten_he_thong.setWordWrap(True)

        self.leftVLayout.addWidget(self.ten_he_thong)

        self.chu_thich = QLabel(self.leftContent)
        self.chu_thich.setObjectName(u"chu_thich")
        self.chu_thich.setStyleSheet(u"color: rgba(255,255,255,166); font-size: 12px; background: transparent;")
        self.chu_thich.setAlignment(Qt.AlignCenter)
        self.chu_thich.setWordWrap(True)

        self.leftVLayout.addWidget(self.chu_thich)

        self.spacerItem1 = QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.leftVLayout.addItem(self.spacerItem1)

        self.rightPanel = QWidget(self.centralwidget)
        self.rightPanel.setObjectName(u"rightPanel")
        self.rightPanel.setGeometry(QRect(420, 0, 480, 620))
        self.rightPanel.setStyleSheet(u"background-color: white;")
        self.rightContent = QWidget(self.rightPanel)
        self.rightContent.setObjectName(u"rightContent")
        self.rightContent.setGeometry(QRect(55, 0, 370, 620))
        self.rightVLayout = QVBoxLayout(self.rightContent)
        self.rightVLayout.setSpacing(0)
        self.rightVLayout.setObjectName(u"rightVLayout")
        self.rightVLayout.setContentsMargins(0, 60, 0, 40)
        self.lblLoginTitle = QLabel(self.rightContent)
        self.lblLoginTitle.setObjectName(u"lblLoginTitle")
        self.lblLoginTitle.setStyleSheet(u"font-size: 26px; font-weight: bold; color: #6b3fa0; background: transparent;")

        self.rightVLayout.addWidget(self.lblLoginTitle)

        self.lblLoginSub = QLabel(self.rightContent)
        self.lblLoginSub.setObjectName(u"lblLoginSub")
        self.lblLoginSub.setStyleSheet(u"font-size: 13px; color: #6b7280; background: transparent; margin-bottom: 20px;")

        self.rightVLayout.addWidget(self.lblLoginSub)

        self.spacerItem2 = QSpacerItem(20, 20, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.rightVLayout.addItem(self.spacerItem2)

        self.roleLayout = QVBoxLayout()
        self.roleLayout.setSpacing(6)
        self.roleLayout.setObjectName(u"roleLayout")
        self.lblRole = QLabel(self.rightContent)
        self.lblRole.setObjectName(u"lblRole")
        self.lblRole.setStyleSheet(u"font-size: 12px; font-weight: bold; color: #374151; background: transparent;")

        self.roleLayout.addWidget(self.lblRole)

        self.chon_role = QComboBox(self.rightContent)
        self.chon_role.addItem("")
        self.chon_role.setObjectName(u"chon_role")
        self.chon_role.setMinimumHeight(42)
        self.chon_role.setStyleSheet(u"QComboBox {\n"
"    border: 1.5px solid #d1d5db; border-radius: 8px;\n"
"    padding: 6px 12px; font-size: 13px; color: #374151; background: white;\n"
"}\n"
"QComboBox:focus { border-color: #9b6fc4; }\n"
"QComboBox::drop-down { border: none; width: 30px; }\n"
"QComboBox QAbstractItemView {\n"
"    background: white; color: #374151;\n"
"    selection-background-color: #ede4f7; selection-color: #6b3fa0;\n"
"    border: 1px solid #e5e7eb;\n"
"}")

        self.roleLayout.addWidget(self.chon_role)


        self.rightVLayout.addLayout(self.roleLayout)

        self.spacerItem3 = QSpacerItem(20, 12, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.rightVLayout.addItem(self.spacerItem3)

        self.emailLayout = QVBoxLayout()
        self.emailLayout.setSpacing(6)
        self.emailLayout.setObjectName(u"emailLayout")
        self.lblEmail = QLabel(self.rightContent)
        self.lblEmail.setObjectName(u"lblEmail")
        self.lblEmail.setStyleSheet(u"font-size: 12px; font-weight: bold; color: #374151; background: transparent;")

        self.emailLayout.addWidget(self.lblEmail)

        self.nhap_id = QLineEdit(self.rightContent)
        self.nhap_id.setObjectName(u"nhap_id")
        self.nhap_id.setMinimumHeight(42)
        self.nhap_id.setStyleSheet(u"QLineEdit {\n"
"    border: 1.5px solid #d1d5db; border-radius: 8px;\n"
"    padding: 8px 14px; font-size: 13px; color: #374151; background: #f9fafb;\n"
"}\n"
"QLineEdit:focus { border-color: #9b6fc4; background: white; }")

        self.emailLayout.addWidget(self.nhap_id)


        self.rightVLayout.addLayout(self.emailLayout)

        self.spacerItem4 = QSpacerItem(20, 12, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.rightVLayout.addItem(self.spacerItem4)

        self.passwordLayout = QVBoxLayout()
        self.passwordLayout.setSpacing(6)
        self.passwordLayout.setObjectName(u"passwordLayout")
        self.lblPassword = QLabel(self.rightContent)
        self.lblPassword.setObjectName(u"lblPassword")
        self.lblPassword.setStyleSheet(u"font-size: 12px; font-weight: bold; color: #374151; background: transparent;")

        self.passwordLayout.addWidget(self.lblPassword)

        self.nhap_mk = QLineEdit(self.rightContent)
        self.nhap_mk.setObjectName(u"nhap_mk")
        self.nhap_mk.setMinimumHeight(42)
        self.nhap_mk.setStyleSheet(u"QLineEdit {\n"
"    border: 1.5px solid #d1d5db; border-radius: 8px;\n"
"    padding: 8px 14px; font-size: 13px; color: #374151; background: #f9fafb;\n"
"}\n"
"QLineEdit:focus { border-color: #9b6fc4; background: white; }")
        self.nhap_mk.setEchoMode(QLineEdit.Password)

        self.passwordLayout.addWidget(self.nhap_mk)


        self.rightVLayout.addLayout(self.passwordLayout)

        self.spacerItem5 = QSpacerItem(20, 8, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.rightVLayout.addItem(self.spacerItem5)

        self.extraBtnLayout = QHBoxLayout()
        self.extraBtnLayout.setSpacing(0)
        self.extraBtnLayout.setObjectName(u"extraBtnLayout")
        self.pushButton = QPushButton(self.rightContent)
        self.pushButton.setObjectName(u"pushButton")
        self.pushButton.setStyleSheet(u"QPushButton {\n"
"    border: none;\n"
"    background: transparent;\n"
"    color: #9ca3af;\n"
"    font-size: 12px;\n"
"    padding: 4px 0px;\n"
"}\n"
"QPushButton:hover { color: #6b7280; }\n"
"QPushButton:pressed { color: #374151; }")
        self.pushButton.setFlat(True)

        self.extraBtnLayout.addWidget(self.pushButton)

        self.horizontalSpacer = QSpacerItem(40, 20, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.extraBtnLayout.addItem(self.horizontalSpacer)

        self.pushButton_2 = QPushButton(self.rightContent)
        self.pushButton_2.setObjectName(u"pushButton_2")
        self.pushButton_2.setStyleSheet(u"QPushButton {\n"
"    border: none;\n"
"    background: transparent;\n"
"    color: #6b3fa0;\n"
"    font-size: 12px;\n"
"    font-weight: bold;\n"
"    padding: 4px 0px;\n"
"}\n"
"QPushButton:hover { color: #9b6fc4; }\n"
"QPushButton:pressed { color: #5e2d8a; }")
        self.pushButton_2.setFlat(True)

        self.extraBtnLayout.addWidget(self.pushButton_2)


        self.rightVLayout.addLayout(self.extraBtnLayout)

        self.spacerItem6 = QSpacerItem(20, 8, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.rightVLayout.addItem(self.spacerItem6)

        self.lblError = QLabel(self.rightContent)
        self.lblError.setObjectName(u"lblError")
        self.lblError.setMinimumHeight(20)
        self.lblError.setStyleSheet(u"color: #ef4444; font-size: 12px; background: transparent;")
        self.lblError.setWordWrap(True)

        self.rightVLayout.addWidget(self.lblError)

        self.dang_nhap = QPushButton(self.rightContent)
        self.dang_nhap.setObjectName(u"dang_nhap")
        self.dang_nhap.setMinimumHeight(48)
        self.dang_nhap.setStyleSheet(u"QPushButton {\n"
"    background-color: #6b3fa0; color: white; border-radius: 10px;\n"
"    font-size: 14px; font-weight: bold; border: none;\n"
"}\n"
"QPushButton:hover { background-color: #9b6fc4; }\n"
"QPushButton:pressed { background-color: #5e2d8a; }\n"
"QPushButton:disabled { background-color: #d4afe8; }")

        self.rightVLayout.addWidget(self.dang_nhap)

        self.spacerItem7 = QSpacerItem(20, 20, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding)

        self.rightVLayout.addItem(self.spacerItem7)

        LoginWindow.setCentralWidget(self.centralwidget)

        self.retranslateUi(LoginWindow)

        QMetaObject.connectSlotsByName(LoginWindow)
    # setupUi

    def retranslateUi(self, LoginWindow):
        LoginWindow.setWindowTitle(QCoreApplication.translate("LoginWindow", u"\u0110\u0103ng Nh\u1eadp - UEL Library", None))
        self.nhom_4.setText(QCoreApplication.translate("LoginWindow", u"NH\u00d3M 4", None))
        self.Icon.setText(QCoreApplication.translate("LoginWindow", u"\U0001f4da", None))
        self.ten_he_thong.setText(QCoreApplication.translate("LoginWindow", u"H\u1ec6 TH\u1ed0NG QU\u1ea2N L\u00dd TH\u01af VI\u1ec6N UEL", None))
        self.chu_thich.setText(QCoreApplication.translate("LoginWindow", u"Qu\u1ea3n l\u00fd s\u00e1ch, sinh vi\u00ean v\u00e0 l\u01b0\u1ee3t m\u01b0\u1ee3n tr\u1ea3 m\u1ed9t c\u00e1ch hi\u1ec7u qu\u1ea3 v\u00e0 ti\u1ec7n l\u1ee3i", None))
        self.lblLoginTitle.setText(QCoreApplication.translate("LoginWindow", u"\u0110\u0103ng Nh\u1eadp", None))
        self.lblLoginSub.setText(QCoreApplication.translate("LoginWindow", u"Ch\u00e0o m\u1eebng b\u1ea1n tr\u1edf l\u1ea1i h\u1ec7 th\u1ed1ng!", None))
        self.lblRole.setText(QCoreApplication.translate("LoginWindow", u"Vai tr\u00f2", None))
        self.chon_role.setItemText(0, QCoreApplication.translate("LoginWindow", u"\U0001f393  \U00000110\U00001ed9c Gi\U00001ea3 (Student)", None))

        self.lblEmail.setText(QCoreApplication.translate("LoginWindow", u"Email / ID", None))
        self.nhap_id.setPlaceholderText(QCoreApplication.translate("LoginWindow", u"Nh\u1eadp email ho\u1eb7c ID c\u1ee7a b\u1ea1n...", None))
        self.lblPassword.setText(QCoreApplication.translate("LoginWindow", u"M\u1eadt kh\u1ea9u", None))
        self.nhap_mk.setPlaceholderText(QCoreApplication.translate("LoginWindow", u"Nh\u1eadp m\u1eadt kh\u1ea9u...", None))
        self.pushButton.setText(QCoreApplication.translate("LoginWindow", u"T\u1ea1o t\u00e0i kho\u1ea3n", None))
        self.pushButton_2.setText(QCoreApplication.translate("LoginWindow", u"Qu\u00ean m\u1eadt kh\u1ea9u?", None))
        self.lblError.setText("")
        self.dang_nhap.setText(QCoreApplication.translate("LoginWindow", u"\u0110\u0102NG NH\u1eacP", None))
    # retranslateUi

