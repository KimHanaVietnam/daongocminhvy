import json
from PySide6.QtWidgets import QMainWindow, QTableWidgetItem, QVBoxLayout, QWidget, QLabel, QPushButton, QHBoxLayout, QMessageBox, QSizePolicy, QDialog, QLineEdit, QComboBox, QHeaderView
from PySide6.QtGui import QColor, QPixmap
from PySide6.QtCore import QTimer,Qt
from index import Ui_MainWindow
import os
from datetime import datetime, timedelta
import xlsxwriter
# ====== THÊM CHO CHART  ======
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
# ====================================================
class MySideBar(QMainWindow, Ui_MainWindow):
    def __init__(self):
        super().__init__()
        self.cancel_time = None
        self.setupUi(self)
        self.stackedWidget.setCurrentIndex(0)
        self.setWindowTitle("UEL Library")
        self.load_books()
        # Sidebar navigation
        self.pushButton_2.clicked.connect(lambda: self.stackedWidget.setCurrentIndex(0))
        self.pushButton_7.clicked.connect(lambda: self.stackedWidget.setCurrentIndex(1))
        self.pushButton_9.clicked.connect(lambda: self.stackedWidget.setCurrentIndex(2))
        self.pushButton_8.clicked.connect(lambda: self.stackedWidget.setCurrentIndex(3))
        self.pushButton_10.clicked.connect(lambda: self.stackedWidget.setCurrentIndex(4))
        # ===== DASHBOARD =====
        self.load_dashboard_cards()
        self.load_dashboard_lists()
        # ===== TABLE =====
        self.load_transfer_data()
        self.lineEdit.textChanged.connect(self.search_table)
        # ===== CHART (SỐ TỪ JSON) =====
        self.init_chart_layout()
        self.draw_bar_chart()
        self.draw_line_chart()
        # ===== AUTO REFRESH =====
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.refresh_dashboard)
        self.timer.start(10000)  # 10 giây refresh
        self.load_community_books()
        self.lineEdit.textChanged.connect(self.filter_community_books)
        # ===== Reader_page =====
        self.xuat_excel.clicked.connect(self.export_excel)
        self.load_students()
        self.lineEdit.textChanged.connect(self.search_students)
        self.them_reader.clicked.connect(self.add_reader)
        self.filter.clicked.connect(self.filter_students)
    def switch_page(self, index, button):
        self.stackedWidget.setCurrentIndex(index)
        # reset style tất cả button
        buttons = [
            self.pushButton_2,
            self.pushButton_7,
            self.pushButton_9,
            self.pushButton_8,
            self.pushButton_10
        ]
        for btn in buttons:
            btn.setStyleSheet("""
                QPushButton{
                    background: transparent;
                    border: none;
                    padding: 10px;
                    text-align: left;
                }
            """)
        # button đang chọn
        button.setStyleSheet("""
            QPushButton{
                background-color: #E8F1FD;
                border-left: 4px solid #079DD9;
                padding: 10px;
                text-align: left;
                font-weight: bold;
            }
        """)

    def filter_community_books(self, text):
        keyword = text.lower().strip()
        for card in self.community_cards:
            title = card.book["title"].lower()
            category = card.book["category"].lower()
            owner = card.book.get("owner_name", "").lower()
            if (keyword in title or
                    keyword in category or
                    keyword in owner):
                card.show()
            else:
                card.hide()

    def load_community_books(self):
        with open("data/users.json", "r", encoding="utf-8") as f:
            users = json.load(f)["users"]
        user_map = {u["id"]: u["name"] for u in users}
        with open("data/community_books.json", "r", encoding="utf-8") as f:
            books = json.load(f)["community_books"]
        self.community_cards = []
        for b in books:
            b["owner_name"] = user_map.get(b["owner"], b["owner"])
        layout = self.ver
        while layout.count():
            item = layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
            elif item.layout():
                while item.layout().count():
                    child = item.layout().takeAt(0)
                    if child.widget():
                        child.widget().deleteLater()
        layout.setSpacing(20)
        row_layout = None
        for i, book in enumerate(books):
            if i % 2 == 0:
                row_layout = QHBoxLayout()
                row_layout.setSpacing(20)
                layout.addLayout(row_layout)
            card = CommunityCard(book)
            self.community_cards.append(card)
            row_layout.addWidget(card)

    # ================= DASHBOARD CARDS =================

    def load_dashboard_cards(self):
        with open("data/books.json", "r", encoding="utf-8") as f:
            books = json.load(f)["books"]

        with open("data/students.json", "r", encoding="utf-8") as f:
            students = json.load(f)["students"]

        with open("data/borrow_record.json", "r", encoding="utf-8") as f:
            records = json.load(f)["borrow_record"]

        total_books = len(books)
        total_students = len(students)
        borrowing = sum(1 for r in records if r["status"] == "borrowing")
        overdue = sum(1 for r in records if r["status"] == "overdue")

        # ----- GÁN LÊN CARD -----
        # ĐỔI TÊN QLabel cho khớp với index_ui.py
        self.label_6.setText(str(total_books))
        self.label_25.setText(str(total_students))
        self.label_24.setText(str(borrowing))
        self.label_23.setText(str(overdue))

    def load_dashboard_lists(self):
        self.clear_layout(self.layoutTopReaders)
        self.clear_layout(self.layoutTopBooks)
        self.clear_layout(self.layoutRecentActivity)
        with open("data/students.json", "r", encoding="utf-8") as f:
            students = json.load(f)["students"]
        with open("data/books.json", "r", encoding="utf-8") as f:
            books = json.load(f)["books"]
        with open("data/borrow_record.json", "r", encoding="utf-8") as f:
            records = json.load(f)["borrow_record"]
        student = {s["id"]: s["name"] for s in students}
        book = {}
        for b in books:
            book[b["id"]] = b["title"]
        with open("data/community_books.json", "r", encoding="utf-8") as f:
            community_books = json.load(f)["community_books"]
        for b in community_books:
            book[b["id"]] = b["title"]
        # clear layout
        self.layoutTopReaders.parentWidget().setStyleSheet("background: transparent;")
        self.layoutTopBooks.parentWidget().setStyleSheet("background: transparent;")
        self.layoutRecentActivity.parentWidget().setStyleSheet("background: transparent;")
        # ===== TOP READERS =====
        reader_count = {}
        for r in records:
            sid = r["student_id"]
            reader_count[sid] = reader_count.get(sid, 0) + 1
        top_readers = sorted(reader_count.items(), key=lambda x: x[1], reverse=True)[:3]
        for sid, count in top_readers:
            name = student.get(sid, sid)
            label = QLabel(f"{name} — mượn {count} lượt ")
            label.setWordWrap(True)
            label.setStyleSheet("""
            QLabel{
            border:1px solid #E5E7EB;
            border-radius:8px;
            padding:6px;
            background:white;
            }
            """)
            self.layoutTopReaders.addWidget(label)
        # ===== TOP BOOKS =====
        book_count = {}
        for r in records:
            bid = r["book_id"]
            book_count[bid] = book_count.get(bid, 0) + 1
        top_books = sorted(book_count.items(), key=lambda x: x[1], reverse=True)[:3]
        for bid, count in top_books:
            title = book.get(bid)
            if not title:
                title = "Không có dữ liệu"
            label = QLabel(f"{title} — {count} lượt mượn")
            label.setWordWrap(True)
            label.setStyleSheet("""
            QLabel{
            border:1px solid #E5E7EB;
            border-radius:8px;
            padding:6px;
            background:white;
            }
            """)
            self.layoutTopBooks.addWidget(label)
        # ===== RECENT ACTIVITY =====
        recent = sorted(records, key=lambda x: x["borrow_date"], reverse=True)[:3]
        for r in recent:
            name = student.get(r["student_id"], r["student_id"])
            title = book.get(r["book_id"], r["book_id"])
            label = QLabel(f"{name} mượn '{title}'")
            label.setWordWrap(True)
            label.setStyleSheet("""
            QLabel{
            border:1px solid #E5E7EB;
            border-radius:8px;
            padding:6px;
            background:white;
            }
            """)
            self.layoutRecentActivity.addWidget(label)
    # ================= READERS PAGE =================
    def load_students(self):
        with open("data/students.json", "r", encoding="utf-8") as f:
            students = json.load(f)["students"]
        headers = ["ID", "Họ tên", "Email", "MSSV",
                   "Ngành", "Ngày tham gia", "Trạng thái"]
        self.tableReaders.setColumnCount(len(headers))
        self.tableReaders.setHorizontalHeaderLabels(headers)
        self.tableReaders.setRowCount(len(students))
        status_map = {
            "active": "Hoạt động",
            "inactive": "Tạm khóa"
        }
        for row, student in enumerate(students):
            values = [
                student["id"],
                student["name"],
                student["email"],
                student["mssv"],
                student["major"],
                student["join_date"],
                status_map.get(student["status"], student["status"])
            ]
            for col, value in enumerate(values):
                item = QTableWidgetItem(str(value))
                if col == 6:
                    if value == "Hoạt động":
                        item.setBackground(QColor(150, 255, 150))
                    else:
                        item.setBackground(QColor(255, 150, 150))
                self.tableReaders.setItem(row, col, item)
        header = self.tableReaders.horizontalHeader()
        header.setSectionResizeMode(0, QHeaderView.ResizeToContents)
        header.setSectionResizeMode(1, QHeaderView.Stretch)
        header.setSectionResizeMode(2, QHeaderView.Stretch)
        header.setSectionResizeMode(3, QHeaderView.ResizeToContents)
        header.setSectionResizeMode(4, QHeaderView.Stretch)
        header.setSectionResizeMode(5, QHeaderView.ResizeToContents)
        header.setSectionResizeMode(6, QHeaderView.ResizeToContents)
        self.tableReaders.verticalHeader().setDefaultSectionSize(40)

    def search_students(self, text):
        for row in range(self.tableReaders.rowCount()):
            match = False
            for col in range(self.tableReaders.columnCount()):
                item = self.tableReaders.item(row, col)
                if text.lower() in item.text().lower():
                    match = True
                    break
            self.tableReaders.setRowHidden(row, not match)

    def add_reader(self):
        dialog = QDialog(self)
        dialog.setWindowTitle("Thêm độc giả")
        layout = QVBoxLayout()

        name_input = QLineEdit()
        name_input.setPlaceholderText("Họ tên")

        email_input = QLineEdit()
        email_input.setPlaceholderText("Email")

        mssv_input = QLineEdit()
        mssv_input.setPlaceholderText("MSSV")

        major_input = QLineEdit()
        major_input.setPlaceholderText("Ngành")

        join_input = QLineEdit()
        join_input.setPlaceholderText("Ngày tham gia (dd/mm/yyyy)")

        status_input = QComboBox()
        status_input.addItems(["Hoạt động", "Đình chỉ"])

        btn_save = QPushButton("Lưu")

        layout.addWidget(name_input)
        layout.addWidget(email_input)
        layout.addWidget(mssv_input)
        layout.addWidget(major_input)
        layout.addWidget(join_input)
        layout.addWidget(status_input)
        layout.addWidget(btn_save)

        dialog.setLayout(layout)

        def save_data():
            mssv = mssv_input.text().strip().upper()
            name = name_input.text().strip().title()
            email = email_input.text().strip().lower()

            if not name or not email or not mssv or not join_input.text():
                QMessageBox.warning(self, "Lỗi", "Vui lòng nhập đủ thông tin")
                return

            with open("data/students.json", "r", encoding="utf-8") as f:
                json_data = json.load(f)

            students = json_data["students"]

            for s in students:
                if s["mssv"] == mssv:
                    QMessageBox.warning(
                        self,
                        "Trùng MSSV",
                        f"MSSV {mssv} đã tồn tại\nSinh viên {s['name']} - Ngành {s['major']}"
                    )
                    return

            new_id = f"DG{len(students) + 1:02d}"

            new_student = {
                "id": new_id,
                "name": name,
                "email": email,
                "mssv": mssv,
                "major": major_input.text(),
                "join_date": join_input.text(),
                "status": "active" if status_input.currentText() == "Hoạt động" else "inactive"
            }

            students.append(new_student)

            with open("data/students.json", "w", encoding="utf-8") as f:
                json.dump(json_data, f, ensure_ascii=False, indent=4)

            self.load_students()
            self.load_transfer_data()

            QMessageBox.information(self, "Thành công", "Đã thêm độc giả mới")
            dialog.accept()

        btn_save.clicked.connect(save_data)
        dialog.exec()
    def filter_students(self):
        with open("data/students.json", "r", encoding="utf-8") as f:
            students = json.load(f)["students"]
        status_filter = "Hoạt động"

        filtered = [s for s in students if s["status"] == status_filter]

        self.tableReaders.setRowCount(len(filtered))

        for row, student in enumerate(filtered):
            self.tableReaders.setItem(row, 0, QTableWidgetItem(student["name"]))
            self.tableReaders.setItem(row, 1, QTableWidgetItem(student["id"]))
            self.tableReaders.setItem(row, 2, QTableWidgetItem(student["major"]))
            self.tableReaders.setItem(row, 3, QTableWidgetItem(student["join_date"]))
            self.tableReaders.setItem(row, 4, QTableWidgetItem(student["status"]))
    def export_excel(self):
        with open("data/students.json", "r", encoding="utf-8") as f:
            students = json.load(f)["students"]

        workbook = xlsxwriter.Workbook("data/readers.xlsx")
        worksheet = workbook.add_worksheet("Readers")

        headers = ["ID", "Họ tên", "Email", "MSSV", "Ngành", "Ngày tham gia", "Trạng thái"]

        for col, header in enumerate(headers):
            worksheet.write(0, col, header)

        for row, student in enumerate(students, start=1):
            worksheet.write(row, 0, student["id"])
            worksheet.write(row, 1, student["name"])
            worksheet.write(row, 2, student["email"])
            worksheet.write(row, 3, student["mssv"])
            worksheet.write(row, 4, student["major"])
            worksheet.write(row, 5, student["join_date"])
            worksheet.write(row, 6, student["status"])

        workbook.close()

        QMessageBox.information(self, "Thành công", "Xuất Excel thành công!")
    # ================= TRANSFER TABLE =================

    def load_transfer_data(self):
        with open("data/students.json", "r", encoding="utf-8") as f:
            students = json.load(f)["students"]
        student = {s["id"]: s["name"] for s in students}

        with open("data/books.json", "r", encoding="utf-8") as f:
            books = json.load(f)["books"]
        with open("data/community_books.json", "r", encoding="utf-8") as f:
            community_books = json.load(f)["community_books"]
        book = {}
        for b in books:
            book[b["id"]] = b["title"]
        for b in community_books:
            book[b["id"]] = b["title"]
        with open("data/borrow_record.json", "r", encoding="utf-8") as f:
            records = json.load(f)["borrow_record"]
        status = {
            'borrowing': 'Đang mượn',
            'overdue': 'Quá hạn',
            'returned': 'Đã trả'
        }
        headers = ["ID", "Độc giả", "Tên sách", "Ngày mượn", "Hạn trả", "Trạng thái"]
        self.transferTable.setColumnCount(len(headers))
        self.transferTable.setHorizontalHeaderLabels(headers)
        self.transferTable.setRowCount(len(records))
        for row, record in enumerate(records):
            values = [
                record["id"],
                student.get(record["student_id"], record["student_id"]),
                book.get(record["book_id"], record["book_id"]),
                record["borrow_date"],
                record["due_date"],
                status.get(record["status"], record["status"])
            ]
            for col, value in enumerate(values):
                item = QTableWidgetItem(str(value))

                if col == 5:
                    if value == "Đang mượn":
                        item.setBackground(QColor(255, 255, 150))
                    elif value == "Quá hạn":
                        item.setBackground(QColor(255, 150, 150))
                    elif value == "Đã trả":
                        item.setBackground(QColor(150, 255, 150))
                self.transferTable.setItem(row, col, item)
        header = self.transferTable.horizontalHeader()
        header.setStretchLastSection(True)
        header.setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.transferTable.verticalHeader().setDefaultSectionSize(40)

    # ================= SEARCH =================

    def search_table(self, text):
        for row in range(self.transferTable.rowCount()):
            match = False
            for col in range(self.transferTable.columnCount()):
                item = self.transferTable.item(row, col)
                if text.lower() in item.text().lower():
                    match = True
                    break
            self.transferTable.setRowHidden(row, not match)

    # ================= CHART LAYOUT =================

    def init_chart_layout(self):
        # LẤY LAYOUT CÓ SẴN TỪ QT DESIGNER (KHÔNG TẠO MỚI)
        self.bar_layout = self.ch_left.layout()
        self.line_layout = self.ch_right.layout()

        # BẢO VỆ TRƯỜNG HỢP QUÊN SET LAYOUT
        if self.bar_layout is None:
            self.bar_layout = QVBoxLayout(self.ch_left)
        if self.line_layout is None:
            self.line_layout = QVBoxLayout(self.ch_right)

    def clear_layout(self, layout):
        while layout.count():
            item = layout.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.deleteLater()
    # ================= BAR CHART =================

    def draw_bar_chart(self):

        with open("data/borrow_record.json", "r", encoding="utf-8") as f:
            records = json.load(f)["borrow_record"]

        # Đếm lượt mượn
        book_count = {}

        for r in records:
            bid = r["book_id"]
            book_count[bid] = book_count.get(bid, 0) + 1

        # Top 5 sách
        top_books = sorted(book_count.items(), key=lambda x: x[1], reverse=True)[:5]

        labels = [bid for bid, _ in top_books]
        values = [count for _, count in top_books]

        self.clear_layout(self.bar_layout)

        fig = Figure(figsize=(6,4))
        canvas = FigureCanvas(fig)

        ax = fig.add_subplot(111)

        bars = ax.bar(labels, values, color="#4C72B0", width=0.6)

        # Title đẹp hơn
        ax.set_title("Top sách được mượn nhiều nhất", fontsize=12, fontweight="normal", color="#444")

        ax.set_ylabel("Số lượt mượn", fontsize=10)

        ax.set_xticklabels(labels, rotation=25, ha="right")

        # Grid nhẹ hơn
        ax.grid(axis="y", linestyle="--", alpha=0.3)

        # Ẩn viền thừa
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)

        # Hiển thị số trên đầu mỗi cột
        for bar in bars:
            height = bar.get_height()
            ax.text(
                bar.get_x() + bar.get_width()/2,
                height + 0.05,
                int(height),
                ha='center',
                va='bottom',
                fontsize=9
            )

        fig.subplots_adjust(left=0.22, bottom=0.30)

        canvas.draw()

        self.bar_layout.addWidget(canvas)



    # ================= LINE CHART =================

    def draw_line_chart(self):

        with open("data/borrow_record.json", "r", encoding="utf-8") as f:
            records = json.load(f)["borrow_record"]

        with open("data/students.json", "r", encoding="utf-8") as f:
            students = json.load(f)["students"]

        student_map = {s["id"]: s["name"] for s in students}

        user_count = {}

        for r in records:
            sid = r["student_id"]
            user_count[sid] = user_count.get(sid, 0) + 1

        top_users = sorted(user_count.items(), key=lambda x: x[1], reverse=True)[:5]

        labels = [student_map.get(sid, sid) for sid, _ in top_users]
        values = [count for _, count in top_users]

        self.clear_layout(self.line_layout)

        fig = Figure(figsize=(6,4))
        canvas = FigureCanvas(fig)

        ax = fig.add_subplot(111)

        ax.plot(
            labels,
            values,
            marker="o",
            linewidth=2.5,
            markersize=7,
            color="#DD8452"
        )

        ax.set_title("Top người dùng mượn nhiều sách", fontsize=12, fontweight="normal", color="#444")

        ax.set_ylabel("Số lượt mượn", fontsize=10)

        ax.set_xticklabels(labels, rotation=25, ha="right")

        ax.grid(True, linestyle="--", alpha=0.3)

        # Ẩn viền
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)

        # Hiển thị số trên mỗi điểm
        for i, v in enumerate(values):
            ax.text(i, v + 0.05, str(v), ha="center", fontsize=9)

        fig.subplots_adjust(left=0.22, bottom=0.30)

        canvas.draw()

        self.line_layout.addWidget(canvas)
    # ================= AUTO REFRESH =================

    def refresh_dashboard(self):
        self.load_dashboard_cards()
        self.load_dashboard_lists()
    
#################PVy######################
    def load_books(self):
        with open("data/books.json", "r", encoding="utf-8") as f:
            books = json.load(f)["books"]
        layout = self.scrollAreaWidgetContents.layout()
        if layout is None:
            layout = QVBoxLayout(self.scrollAreaWidgetContents)
            self.scrollAreaWidgetContents.setLayout(layout)
        # Xóa item cũ
        while layout.count():
            child = layout.takeAt(0)
            if child.widget():
                child.widget().deleteLater()
        # Thêm item mới
        for book in books:
            item = bookItem(book)
            layout.addWidget(item)
        layout.addStretch()

class bookItem(QWidget):
    def __init__(self, book_data):
        super().__init__()
        self.setFixedHeight(120)
        self.setStyleSheet("""
            QWidget {
                background-color: white;
                border-radius: 10px;
            }
        """)
        main_layout = QHBoxLayout(self)
        main_layout.setContentsMargins(15, 10, 15, 10)
        main_layout.setSpacing(15)
        # ===== ẢNH =====
        self.image_label = QLabel()
        self.image_label.setFixedSize(80, 100)
        base_dir = os.path.dirname(os.path.abspath(__file__))
        image_path = os.path.join(base_dir, book_data.get("image", ""))
        print("Loading:", image_path)  # debug
        if os.path.exists(image_path) and book_data.get("image"):
            pixmap = QPixmap(image_path)
            if not pixmap.isNull():
                self.image_label.setPixmap(
                    pixmap.scaled(80, 100, Qt.KeepAspectRatio, Qt.SmoothTransformation)
                )
            else:
                self.image_label.setText("Invalid Image")
                self.image_label.setAlignment(Qt.AlignCenter)
        else:
            self.image_label.setText("No Image")
            self.image_label.setAlignment(Qt.AlignCenter)
        # ===== INFO =====
        info_layout = QVBoxLayout()
        info_layout.setSpacing(5)
        self.title = QLabel(book_data.get("title", "Unknown Title"))
        self.title.setStyleSheet("font-weight: bold; font-size: 14px;")
        self.author = QLabel("Author: " + book_data.get("author", "Unknown"))
        self.category = QLabel("Category: " + book_data.get("category", "Unknown"))
        # ===== STOCK INFO =====
        total_quantity = int(book_data.get("total_quantity", 0))
        available_quantity = int(book_data.get("available_quantity", 0))
        rate = float(book_data.get("rate", 0))
        self.total_label = QLabel(f"Total: {total_quantity}")
        self.available_label = QLabel(f"Available: {available_quantity}")
        self.rate_label = QLabel(f"Rating: {rate}")
        info_layout.addWidget(self.title)
        info_layout.addWidget(self.author)
        info_layout.addWidget(self.category)
        info_layout.addWidget(self.total_label)
        info_layout.addWidget(self.available_label)
        info_layout.addWidget(self.rate_label)
        main_layout.addWidget(self.image_label)
        main_layout.addLayout(info_layout)
#PHƯƠNG
# ================= COMMUNITY PAGE =================
class CommunityCard(QWidget):
    def __init__(self, book):
        super().__init__()
        self.book = book
        self.cancel_time = None
        self.setMinimumHeight(180)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        self.setStyleSheet("""
        QWidget{
            background: #F8FAFC;          
            border-radius:14px;
            border:1px solid #E5E7EB;
        }
        QPushButton{
            background-color: #079DD9;
            color: white;
            border-radius: 10px;
            padding: 8px 16px;
            font-weight: bold;
        }
        QPushButton:hover{
            background:#99D9F2;          
        }
        QPushButton:pressed {
            background-color: #80BDF2;
        }   
        QPushButton:disabled{
            background:#BDBDBD;          
        }
        """)
        main_layout = QHBoxLayout(self)
        main_layout.setContentsMargins(15,15,15,15)
        main_layout.setSpacing(15)
        img = QLabel()
        img.setFixedSize(100,140)
        base = os.path.dirname(os.path.abspath(__file__))
        path = os.path.join(base, book.get("image", ""))
        if os.path.exists(path):
            pix = QPixmap(path)
            img.setPixmap(pix.scaled(100, 140, Qt.KeepAspectRatio, Qt.SmoothTransformation))
        else:
            img.setText("Chưa có dữ liệu")
            img.setAlignment(Qt.AlignCenter)
        main_layout.addWidget(img)
        info_layout = QVBoxLayout()
        info_layout.setSpacing(6)
        category = QLabel(book["category"])
        category.setStyleSheet("""
                    background:#E8F1FD;             
                    padding:3px 8px;
                    border-radius:8px;
                    font-size:11px;
                """)
        title = QLabel(book["title"])
        title.setWordWrap(True)
        title.setStyleSheet("font-weight:700; font-size:14px;")
        owner = QLabel(f"Chủ sách: {book.get('owner_name', book['owner'])}")
        owner.setStyleSheet("color:#6B7280; font-size:12px;")
        info_layout.addWidget(category)
        info_layout.addWidget(title)
        info_layout.addWidget(owner)
        bottom_layout = QHBoxLayout()
        status_map = {
            "available": ("Còn sẵn", "#27AE60"),
            "requested": ("Đang yêu cầu", "#F2C94C"),
            "borrowed": ("Tạm hết", "#EB5757")
        }
        text, color = status_map.get(book["status"], ("?", "#999"))
        self.status_label = QLabel(text)
        self.status_label.setStyleSheet(f"""
            background:{color};
            color:white;
            padding:4px 10px;
            border-radius:8px;
            font-size:11px;
        """)
        self.borrow_btn = QPushButton("Mượn ngay")
        self.borrow_btn.setEnabled(book["status"] == "available")
        self.borrow_btn.clicked.connect(self.borrow_clicked)
        # ===== NÚT HỦY =====
        self.cancel_btn = QPushButton("Huỷ mượn")
        self.cancel_btn.setStyleSheet("""
            QPushButton {
                background-color: #EB5757;
                color: white;
                border-radius: 10px;
                padding: 8px 16px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #FF7B7B;   
            }
            QPushButton:pressed {
                background-color: #C0392B;   
            }
        """)
        self.cancel_btn.clicked.connect(self.cancel_request)
        self.cancel_btn.hide()
        bottom_layout.addWidget(self.status_label)
        bottom_layout.addStretch()
        bottom_layout.addWidget(self.borrow_btn)
        bottom_layout.addWidget(self.cancel_btn)
        info_layout.addLayout(bottom_layout)
        main_layout.addLayout(info_layout)

    def borrow_clicked(self):
        #Nếu đang ở trạng thái requested
        if self.book["status"] == "requested":
            QMessageBox.information(
                self,
                "Thông báo",
                "Bạn đã gửi yêu cầu rồi."
            )
            return
        #Nếu vừa huỷ
        if self.cancel_time:
            if datetime.now() - self.cancel_time < timedelta(hours=24):
                QMessageBox.warning(
                    self,
                    "Không thể mượn",
                    "Bạn vừa huỷ yêu cầu.\nTrong 24 giờ không được mượn lại."
                )
                return
        #Cho phép gửi yêu cầu
        QMessageBox.information(
            self,
            "Mượn sách",
            f"Bạn đã gửi yêu cầu mượn:\n{self.book['title']}"
        )
        self.book["status"] = "requested"
        self.status_label.setText("Đang yêu cầu")
        self.status_label.setStyleSheet("""
            background:#F2C94C;
            color:white;
            padding:4px 10px;
            border-radius:8px;
            font-size:11px;
        """)
        self.cancel_btn.show()
    def cancel_request(self):
        reply = QMessageBox.question(
            self,
            "Xác nhận huỷ",
            "Bạn có chắc chắn huỷ?\nSau 24 giờ mới được yêu cầu lại.",
            QMessageBox.Ok | QMessageBox.Cancel
        )

        if reply == QMessageBox.Ok:
            self.book["status"] = "available"
            self.status_label.setText("Còn sẵn")
            self.status_label.setStyleSheet("""
                background:#27AE60;
                color:white;
                padding:4px 10px;
                border-radius:8px;
                font-size:11px;
            """)
            self.cancel_time = datetime.now()
            self.cancel_btn.hide()
        else:
            return


