# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'login.ui'
##
## Created by: Qt User Interface Compiler version 6.10.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QComboBox, QLabel, QLineEdit,
    QMainWindow, QPushButton, QSizePolicy, QWidget)

class Ui_LoginWindow(object):
    def setupUi(self, LoginWindow):
        if not LoginWindow.objectName():
            LoginWindow.setObjectName(u"LoginWindow")
        LoginWindow.resize(900, 650)
        self.centralwidget = QWidget(LoginWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.leftPanel = QWidget(self.centralwidget)
        self.leftPanel.setObjectName(u"leftPanel")
        self.leftPanel.setGeometry(QRect(0, 0, 420, 650))
        self.leftPanel.setStyleSheet(u"background-color: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #6b3fa0, stop:0.5 #7c4daa, stop:1 #9b6fc4);")
        self.Icon = QLabel(self.leftPanel)
        self.Icon.setObjectName(u"Icon")
        self.Icon.setGeometry(QRect(150, 240, 110, 90))
        self.Icon.setStyleSheet(u"color: white; font-size: 64px; background: transparent;")
        self.Icon.setAlignment(Qt.AlignCenter)
        self.ten_he_thong = QLabel(self.leftPanel)
        self.ten_he_thong.setObjectName(u"ten_he_thong")
        self.ten_he_thong.setGeometry(QRect(30, 320, 360, 65))
        self.ten_he_thong.setStyleSheet(u"color: white; font-size: 20px; font-weight: bold; background: transparent;")
        self.ten_he_thong.setAlignment(Qt.AlignCenter)
        self.ten_he_thong.setWordWrap(True)
        self.chu_thich = QLabel(self.leftPanel)
        self.chu_thich.setObjectName(u"chu_thich")
        self.chu_thich.setGeometry(QRect(40, 390, 340, 60))
        self.chu_thich.setStyleSheet(u"color: rgba(255,255,255,166); font-size: 12px; background: transparent;")
        self.chu_thich.setAlignment(Qt.AlignCenter)
        self.chu_thich.setWordWrap(True)
        self.nhom_4 = QLabel(self.leftPanel)
        self.nhom_4.setObjectName(u"nhom_4")
        self.nhom_4.setGeometry(QRect(30, 150, 360, 65))
        self.nhom_4.setStyleSheet(u"color: white; font-size: 20px; font-weight: bold; background: transparent;")
        self.nhom_4.setAlignment(Qt.AlignCenter)
        self.nhom_4.setWordWrap(True)
        self.rightPanel = QWidget(self.centralwidget)
        self.rightPanel.setObjectName(u"rightPanel")
        self.rightPanel.setGeometry(QRect(420, 0, 480, 650))
        self.rightPanel.setStyleSheet(u"background-color: white;")
        self.lblLoginTitle = QLabel(self.rightPanel)
        self.lblLoginTitle.setObjectName(u"lblLoginTitle")
        self.lblLoginTitle.setGeometry(QRect(55, 160, 370, 42))
        self.lblLoginTitle.setStyleSheet(u"font-size: 26px; font-weight: bold; color: #6b3fa0; background: transparent;")
        self.lblLoginSub = QLabel(self.rightPanel)
        self.lblLoginSub.setObjectName(u"lblLoginSub")
        self.lblLoginSub.setGeometry(QRect(55, 204, 370, 22))
        self.lblLoginSub.setStyleSheet(u"font-size: 13px; color: #6b7280; background: transparent;")
        self.lblRole = QLabel(self.rightPanel)
        self.lblRole.setObjectName(u"lblRole")
        self.lblRole.setGeometry(QRect(55, 240, 370, 18))
        self.lblRole.setStyleSheet(u"font-size: 12px; font-weight: bold; color: #374151; background: transparent;")
        self.chon_role = QComboBox(self.rightPanel)
        self.chon_role.addItem("")
        self.chon_role.addItem("")
        self.chon_role.setObjectName(u"chon_role")
        self.chon_role.setGeometry(QRect(55, 262, 370, 40))
        self.chon_role.setStyleSheet(u"QComboBox {\n"
"    border: 1.5px solid #d1d5db; border-radius: 8px;\n"
"    padding: 6px 12px; font-size: 13px; color: #374151; background: white;\n"
"}\n"
"QComboBox:focus { border-color: #9b6fc4; }\n"
"QComboBox::drop-down { border: none; width: 30px; }\n"
"QComboBox QAbstractItemView {\n"
"    background: white; color: #374151;\n"
"    selection-background-color: #ede4f7; selection-color: #6b3fa0;\n"
"    border: 1px solid #e5e7eb;\n"
"}")
        self.lblEmail = QLabel(self.rightPanel)
        self.lblEmail.setObjectName(u"lblEmail")
        self.lblEmail.setGeometry(QRect(55, 316, 370, 18))
        self.lblEmail.setStyleSheet(u"font-size: 12px; font-weight: bold; color: #374151; background: transparent;")
        self.nhap_id = QLineEdit(self.rightPanel)
        self.nhap_id.setObjectName(u"nhap_id")
        self.nhap_id.setGeometry(QRect(55, 338, 370, 42))
        self.nhap_id.setStyleSheet(u"QLineEdit {\n"
"    border: 1.5px solid #d1d5db; border-radius: 8px;\n"
"    padding: 8px 14px; font-size: 13px; color: #374151; background: #f9fafb;\n"
"}\n"
"QLineEdit:focus { border-color: #9b6fc4; background: white; }")
        self.lblPassword = QLabel(self.rightPanel)
        self.lblPassword.setObjectName(u"lblPassword")
        self.lblPassword.setGeometry(QRect(55, 394, 370, 18))
        self.lblPassword.setStyleSheet(u"font-size: 12px; font-weight: bold; color: #374151; background: transparent;")
        self.nhap_mk = QLineEdit(self.rightPanel)
        self.nhap_mk.setObjectName(u"nhap_mk")
        self.nhap_mk.setGeometry(QRect(55, 416, 370, 42))
        self.nhap_mk.setStyleSheet(u"QLineEdit {\n"
"    border: 1.5px solid #d1d5db; border-radius: 8px;\n"
"    padding: 8px 14px; font-size: 13px; color: #374151; background: #f9fafb;\n"
"}\n"
"QLineEdit:focus { border-color: #9b6fc4; background: white; }")
        self.nhap_mk.setEchoMode(QLineEdit.Password)
        self.lblError = QLabel(self.rightPanel)
        self.lblError.setObjectName(u"lblError")
        self.lblError.setGeometry(QRect(55, 466, 370, 22))
        self.lblError.setStyleSheet(u"color: #ef4444; font-size: 12px; background: transparent;")
        self.dang_nhap = QPushButton(self.rightPanel)
        self.dang_nhap.setObjectName(u"dang_nhap")
        self.dang_nhap.setGeometry(QRect(55, 495, 370, 48))
        self.dang_nhap.setStyleSheet(u"QPushButton {\n"
"    background-color: #6b3fa0; color: white; border-radius: 10px;\n"
"    font-size: 14px; font-weight: bold; border: none;\n"
"}\n"
"QPushButton:hover { background-color: #9b6fc4; }\n"
"QPushButton:pressed { background-color: #5e2d8a; }\n"
"QPushButton:disabled { background-color: #d4afe8; }")
        LoginWindow.setCentralWidget(self.centralwidget)

        self.retranslateUi(LoginWindow)

        QMetaObject.connectSlotsByName(LoginWindow)
    # setupUi

    def retranslateUi(self, LoginWindow):
        LoginWindow.setWindowTitle(QCoreApplication.translate("LoginWindow", u"\u0110\u0103ng Nh\u1eadp - UEL Library", None))
        self.Icon.setText(QCoreApplication.translate("LoginWindow", u"\U0001f4da", None))
        self.ten_he_thong.setText(QCoreApplication.translate("LoginWindow", u"H\u1ec6 TH\u1ed0NG QU\u1ea2N L\u00dd TH\u01af VI\u1ec6N UEL", None))
        self.chu_thich.setText(QCoreApplication.translate("LoginWindow", u"<html><head/><body><p><span style=\" font-size:12pt;\">Qu\u1ea3n l\u00fd s\u00e1ch, sinh vi\u00ean v\u00e0 l\u01b0\u1ee3t m\u01b0\u1ee3n tr\u1ea3 m\u1ed9t c\u00e1ch hi\u1ec7u qu\u1ea3 v\u00e0 ti\u1ec7n l\u1ee3i</span></p></body></html>", None))
        self.nhom_4.setText(QCoreApplication.translate("LoginWindow", u"<html><head/><body><p><span style=\" font-size:22pt;\">NH\u00d3M 4</span></p></body></html>", None))
        self.lblLoginTitle.setText(QCoreApplication.translate("LoginWindow", u"\u0110\u0103ng Nh\u1eadp", None))
        self.lblLoginSub.setText(QCoreApplication.translate("LoginWindow", u"Ch\u00e0o m\u1eebng b\u1ea1n tr\u1edf l\u1ea1i h\u1ec7 th\u1ed1ng!", None))
        self.lblRole.setText(QCoreApplication.translate("LoginWindow", u"Vai tr\u00f2", None))
        self.chon_role.setItemText(0, QCoreApplication.translate("LoginWindow", u"\U0001f468\U0000200d\U0001f4bc  Qu\U00001ea3n Tr\U00001ecb Vi\U000000ean (Admin)", None))
        self.chon_role.setItemText(1, QCoreApplication.translate("LoginWindow", u"\U0001f393  \U00000110\U00001ed9c Gi\U00001ea3 (Student)", None))

        self.lblEmail.setText(QCoreApplication.translate("LoginWindow", u"Email / ID", None))
        self.nhap_id.setPlaceholderText(QCoreApplication.translate("LoginWindow", u"Nh\u1eadp email ho\u1eb7c ID c\u1ee7a b\u1ea1n...", None))
        self.lblPassword.setText(QCoreApplication.translate("LoginWindow", u"M\u1eadt kh\u1ea9u", None))
        self.nhap_mk.setPlaceholderText(QCoreApplication.translate("LoginWindow", u"Nh\u1eadp m\u1eadt kh\u1ea9u...", None))
        self.lblError.setText("")
        self.dang_nhap.setText(QCoreApplication.translate("LoginWindow", u"\u0110\u0102NG NH\u1eacP", None))
    # retranslateUi

