import json
import os

from PySide6.QtWidgets import QMainWindow, QMessageBox
from login_ui import Ui_LoginWindow


class LoginWindow(QMainWindow):
    def __init__(self, main_window_class):
        super().__init__()
        self.ui = Ui_LoginWindow()
        self.ui.setupUi(self)

        self.MainWindowClass = main_window_class
        self.USERS_JSON = os.path.join(
            os.path.dirname(os.path.abspath(__file__)), "data", "users.json"
        )

    
        self.ui.dang_nhap.clicked.connect(self.log_in)
        self.ui.nhap_id.returnPressed.connect(self.log_in)
        self.ui.nhap_mk.returnPressed.connect(self.log_in)
        self.ui.pushButton.clicked.connect(self.tao_tai_khoan)
        self.ui.pushButton_2.clicked.connect(self.quen_mat_khau)

    #Đọc danh sách user
    def read_data(self):
        try:
            with open(self.USERS_JSON, "r", encoding="utf-8") as f:
                return json.load(f).get("users", [])
        except Exception as e:
            print(f"[AUTH] Không đọc được users.json: {e}")
            return []

    #Xác thực tài khoản 
    def xac_thuc(self, email_or_id: str, password: str):
        key = email_or_id.strip().lower()
        for u in self.read_data():
            # Hỗ trợ cả typo "emal" trong JSON cũ
            email = (u.get("email") or u.get("emal") or "").lower()
            uid   = u.get("id", "").lower()
            if key not in (email, uid):
                continue
            if u.get("password") != password:
                continue
            if u.get("role") != "student":
                return None, "Tài khoản không có quyền truy cập hệ thống này!"
            if u.get("status") == "inactive":
                return None, "Tài khoản đã bị vô hiệu hóa!"
            return u, None
        return None, "Email/ID hoặc mật khẩu không đúng!"


    def log_in(self):
        email    = self.ui.nhap_id.text().strip()
        password = self.ui.nhap_mk.text()

        if not email or not password:
            self.ui.lblError.setText("Vui lòng nhập đầy đủ email/ID và mật khẩu!")
            return

        self.ui.dang_nhap.setEnabled(False)
        self.ui.dang_nhap.setText("Đang xác thực...")
        self.ui.lblError.setText("")

        try:
            user, err = self.xac_thuc(email, password)

            if err:
                self.ui.lblError.setText(err)
                return

            self.chuyen_sang_frontPage(user)

        except Exception as e:
            self.ui.lblError.setText(f"Lỗi hệ thống: {e}")
        finally:
            if self.isVisible():
                self.ui.dang_nhap.setEnabled(True)
                self.ui.dang_nhap.setText("ĐĂNG NHẬP")

    #Mở giao diện chính
    def chuyen_sang_frontPage(self, user):
        self._main_win = self.MainWindowClass()
        self._main_win.setWindowTitle(
            f"UEL Library  —  {user.get('name', user.get('id', ''))}"
        )
        self._main_win.show()
        self.close()

    #Tạo tài khoản
    def tao_tai_khoan(self):
        QMessageBox.information(
            self,
            "Tạo tài khoản",
            "Vui lòng liên hệ thủ thư để được cấp tài khoản.\n"
            "📧  library@uel.edu.vn",
        )

    #Quên mật khẩu
    def quen_mat_khau(self):
        QMessageBox.information(
            self,
            "Quên mật khẩu",
            "Vui lòng liên hệ thủ thư để đặt lại mật khẩu.\n"
            "📧  library@uel.edu.vn",
        )
