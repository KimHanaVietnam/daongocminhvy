# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'index.ui'
##
## Created by: Qt User Interface Compiler version 6.10.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QFrame, QGridLayout, QGroupBox,
    QHBoxLayout, QHeaderView, QLabel, QLineEdit,
    QMainWindow, QPushButton, QScrollArea, QSizePolicy,
    QSpacerItem, QStackedWidget, QTableWidget, QTableWidgetItem,
    QTextEdit, QVBoxLayout, QWidget)
import resources_rc

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(1290, 921)
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.icon_text_widget = QWidget(self.centralwidget)
        self.icon_text_widget.setObjectName(u"icon_text_widget")
        self.icon_text_widget.setGeometry(QRect(110, 20, 211, 801))
        self.icon_text_widget.setStyleSheet(u"background-color: rgb(74, 74, 74);")
        self.layoutWidget = QWidget(self.icon_text_widget)
        self.layoutWidget.setObjectName(u"layoutWidget")
        self.layoutWidget.setGeometry(QRect(10, 680, 191, 81))
        self.verticalLayout_2 = QVBoxLayout(self.layoutWidget)
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.verticalLayout_2.setContentsMargins(0, 0, 0, 0)
        self.pushButton_12 = QPushButton(self.layoutWidget)
        self.pushButton_12.setObjectName(u"pushButton_12")
        self.pushButton_12.setStyleSheet(u"QPushButton {\n"
"    background-color: rgb(74, 74, 74);\n"
"    color: white;            \n"
"    border-radius: 10px;\n"
"    padding: 4px 8px;\n"
"    margin: 4px 6px;\n"
"    font-size: 14px;\n"
"    text-align: left;\n"
"    border: none;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: white;\n"
"    color: #000000;\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    background-color: white;\n"
"    color: #000000;\n"
"}")
        icon = QIcon()
        icon.addFile(u":/icons/icons/setting.svg", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.pushButton_12.setIcon(icon)
        self.pushButton_12.setCheckable(True)
        self.pushButton_12.setChecked(False)
        self.pushButton_12.setAutoExclusive(True)

        self.verticalLayout_2.addWidget(self.pushButton_12)

        self.pushButton_11 = QPushButton(self.layoutWidget)
        self.pushButton_11.setObjectName(u"pushButton_11")
        self.pushButton_11.setStyleSheet(u"QPushButton {\n"
"    background-color: rgb(74, 74, 74);\n"
"    color: white;            \n"
"    border-radius: 10px;\n"
"    padding: 4px 8px;\n"
"    margin: 4px 6px;\n"
"    font-size: 14px;\n"
"    text-align: left;\n"
"    border: none;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: white;\n"
"    color: #000000;\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    background-color: white;\n"
"    color: #000000;\n"
"}")
        icon1 = QIcon()
        icon1.addFile(u":/icons/icons/logout.svg", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.pushButton_11.setIcon(icon1)
        self.pushButton_11.setCheckable(True)
        self.pushButton_11.setChecked(False)
        self.pushButton_11.setAutoExclusive(True)

        self.verticalLayout_2.addWidget(self.pushButton_11)

        self.layoutWidget1 = QWidget(self.icon_text_widget)
        self.layoutWidget1.setObjectName(u"layoutWidget1")
        self.layoutWidget1.setGeometry(QRect(10, 130, 191, 231))
        self.verticalLayout = QVBoxLayout(self.layoutWidget1)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.pushButton_2 = QPushButton(self.layoutWidget1)
        self.pushButton_2.setObjectName(u"pushButton_2")
        self.pushButton_2.setStyleSheet(u"QPushButton {\n"
"    background-color: rgb(74, 74, 74);\n"
"    color: white;            \n"
"    border-radius: 10px;\n"
"    padding: 4px 8px;\n"
"    margin: 4px 6px;\n"
"    font-size: 14px;\n"
"    text-align: left;\n"
"    border: none;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: white;\n"
"    color: #000000;\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    background-color: white;\n"
"    color: #000000;\n"
"}")
        icon2 = QIcon()
        icon2.addFile(u":/icons/icons/dashboard.svg", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.pushButton_2.setIcon(icon2)
        self.pushButton_2.setCheckable(True)
        self.pushButton_2.setChecked(False)
        self.pushButton_2.setAutoExclusive(True)

        self.verticalLayout.addWidget(self.pushButton_2)

        self.pushButton_7 = QPushButton(self.layoutWidget1)
        self.pushButton_7.setObjectName(u"pushButton_7")
        self.pushButton_7.setStyleSheet(u"QPushButton {\n"
"    background-color: rgb(74, 74, 74);\n"
"    color: white;            \n"
"    border-radius: 10px;\n"
"    padding: 4px 8px;\n"
"    margin: 4px 6px;\n"
"    font-size: 14px;\n"
"    text-align: left;\n"
"    border: none;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: white;\n"
"    color: #000000;\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    background-color: white;\n"
"    color: #000000;\n"
"}")
        icon3 = QIcon()
        icon3.addFile(u":/icons/icons/books.svg", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.pushButton_7.setIcon(icon3)
        self.pushButton_7.setCheckable(True)
        self.pushButton_7.setChecked(False)
        self.pushButton_7.setAutoExclusive(True)

        self.verticalLayout.addWidget(self.pushButton_7)

        self.pushButton_9 = QPushButton(self.layoutWidget1)
        self.pushButton_9.setObjectName(u"pushButton_9")
        self.pushButton_9.setStyleSheet(u"QPushButton {\n"
"    background-color: rgb(74, 74, 74);\n"
"    color: white;            \n"
"    border-radius: 10px;\n"
"    padding: 4px 8px;\n"
"    margin: 4px 6px;\n"
"    font-size: 14px;\n"
"    text-align: left;\n"
"    border: none;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: white;\n"
"    color: #000000;\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    background-color: white;\n"
"    color: #000000;\n"
"}")
        icon4 = QIcon()
        icon4.addFile(u":/icons/icons/reader.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.pushButton_9.setIcon(icon4)
        self.pushButton_9.setCheckable(True)
        self.pushButton_9.setChecked(False)
        self.pushButton_9.setAutoExclusive(True)

        self.verticalLayout.addWidget(self.pushButton_9)

        self.pushButton_8 = QPushButton(self.layoutWidget1)
        self.pushButton_8.setObjectName(u"pushButton_8")
        self.pushButton_8.setStyleSheet(u"QPushButton {\n"
"    background-color: rgb(74, 74, 74);\n"
"    color: white;            \n"
"    border-radius: 10px;\n"
"    padding: 4px 8px;\n"
"    margin: 4px 6px;\n"
"    font-size: 14px;\n"
"    text-align: left;\n"
"    border: none;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: white;\n"
"    color: #000000;\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    background-color: white;\n"
"    color: #000000;\n"
"}")
        icon5 = QIcon()
        icon5.addFile(u":/icons/icons/transfer.svg", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.pushButton_8.setIcon(icon5)
        self.pushButton_8.setCheckable(True)
        self.pushButton_8.setChecked(False)
        self.pushButton_8.setAutoExclusive(True)

        self.verticalLayout.addWidget(self.pushButton_8)

        self.pushButton_10 = QPushButton(self.layoutWidget1)
        self.pushButton_10.setObjectName(u"pushButton_10")
        self.pushButton_10.setStyleSheet(u"QPushButton {\n"
"    background-color: rgb(74, 74, 74);\n"
"    color: white;            \n"
"    border-radius: 10px;\n"
"    padding: 4px 8px;\n"
"    margin: 4px 6px;\n"
"    font-size: 14px;\n"
"    text-align: left;\n"
"    border: none;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: white;\n"
"    color: #000000;\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    background-color: white;\n"
"    color: #000000;\n"
"}")
        icon6 = QIcon()
        icon6.addFile(u":/icons/icons/community.svg", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.pushButton_10.setIcon(icon6)
        self.pushButton_10.setCheckable(True)
        self.pushButton_10.setChecked(False)
        self.pushButton_10.setAutoExclusive(True)

        self.verticalLayout.addWidget(self.pushButton_10)

        self.label_3 = QLabel(self.icon_text_widget)
        self.label_3.setObjectName(u"label_3")
        self.label_3.setGeometry(QRect(0, 40, 211, 31))
        self.label_3.setMinimumSize(QSize(19, 0))
        font = QFont()
        font.setPointSize(14)
        font.setBold(True)
        self.label_3.setFont(font)
        self.label_3.setStyleSheet(u"QLabel {\n"
"    color: white;\n"
"}\n"
"")
        self.layoutWidget2 = QWidget(self.centralwidget)
        self.layoutWidget2.setObjectName(u"layoutWidget2")
        self.layoutWidget2.setGeometry(QRect(330, 20, 981, 801))
        self.verticalLayout_4 = QVBoxLayout(self.layoutWidget2)
        self.verticalLayout_4.setObjectName(u"verticalLayout_4")
        self.verticalLayout_4.setContentsMargins(0, 0, 0, 0)
        self.header_widget = QWidget(self.layoutWidget2)
        self.header_widget.setObjectName(u"header_widget")
        self.layoutWidget3 = QWidget(self.header_widget)
        self.layoutWidget3.setObjectName(u"layoutWidget3")
        self.layoutWidget3.setGeometry(QRect(20, 20, 409, 51))
        self.horizontalLayout_2 = QHBoxLayout(self.layoutWidget3)
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.horizontalLayout_2.setContentsMargins(0, 0, 0, 0)
        self.pushButton = QPushButton(self.layoutWidget3)
        self.pushButton.setObjectName(u"pushButton")
        icon7 = QIcon()
        icon7.addFile(u":/icons/icons/align-justify.svg", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.pushButton.setIcon(icon7)
        self.pushButton.setIconSize(QSize(29, 35))
        self.pushButton.setCheckable(True)

        self.horizontalLayout_2.addWidget(self.pushButton)

        self.label_2 = QLabel(self.layoutWidget3)
        self.label_2.setObjectName(u"label_2")
        font1 = QFont()
        font1.setPointSize(10)
        self.label_2.setFont(font1)
        self.label_2.setStyleSheet(u"color: rgb(135, 135, 135);")

        self.horizontalLayout_2.addWidget(self.label_2)

        self.label = QLabel(self.layoutWidget3)
        self.label.setObjectName(u"label")
        font2 = QFont()
        font2.setPointSize(15)
        self.label.setFont(font2)

        self.horizontalLayout_2.addWidget(self.label)

        self.stackedWidget = QStackedWidget(self.header_widget)
        self.stackedWidget.setObjectName(u"stackedWidget")
        self.stackedWidget.setGeometry(QRect(10, 90, 911, 701))
        self.stackedWidget.setMaximumSize(QSize(941, 741))
        self.stackedWidget.setStyleSheet(u"QPushButton {\n"
"    background-color: #079DD9;\n"
"    color: white;\n"
"    border-radius: 10px;\n"
"    padding: 6px 12px;\n"
"    font-weight: bold;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #99D9F2;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: #80BDF2;\n"
"}")
        self.page = QWidget()
        self.page.setObjectName(u"page")
        self.page.setMaximumSize(QSize(841, 741))
        self.textEdit = QTextEdit(self.page)
        self.textEdit.setObjectName(u"textEdit")
        self.textEdit.setGeometry(QRect(10, 80, 181, 101))
        self.textEdit.setStyleSheet(u"QTextEdit {\n"
"    border-radius: 10px;\n"
"    background-color: white;\n"
"    border: 1px solid #ccc;\n"
"    padding: 8px;\n"
"}")
        self.textEdit.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.textEdit.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.textEdit.setReadOnly(True)
        self.textEdit_2 = QTextEdit(self.page)
        self.textEdit_2.setObjectName(u"textEdit_2")
        self.textEdit_2.setGeometry(QRect(210, 80, 191, 101))
        self.textEdit_2.setStyleSheet(u"QTextEdit {\n"
"    border-radius: 10px;\n"
"    background-color: white;\n"
"    border: 1px solid #ccc;\n"
"    padding: 8px;\n"
"}")
        self.textEdit_2.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.textEdit_2.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.textEdit_2.setReadOnly(True)
        self.textEdit_3 = QTextEdit(self.page)
        self.textEdit_3.setObjectName(u"textEdit_3")
        self.textEdit_3.setGeometry(QRect(630, 80, 191, 101))
        self.textEdit_3.setStyleSheet(u"QTextEdit {\n"
"    border-radius: 10px;\n"
"    background-color: white;\n"
"    border: 1px solid #ccc;\n"
"    padding: 8px;\n"
"}")
        self.textEdit_3.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.textEdit_3.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.textEdit_3.setReadOnly(True)
        self.textEdit_4 = QTextEdit(self.page)
        self.textEdit_4.setObjectName(u"textEdit_4")
        self.textEdit_4.setGeometry(QRect(420, 80, 191, 101))
        self.textEdit_4.setStyleSheet(u"QTextEdit {\n"
"    border-radius: 10px;\n"
"    background-color: white;\n"
"    border: 1px solid #ccc;\n"
"    padding: 8px;\n"
"}")
        self.textEdit_4.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.textEdit_4.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.textEdit_4.setReadOnly(True)
        self.label_20 = QLabel(self.page)
        self.label_20.setObjectName(u"label_20")
        self.label_20.setGeometry(QRect(670, 160, 41, 31))
        self.label_20.setPixmap(QPixmap(u"../../../PC/.designer/backup/icons/clock.svg"))
        self.label_21 = QLabel(self.page)
        self.label_21.setObjectName(u"label_21")
        self.label_21.setGeometry(QRect(10, 50, 701, 21))
        font3 = QFont()
        font3.setFamilies([u"Arial"])
        font3.setPointSize(12)
        self.label_21.setFont(font3)
        self.label_22 = QLabel(self.page)
        self.label_22.setObjectName(u"label_22")
        self.label_22.setGeometry(QRect(10, 10, 271, 41))
        font4 = QFont()
        font4.setFamilies([u"Arial"])
        font4.setPointSize(12)
        font4.setBold(True)
        self.label_22.setFont(font4)
        self.frame = QFrame(self.page)
        self.frame.setObjectName(u"frame")
        self.frame.setGeometry(QRect(10, 230, 841, 431))
        self.frame.setFrameShape(QFrame.StyledPanel)
        self.frame.setFrameShadow(QFrame.Raised)
        self.ch_left = QWidget(self.frame)
        self.ch_left.setObjectName(u"ch_left")
        self.ch_left.setGeometry(QRect(0, 40, 331, 361))
        self.ch_right = QWidget(self.frame)
        self.ch_right.setObjectName(u"ch_right")
        self.ch_right.setGeometry(QRect(340, 40, 491, 361))
        self.label_6 = QLabel(self.page)
        self.label_6.setObjectName(u"label_6")
        self.label_6.setGeometry(QRect(20, 120, 71, 31))
        self.label_6.setStyleSheet(u"QLabel {\n"
"    font-family: \"Arial\";\n"
"    font-size: 24px;\n"
"    font-weight: bold;\n"
"    color: #000000;\n"
"    text-transform: uppercase; \n"
"}")
        self.label_24 = QLabel(self.page)
        self.label_24.setObjectName(u"label_24")
        self.label_24.setGeometry(QRect(430, 120, 71, 31))
        self.label_24.setStyleSheet(u"QLabel {\n"
"    font-family: \"Arial\";\n"
"    font-size: 24px;\n"
"    font-weight: bold;\n"
"    color: #000000;\n"
"    text-transform: uppercase; \n"
"}")
        self.label_25 = QLabel(self.page)
        self.label_25.setObjectName(u"label_25")
        self.label_25.setGeometry(QRect(220, 120, 71, 31))
        self.label_25.setStyleSheet(u"QLabel {\n"
"    font-family: \"Arial\";\n"
"    font-size: 24px;\n"
"    font-weight: bold;\n"
"    color: #000000;\n"
"    text-transform: uppercase; \n"
"}")
        self.label_23 = QLabel(self.page)
        self.label_23.setObjectName(u"label_23")
        self.label_23.setGeometry(QRect(640, 120, 71, 31))
        self.label_23.setStyleSheet(u"QLabel {\n"
"    font-family: \"Arial\";\n"
"    font-size: 24px;\n"
"    font-weight: bold;\n"
"    color: #000000;\n"
"    text-transform: uppercase; \n"
"}")
        self.stackedWidget.addWidget(self.page)
        self.page_3 = QWidget()
        self.page_3.setObjectName(u"page_3")
        self.page_3.setMaximumSize(QSize(841, 741))
        self.groupBox = QGroupBox(self.page_3)
        self.groupBox.setObjectName(u"groupBox")
        self.groupBox.setGeometry(QRect(20, 10, 791, 101))
        self.groupBox.setStyleSheet(u"QGroupBox {\n"
"    border: none;\n"
"    border-radius: 20px;\n"
"    background-color: white;\n"
"}")
        self.gridLayout_2 = QGridLayout(self.groupBox)
        self.gridLayout_2.setObjectName(u"gridLayout_2")
        self.label_26 = QLabel(self.groupBox)
        self.label_26.setObjectName(u"label_26")

        self.gridLayout_2.addWidget(self.label_26, 1, 0, 1, 1)

        self.label_7 = QLabel(self.groupBox)
        self.label_7.setObjectName(u"label_7")

        self.gridLayout_2.addWidget(self.label_7, 0, 0, 1, 1)

        self.btn_muonsach = QPushButton(self.groupBox)
        self.btn_muonsach.setObjectName(u"btn_muonsach")
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.btn_muonsach.sizePolicy().hasHeightForWidth())
        self.btn_muonsach.setSizePolicy(sizePolicy)
        self.btn_muonsach.setStyleSheet(u"QPushButton {\n"
"    background-color: #079DD9;\n"
"    color: white;\n"
"    border-radius: 10px;\n"
"    padding: 6px 12px;\n"
"    font-weight: bold;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #99D9F2;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: #80BDF2;\n"
"}\n"
"\n"
"")

        self.gridLayout_2.addWidget(self.btn_muonsach, 0, 1, 1, 1)

        self.scrollArea = QScrollArea(self.page_3)
        self.scrollArea.setObjectName(u"scrollArea")
        self.scrollArea.setGeometry(QRect(10, 170, 811, 471))
        self.scrollArea.setWidgetResizable(True)
        self.scrollAreaWidgetContents = QWidget()
        self.scrollAreaWidgetContents.setObjectName(u"scrollAreaWidgetContents")
        self.scrollAreaWidgetContents.setGeometry(QRect(0, 0, 809, 469))
        self.verticalLayoutWidget = QWidget(self.scrollAreaWidgetContents)
        self.verticalLayoutWidget.setObjectName(u"verticalLayoutWidget")
        self.verticalLayoutWidget.setGeometry(QRect(10, 10, 791, 451))
        self.verticalLayout_6 = QVBoxLayout(self.verticalLayoutWidget)
        self.verticalLayout_6.setObjectName(u"verticalLayout_6")
        self.verticalLayout_6.setContentsMargins(0, 0, 0, 0)
        self.scrollArea.setWidget(self.scrollAreaWidgetContents)
        self.layoutWidget4 = QWidget(self.page_3)
        self.layoutWidget4.setObjectName(u"layoutWidget4")
        self.layoutWidget4.setGeometry(QRect(20, 120, 801, 42))
        self.horizontalLayout_3 = QHBoxLayout(self.layoutWidget4)
        self.horizontalLayout_3.setObjectName(u"horizontalLayout_3")
        self.horizontalLayout_3.setContentsMargins(0, 0, 0, 0)
        self.lineEdit_2 = QLineEdit(self.layoutWidget4)
        self.lineEdit_2.setObjectName(u"lineEdit_2")
        self.lineEdit_2.setStyleSheet(u"QLineEdit {\n"
"    border: 1px solid #dddddd;\n"
"    border-radius: 20px;\n"
"    padding: 10px 15px;\n"
"    background-color:  rgb(220, 220, 220);\n"
"}")

        self.horizontalLayout_3.addWidget(self.lineEdit_2)

        self.xuat_excel_2 = QPushButton(self.layoutWidget4)
        self.xuat_excel_2.setObjectName(u"xuat_excel_2")
        self.xuat_excel_2.setStyleSheet(u"QPushButton {\n"
"    background-color: #079DD9;\n"
"    color: white;\n"
"    border-radius: 10px;\n"
"    padding: 6px 12px;\n"
"    font-weight: bold;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #99D9F2;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: #80BDF2;\n"
"}\n"
"QPushButton{\n"
"    background-color: #2DA9E1;\n"
"    color: white;\n"
"}\n"
"QPushButton svg{\n"
"    fill: white;\n"
"}")

        self.horizontalLayout_3.addWidget(self.xuat_excel_2)

        self.stackedWidget.addWidget(self.page_3)
        self.page_2 = QWidget()
        self.page_2.setObjectName(u"page_2")
        self.page_2.setStyleSheet(u"\n"
"QWidget { background-color:#f5f7fb; }\n"
"#cardFrame { background:white; border-radius:16px; }\n"
"QPushButton#addBtn { background:#2563eb; color:white; border-radius:8px; padding:8px 16px; }\n"
"QPushButton#pageActive { background:#2563eb; color:white; border-radius:6px; padding:4px 10px; }\n"
"QPushButton#pageBtn { background:#e5e7eb; border-radius:6px; padding:4px 10px; }\n"
" ")
        self.cardFrame = QFrame(self.page_2)
        self.cardFrame.setObjectName(u"cardFrame")
        self.cardFrame.setGeometry(QRect(11, 72, 641, 581))
        self.vboxLayout = QVBoxLayout(self.cardFrame)
        self.vboxLayout.setObjectName(u"vboxLayout")
        self.hboxLayout = QHBoxLayout()
        self.hboxLayout.setObjectName(u"hboxLayout")
        self.lineEdit = QLineEdit(self.cardFrame)
        self.lineEdit.setObjectName(u"lineEdit")

        self.hboxLayout.addWidget(self.lineEdit)

        self.spacerItem = QSpacerItem(0, 0, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.hboxLayout.addItem(self.spacerItem)

        self.xuat_excel = QPushButton(self.cardFrame)
        self.xuat_excel.setObjectName(u"xuat_excel")
        self.xuat_excel.setStyleSheet(u"QPushButton {\n"
"    background-color: #079DD9;\n"
"    color: white;\n"
"    border-radius: 10px;\n"
"    padding: 6px 12px;\n"
"    font-weight: bold;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #99D9F2;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: #80BDF2;\n"
"}\n"
"QPushButton{\n"
"    background-color: #2DA9E1;\n"
"    color: white;\n"
"}\n"
"QPushButton svg{\n"
"    fill: white;\n"
"}")

        self.hboxLayout.addWidget(self.xuat_excel)

        self.filter = QPushButton(self.cardFrame)
        self.filter.setObjectName(u"filter")
        self.filter.setStyleSheet(u"QPushButton {\n"
"    background-color: #079DD9;\n"
"    color: white;\n"
"    border-radius: 10px;\n"
"    padding: 6px 12px;\n"
"    font-weight: bold;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #99D9F2;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: #80BDF2;\n"
"}")

        self.hboxLayout.addWidget(self.filter)


        self.vboxLayout.addLayout(self.hboxLayout)

        self.tableReaders = QTableWidget(self.cardFrame)
        if (self.tableReaders.columnCount() < 5):
            self.tableReaders.setColumnCount(5)
        __qtablewidgetitem = QTableWidgetItem()
        self.tableReaders.setHorizontalHeaderItem(0, __qtablewidgetitem)
        __qtablewidgetitem1 = QTableWidgetItem()
        self.tableReaders.setHorizontalHeaderItem(1, __qtablewidgetitem1)
        __qtablewidgetitem2 = QTableWidgetItem()
        self.tableReaders.setHorizontalHeaderItem(2, __qtablewidgetitem2)
        __qtablewidgetitem3 = QTableWidgetItem()
        self.tableReaders.setHorizontalHeaderItem(3, __qtablewidgetitem3)
        __qtablewidgetitem4 = QTableWidgetItem()
        self.tableReaders.setHorizontalHeaderItem(4, __qtablewidgetitem4)
        self.tableReaders.setObjectName(u"tableReaders")
        self.tableReaders.setStyleSheet(u"QPushButton {\n"
"    background-color: rgb(74, 74, 74);\n"
"    color: white;            \n"
"    border-radius: 10px;\n"
"    padding: 4px 8px;\n"
"    margin: 4px 6px;\n"
"    font-size: 14px;\n"
"    text-align: center;\n"
"    border: none;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: white;\n"
"    color: #000000;\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    background-color: #004578;\n"
"    color: white;\n"
"}\n"
"")
        self.tableReaders.setColumnCount(5)

        self.vboxLayout.addWidget(self.tableReaders)

        self.hboxLayout1 = QHBoxLayout()
        self.hboxLayout1.setObjectName(u"hboxLayout1")
        self.label1 = QLabel(self.cardFrame)
        self.label1.setObjectName(u"label1")

        self.hboxLayout1.addWidget(self.label1)

        self.spacerItem1 = QSpacerItem(0, 0, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.hboxLayout1.addItem(self.spacerItem1)

        self.pageBtn = QPushButton(self.cardFrame)
        self.pageBtn.setObjectName(u"pageBtn")
        self.pageBtn.setStyleSheet(u"QPushButton {\n"
"    background-color: white;\n"
"    color: black;\n"
"    border-radius: 10px;\n"
"    padding: 4px 8px;\n"
"    margin: 4px 6px;\n"
"    font-size: 12px;\n"
"    text-align: center;\n"
"    border: none;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #F2F2F2;\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    background-color: #E0E0E0;\n"
"}")

        self.hboxLayout1.addWidget(self.pageBtn)

        self.pageActive = QPushButton(self.cardFrame)
        self.pageActive.setObjectName(u"pageActive")

        self.hboxLayout1.addWidget(self.pageActive)

        self.pageBtn1 = QPushButton(self.cardFrame)
        self.pageBtn1.setObjectName(u"pageBtn1")
        self.pageBtn1.setStyleSheet(u"QPushButton {\n"
"    background-color: white;\n"
"    color: black;\n"
"    border-radius: 10px;\n"
"    padding: 4px 8px;\n"
"    margin: 4px 6px;\n"
"    font-size: 12px;\n"
"    text-align: center;\n"
"    border: none;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #F2F2F2;\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    background-color: #E0E0E0;\n"
"}")

        self.hboxLayout1.addWidget(self.pageBtn1)


        self.vboxLayout.addLayout(self.hboxLayout1)

        self.widget_6 = QWidget(self.page_2)
        self.widget_6.setObjectName(u"widget_6")
        self.widget_6.setGeometry(QRect(650, 60, 251, 601))
        self.verticalLayout_9 = QVBoxLayout(self.widget_6)
        self.verticalLayout_9.setSpacing(15)
        self.verticalLayout_9.setObjectName(u"verticalLayout_9")
        self.verticalLayout_8 = QVBoxLayout()
        self.verticalLayout_8.setSpacing(15)
        self.verticalLayout_8.setObjectName(u"verticalLayout_8")
        self.boxTopReaders = QGroupBox(self.widget_6)
        self.boxTopReaders.setObjectName(u"boxTopReaders")
        font5 = QFont()
        font5.setFamilies([u"MS Shell Dlg 2"])
        font5.setPointSize(9)
        font5.setBold(True)
        self.boxTopReaders.setFont(font5)
        self.boxTopReaders.setStyleSheet(u"QGroupBox {\n"
"    border: 1px solid #E5E7EB;\n"
"    border-radius: 12px;\n"
"    background: #F5F7FA;\n"
"    padding: 12px;\n"
"}\n"
"\n"
"QGroupBox::title {\n"
"    subcontrol-origin: margin;\n"
"    left: 12px;\n"
"    padding: 0 6px;\n"
"    font-size: 14px;\n"
"    font-weight: 700;\n"
"}")
        self.verticalLayoutWidget_6 = QWidget(self.boxTopReaders)
        self.verticalLayoutWidget_6.setObjectName(u"verticalLayoutWidget_6")
        self.verticalLayoutWidget_6.setGeometry(QRect(10, 20, 201, 161))
        self.layoutTopReaders = QVBoxLayout(self.verticalLayoutWidget_6)
        self.layoutTopReaders.setObjectName(u"layoutTopReaders")
        self.layoutTopReaders.setContentsMargins(0, 0, 0, 0)

        self.verticalLayout_8.addWidget(self.boxTopReaders)

        self.boxTopBooks = QGroupBox(self.widget_6)
        self.boxTopBooks.setObjectName(u"boxTopBooks")
        font6 = QFont()
        font6.setPointSize(9)
        font6.setBold(True)
        self.boxTopBooks.setFont(font6)
        self.boxTopBooks.setStyleSheet(u"QGroupBox {\n"
"    border: 1px solid #E5E7EB;\n"
"    border-radius: 12px;\n"
"    background: #F5F7FA;\n"
"    padding: 12px;\n"
"}\n"
"\n"
"QGroupBox::title {\n"
"    subcontrol-origin: margin;\n"
"    left: 12px;\n"
"    padding: 0 6px;\n"
"    font-size: 14px;\n"
"    font-weight: 700;\n"
"}")
        self.verticalLayoutWidget_4 = QWidget(self.boxTopBooks)
        self.verticalLayoutWidget_4.setObjectName(u"verticalLayoutWidget_4")
        self.verticalLayoutWidget_4.setGeometry(QRect(10, 20, 201, 151))
        self.layoutTopBooks = QVBoxLayout(self.verticalLayoutWidget_4)
        self.layoutTopBooks.setObjectName(u"layoutTopBooks")
        self.layoutTopBooks.setContentsMargins(0, 0, 0, 0)

        self.verticalLayout_8.addWidget(self.boxTopBooks)

        self.boxRecentActivity = QGroupBox(self.widget_6)
        self.boxRecentActivity.setObjectName(u"boxRecentActivity")
        self.boxRecentActivity.setFont(font6)
        self.boxRecentActivity.setStyleSheet(u"QGroupBox {\n"
"    border: 1px solid #E5E7EB;\n"
"    border-radius: 12px;\n"
"    background: #F5F7FA;\n"
"    padding: 12px;\n"
"}\n"
"\n"
"QGroupBox::title {\n"
"    subcontrol-origin: margin;\n"
"    left: 12px;\n"
"    padding: 0 6px;\n"
"    font-size: 14px;\n"
"    font-weight: 700;\n"
"}")
        self.verticalLayoutWidget_5 = QWidget(self.boxRecentActivity)
        self.verticalLayoutWidget_5.setObjectName(u"verticalLayoutWidget_5")
        self.verticalLayoutWidget_5.setGeometry(QRect(10, 20, 201, 151))
        self.layoutRecentActivity = QVBoxLayout(self.verticalLayoutWidget_5)
        self.layoutRecentActivity.setObjectName(u"layoutRecentActivity")
        self.layoutRecentActivity.setContentsMargins(0, 0, 0, 0)

        self.verticalLayout_8.addWidget(self.boxRecentActivity)


        self.verticalLayout_9.addLayout(self.verticalLayout_8)

        self.layoutWidget5 = QWidget(self.page_2)
        self.layoutWidget5.setObjectName(u"layoutWidget5")
        self.layoutWidget5.setGeometry(QRect(11, 11, 881, 54))
        self.hboxLayout2 = QHBoxLayout(self.layoutWidget5)
        self.hboxLayout2.setObjectName(u"hboxLayout2")
        self.hboxLayout2.setContentsMargins(0, 0, 0, 0)
        self.vboxLayout1 = QVBoxLayout()
        self.vboxLayout1.setObjectName(u"vboxLayout1")
        self.label2 = QLabel(self.layoutWidget5)
        self.label2.setObjectName(u"label2")

        self.vboxLayout1.addWidget(self.label2)

        self.label3 = QLabel(self.layoutWidget5)
        self.label3.setObjectName(u"label3")

        self.vboxLayout1.addWidget(self.label3)


        self.hboxLayout2.addLayout(self.vboxLayout1)

        self.spacerItem2 = QSpacerItem(0, 0, QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        self.hboxLayout2.addItem(self.spacerItem2)

        self.them_reader = QPushButton(self.layoutWidget5)
        self.them_reader.setObjectName(u"them_reader")
        sizePolicy.setHeightForWidth(self.them_reader.sizePolicy().hasHeightForWidth())
        self.them_reader.setSizePolicy(sizePolicy)
        self.them_reader.setStyleSheet(u"QPushButton {\n"
"    background-color: #079DD9;\n"
"    color: white;\n"
"    border-radius: 10px;\n"
"    padding: 6px 12px;\n"
"    font-weight: bold;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #99D9F2;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: #80BDF2;\n"
"}\n"
"\n"
"")

        self.hboxLayout2.addWidget(self.them_reader)

        self.stackedWidget.addWidget(self.page_2)
        self.page_4 = QWidget()
        self.page_4.setObjectName(u"page_4")
        self.page_4.setMaximumSize(QSize(841, 741))
        self.transferTable = QTableWidget(self.page_4)
        if (self.transferTable.columnCount() < 6):
            self.transferTable.setColumnCount(6)
        __qtablewidgetitem5 = QTableWidgetItem()
        self.transferTable.setHorizontalHeaderItem(0, __qtablewidgetitem5)
        __qtablewidgetitem6 = QTableWidgetItem()
        self.transferTable.setHorizontalHeaderItem(1, __qtablewidgetitem6)
        __qtablewidgetitem7 = QTableWidgetItem()
        self.transferTable.setHorizontalHeaderItem(2, __qtablewidgetitem7)
        __qtablewidgetitem8 = QTableWidgetItem()
        self.transferTable.setHorizontalHeaderItem(3, __qtablewidgetitem8)
        __qtablewidgetitem9 = QTableWidgetItem()
        self.transferTable.setHorizontalHeaderItem(4, __qtablewidgetitem9)
        __qtablewidgetitem10 = QTableWidgetItem()
        self.transferTable.setHorizontalHeaderItem(5, __qtablewidgetitem10)
        self.transferTable.setObjectName(u"transferTable")
        self.transferTable.setGeometry(QRect(20, 150, 831, 501))
        self.transferTable.setStyleSheet(u"QHeaderView::section{\n"
"    font-weight: bold;\n"
"    background-color: black;\n"
"    color: white;\n"
"}\n"
"\n"
"QTableWidget{\n"
"    alternate-background-color: #B0EDFB;\n"
"    background-color: #F4F9FA;\n"
"}\n"
"")
        self.label_9 = QLabel(self.page_4)
        self.label_9.setObjectName(u"label_9")
        self.label_9.setGeometry(QRect(134, 75, 91, 51))
        self.label_9.setPixmap(QPixmap(u":/icons/icons/alert-circle.svg"))
        self.widget = QWidget(self.page_4)
        self.widget.setObjectName(u"widget")
        self.widget.setGeometry(QRect(20, 30, 821, 111))
        self.horizontalLayout_7 = QHBoxLayout(self.widget)
        self.horizontalLayout_7.setObjectName(u"horizontalLayout_7")
        self.horizontalLayout_7.setContentsMargins(0, 0, 0, 0)
        self.widget_3 = QWidget(self.widget)
        self.widget_3.setObjectName(u"widget_3")
        self.widget_3.setStyleSheet(u"background-color: rgb(215, 239, 255);\n"
"border-radius: 15px;\n"
"border: none;\n"
"")
        self.widget1 = QWidget(self.widget_3)
        self.widget1.setObjectName(u"widget1")
        self.widget1.setGeometry(QRect(30, 40, 128, 34))
        self.horizontalLayout_4 = QHBoxLayout(self.widget1)
        self.horizontalLayout_4.setObjectName(u"horizontalLayout_4")
        self.horizontalLayout_4.setContentsMargins(0, 0, 0, 0)
        self.label_33 = QLabel(self.widget1)
        self.label_33.setObjectName(u"label_33")
        sizePolicy.setHeightForWidth(self.label_33.sizePolicy().hasHeightForWidth())
        self.label_33.setSizePolicy(sizePolicy)
        self.label_33.setMinimumSize(QSize(32, 32))
        self.label_33.setMaximumSize(QSize(32, 32))
        self.label_33.setStyleSheet(u"QLabel{\n"
"background:transparent;\n"
"border-radius:10px;\n"
"padding:4px;\n"
"}")
        self.label_33.setPixmap(QPixmap(u":/icons/icons/clock.svg"))
        self.label_33.setScaledContents(True)

        self.horizontalLayout_4.addWidget(self.label_33)

        self.label_16 = QLabel(self.widget1)
        self.label_16.setObjectName(u"label_16")
        self.label_16.setStyleSheet(u"font: 10pt \"MS Shell Dlg 2\";")

        self.horizontalLayout_4.addWidget(self.label_16)


        self.horizontalLayout_7.addWidget(self.widget_3)

        self.widget_2 = QWidget(self.widget)
        self.widget_2.setObjectName(u"widget_2")
        self.widget_2.setStyleSheet(u"background-color: #F2D0D0;\n"
"border-radius: 15px;\n"
"border: none;\n"
"")
        self.layoutWidget6 = QWidget(self.widget_2)
        self.layoutWidget6.setObjectName(u"layoutWidget6")
        self.layoutWidget6.setGeometry(QRect(30, 40, 151, 34))
        self.horizontalLayout_5 = QHBoxLayout(self.layoutWidget6)
        self.horizontalLayout_5.setObjectName(u"horizontalLayout_5")
        self.horizontalLayout_5.setContentsMargins(0, 0, 0, 0)
        self.label_11 = QLabel(self.layoutWidget6)
        self.label_11.setObjectName(u"label_11")
        sizePolicy.setHeightForWidth(self.label_11.sizePolicy().hasHeightForWidth())
        self.label_11.setSizePolicy(sizePolicy)
        self.label_11.setMinimumSize(QSize(32, 32))
        self.label_11.setMaximumSize(QSize(32, 32))
        self.label_11.setStyleSheet(u"QLabel{\n"
"background:transparent;\n"
"border-radius:10px;\n"
"padding:4px;\n"
"}")
        self.label_11.setPixmap(QPixmap(u":/icons/icons/book.svg"))
        self.label_11.setScaledContents(True)

        self.horizontalLayout_5.addWidget(self.label_11)

        self.label_14 = QLabel(self.layoutWidget6)
        self.label_14.setObjectName(u"label_14")
        self.label_14.setStyleSheet(u"font: 10pt \"MS Shell Dlg 2\";")

        self.horizontalLayout_5.addWidget(self.label_14)


        self.horizontalLayout_7.addWidget(self.widget_2)

        self.widget_4 = QWidget(self.widget)
        self.widget_4.setObjectName(u"widget_4")
        self.widget_4.setStyleSheet(u"background-color: rgb(225, 253, 255);\n"
"border-radius: 15px;\n"
"border: none;\n"
"")
        self.widget2 = QWidget(self.widget_4)
        self.widget2.setObjectName(u"widget2")
        self.widget2.setGeometry(QRect(30, 40, 200, 34))
        self.horizontalLayout_6 = QHBoxLayout(self.widget2)
        self.horizontalLayout_6.setObjectName(u"horizontalLayout_6")
        self.horizontalLayout_6.setContentsMargins(0, 0, 0, 0)
        self.label_13 = QLabel(self.widget2)
        self.label_13.setObjectName(u"label_13")
        sizePolicy.setHeightForWidth(self.label_13.sizePolicy().hasHeightForWidth())
        self.label_13.setSizePolicy(sizePolicy)
        self.label_13.setMinimumSize(QSize(32, 32))
        self.label_13.setMaximumSize(QSize(32, 32))
        self.label_13.setStyleSheet(u"QLabel{\n"
"background:transparent;\n"
"border-radius:10px;\n"
"padding:4px;\n"
"}")
        self.label_13.setPixmap(QPixmap(u":/icons/icons/check.svg"))
        self.label_13.setScaledContents(True)

        self.horizontalLayout_6.addWidget(self.label_13)

        self.label_17 = QLabel(self.widget2)
        self.label_17.setObjectName(u"label_17")
        self.label_17.setStyleSheet(u"font: 10pt \"MS Shell Dlg 2\";")

        self.horizontalLayout_6.addWidget(self.label_17)


        self.horizontalLayout_7.addWidget(self.widget_4)

        self.stackedWidget.addWidget(self.page_4)
        self.page_5 = QWidget()
        self.page_5.setObjectName(u"page_5")
        self.page_5.setMaximumSize(QSize(841, 741))
        self.scrollArea_2 = QScrollArea(self.page_5)
        self.scrollArea_2.setObjectName(u"scrollArea_2")
        self.scrollArea_2.setGeometry(QRect(10, 170, 821, 491))
        self.scrollArea_2.setStyleSheet(u"QScrollArea {\n"
"    border: none;\n"
"    border-radius: 20px;\n"
"    background-color: white;\n"
"}")
        self.scrollArea_2.setWidgetResizable(True)
        self.scrollAreaWidgetContents_3 = QWidget()
        self.scrollAreaWidgetContents_3.setObjectName(u"scrollAreaWidgetContents_3")
        self.scrollAreaWidgetContents_3.setGeometry(QRect(0, 0, 821, 491))
        self.gridLayout = QGridLayout(self.scrollAreaWidgetContents_3)
        self.gridLayout.setObjectName(u"gridLayout")
        self.wid = QWidget(self.scrollAreaWidgetContents_3)
        self.wid.setObjectName(u"wid")
        self.verticalLayout_7 = QVBoxLayout(self.wid)
        self.verticalLayout_7.setObjectName(u"verticalLayout_7")
        self.ver = QVBoxLayout()
        self.ver.setObjectName(u"ver")

        self.verticalLayout_7.addLayout(self.ver)


        self.gridLayout.addWidget(self.wid, 0, 0, 1, 1)

        self.scrollArea_2.setWidget(self.scrollAreaWidgetContents_3)
        self.label_10 = QLabel(self.page_5)
        self.label_10.setObjectName(u"label_10")
        self.label_10.setGeometry(QRect(0, 10, 391, 41))
        self.label_28 = QLabel(self.page_5)
        self.label_28.setObjectName(u"label_28")
        self.label_28.setGeometry(QRect(0, 40, 431, 41))
        self.label_29 = QLabel(self.page_5)
        self.label_29.setObjectName(u"label_29")
        self.label_29.setGeometry(QRect(10, 120, 271, 51))
        self.btn_borrow = QPushButton(self.page_5)
        self.btn_borrow.setObjectName(u"btn_borrow")
        self.btn_borrow.setGeometry(QRect(610, 0, 211, 28))
        self.btn_borrow.setStyleSheet(u"QPushButton {\n"
"    background-color: #079DD9;\n"
"    color: white;\n"
"    border-radius: 10px;\n"
"    padding: 6px 12px;\n"
"    font-weight: bold;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #99D9F2;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: #80BDF2;\n"
"}")
        self.widget_5 = QWidget(self.page_5)
        self.widget_5.setObjectName(u"widget_5")
        self.widget_5.setGeometry(QRect(560, 40, 271, 121))
        self.widget_5.setStyleSheet(u"QWidget {\n"
"    background-color: #079DD9;\n"
"	color: white;\n"
"    border-radius: 20px;\n"
"}")
        self.label_30 = QLabel(self.widget_5)
        self.label_30.setObjectName(u"label_30")
        self.label_30.setGeometry(QRect(10, 10, 141, 21))
        self.label_31 = QLabel(self.widget_5)
        self.label_31.setObjectName(u"label_31")
        self.label_31.setGeometry(QRect(10, 30, 261, 41))
        self.btn_share = QPushButton(self.widget_5)
        self.btn_share.setObjectName(u"btn_share")
        self.btn_share.setGeometry(QRect(60, 80, 151, 28))
        self.btn_share.setStyleSheet(u"QPushButton {\n"
"    background-color: white;\n"
"    color: #079DD9;\n"
"    border-radius: 10px;\n"
"    padding: 6px 12px;\n"
"    font-weight: bold;\n"
"}\n"
"\n"
"QPushButton:hover{\n"
"    background-color: #E8F1FD;\n"
"}\n"
"\n"
"QPushButton:pressed {\n"
"    background-color: #BBD8F2;\n"
"}")
        icon8 = QIcon()
        iconThemeName = u"share"
        if QIcon.hasThemeIcon(iconThemeName):
            icon8 = QIcon.fromTheme(iconThemeName)
        else:
            icon8.addFile(u"../../../PC/.designer/backup", QSize(), QIcon.Mode.Normal, QIcon.State.Off)

        self.btn_share.setIcon(icon8)
        self.stackedWidget.addWidget(self.page_5)
        self.label_4 = QLabel(self.header_widget)
        self.label_4.setObjectName(u"label_4")
        self.label_4.setGeometry(QRect(812, 1, 16, 21))
        self.label_4.setFont(font1)
        self.label_4.setStyleSheet(u"color: rgb(135, 135, 135);")
        self.label_4.setPixmap(QPixmap(u":/icons/icons/user.svg"))
        self.layoutWidget7 = QWidget(self.header_widget)
        self.layoutWidget7.setObjectName(u"layoutWidget7")
        self.layoutWidget7.setGeometry(QRect(580, 30, 251, 41))
        self.horizontalLayout = QHBoxLayout(self.layoutWidget7)
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.horizontalLayout.setContentsMargins(0, 0, 0, 0)
        self.lineEdit1 = QLineEdit(self.layoutWidget7)
        self.lineEdit1.setObjectName(u"lineEdit1")
        self.lineEdit1.setStyleSheet(u"QlineEdit{\n"
"  padding-left:20px;\n"
"  border:1px-solid gray;\n"
"  border-radius: 20px;\n"
"}")

        self.horizontalLayout.addWidget(self.lineEdit1)

        self.label_5 = QLabel(self.layoutWidget7)
        self.label_5.setObjectName(u"label_5")
        self.label_5.setFont(font1)
        self.label_5.setStyleSheet(u"color: rgb(135, 135, 135);\n"
"color: rgb(0, 0, 0);")

        self.horizontalLayout.addWidget(self.label_5)

        self.label_4.raise_()
        self.stackedWidget.raise_()
        self.layoutWidget7.raise_()
        self.layoutWidget7.raise_()

        self.verticalLayout_4.addWidget(self.header_widget)

        MainWindow.setCentralWidget(self.centralwidget)
        self.layoutWidget7.raise_()
        self.icon_text_widget.raise_()

        self.retranslateUi(MainWindow)

        self.stackedWidget.setCurrentIndex(1)


        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"MainWindow", None))
        self.pushButton_12.setText(QCoreApplication.translate("MainWindow", u"     C\u00e0i \u0111\u1eb7t", None))
        self.pushButton_11.setText(QCoreApplication.translate("MainWindow", u"     \u0110\u0102NG XU\u1ea4T", None))
        self.layoutWidget1.setStyleSheet(QCoreApplication.translate("MainWindow", u"QPushButton {\n"
"    background-color: white;\n"
"    color: black;\n"
"    border-radius: 10px;\n"
"    padding: 4px 8px;\n"
"    margin: 4px 6px;\n"
"    font-size: 12px;\n"
"    text-align: center;\n"
"    border: none;\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"    background-color: #F2F2F2;\n"
"}\n"
"\n"
"QPushButton:checked {\n"
"    background-color: #E0E0E0;\n"
"}", None))
        self.pushButton_2.setText(QCoreApplication.translate("MainWindow", u"     B\u1ea3ng \u0111i\u1ec1u khi\u1ec3n", None))
        self.pushButton_7.setText(QCoreApplication.translate("MainWindow", u"     Kho s\u00e1ch", None))
        self.pushButton_9.setText(QCoreApplication.translate("MainWindow", u"     \u0110\u1ed9c gi\u1ea3 ", None))
        self.pushButton_8.setText(QCoreApplication.translate("MainWindow", u"     M\u01b0\u1ee3n/Tr\u1ea3 s\u00e1ch", None))
        self.pushButton_10.setText(QCoreApplication.translate("MainWindow", u"     C\u1ed9ng \u0111\u1ed3ng", None))
        self.label_3.setText(QCoreApplication.translate("MainWindow", u"<html><head/><body><p align=\"center\"><span style=\" font-weight:400;\">UEL LIBRARY</span></p><p align=\"center\"><span style=\" font-weight:400;\"><br/></span></p></body></html>", None))
        self.pushButton.setText("")
        self.label_2.setText(QCoreApplication.translate("MainWindow", u"Welcome to your page.", None))
        self.label.setText(QCoreApplication.translate("MainWindow", u"<html><head/><body><p><span style=\" font-size:12pt;\">Hello, Everyone!</span></p></body></html>", None))
        self.textEdit.setHtml(QCoreApplication.translate("MainWindow", u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'MS Shell Dlg 2'; font-size:7.8pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:10pt; color:#6c6c6c;\">T\u1ed5ng s\u1ed1 s\u00e1ch</span></p></body></html>", None))
        self.textEdit_2.setHtml(QCoreApplication.translate("MainWindow", u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'MS Shell Dlg 2'; font-size:7.8pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:10pt; color:#6c6c6c;\">Sinh vi\u00ean \u0111\u0103ng k\u00ed</span></p></body></html>", None))
        self.textEdit_3.setHtml(QCoreApplication.translate("MainWindow", u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'MS Shell Dlg 2'; font-size:7.8pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:10pt; color:#6c6c6c;\">Qu\u00e1 h\u1ea1n</span></p></body></html>", None))
        self.textEdit_4.setHtml(QCoreApplication.translate("MainWindow", u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'MS Shell Dlg 2'; font-size:7.8pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:10pt; color:#6c6c6c;\">\u0110ang m\u01b0\u1ee3n</span></p></body></html>", None))
        self.label_20.setText("")
        self.label_21.setText(QCoreApplication.translate("MainWindow", u"<html><head/><body><p><span style=\" font-size:10pt; color:#6c6c6c;\">Ch\u00e0o m\u1eebng b\u1ea1n tr\u1edf l\u1ea1i, \u0111\u00e2y l\u00e0 nh\u1eefng g\u00ec \u0111ang di\u1ec5n ra h\u00f4m nay!</span></p><p><span style=\" font-size:10pt; color:#6c6c6c;\"><br/></span></p></body></html>", None))
        self.label_22.setText(QCoreApplication.translate("MainWindow", u"<html><head/><body><p><span style=\" font-size:16pt;\">T\u1ed5ng quan h\u1ec7 th\u1ed1ng</span></p></body></html>", None))
        self.label_6.setText("")
        self.label_24.setText("")
        self.label_25.setText("")
        self.label_23.setText("")
        self.groupBox.setTitle("")
        self.label_26.setText(QCoreApplication.translate("MainWindow", u"<html><head/><body><p><span style=\" font-size:11pt; color:#6c6c6c;\">Qu\u1ea3n l\u00fd v\u00e0 c\u1eadp nh\u1eadt danh m\u1ee5c s\u00e1ch trong h\u1ec7 th\u1ed1ng.</span></p></body></html>", None))
        self.label_7.setText(QCoreApplication.translate("MainWindow", u"<html><head/><body><p><span style=\" font-size:14pt; font-weight:600;\">Kho t\u00e0i li\u1ec7u tri th\u1ee9c </span></p></body></html>", None))
        self.btn_muonsach.setText(QCoreApplication.translate("MainWindow", u"M\u01b0\u1ee3n s\u00e1ch", None))
        self.lineEdit_2.setPlaceholderText(QCoreApplication.translate("MainWindow", u"T\u00ecm ki\u1ebfm theo ti\u00eau \u0111\u1ec1, t\u00e1c gi\u1ea3,...", None))
        self.xuat_excel_2.setText(QCoreApplication.translate("MainWindow", u"Xu\u1ea5t Excel", None))
        self.lineEdit.setPlaceholderText(QCoreApplication.translate("MainWindow", u"T\u00ecm theo m\u00e3 \u0111\u1ed9c gi\u1ea3 ho\u1eb7c t\u00ean...", None))
        self.xuat_excel.setText(QCoreApplication.translate("MainWindow", u"Xu\u1ea5t Excel", None))
        self.filter.setText(QCoreApplication.translate("MainWindow", u"B\u1ed9 l\u1ecdc", None))
        ___qtablewidgetitem = self.tableReaders.horizontalHeaderItem(0)
        ___qtablewidgetitem.setText(QCoreApplication.translate("MainWindow", u"H\u1ecd t\u00ean", None));
        ___qtablewidgetitem1 = self.tableReaders.horizontalHeaderItem(1)
        ___qtablewidgetitem1.setText(QCoreApplication.translate("MainWindow", u"M\u00e3", None));
        ___qtablewidgetitem2 = self.tableReaders.horizontalHeaderItem(2)
        ___qtablewidgetitem2.setText(QCoreApplication.translate("MainWindow", u"Email", None));
        ___qtablewidgetitem3 = self.tableReaders.horizontalHeaderItem(3)
        ___qtablewidgetitem3.setText(QCoreApplication.translate("MainWindow", u"Ng\u00e0y \u0111\u0103ng k\u00fd", None));
        ___qtablewidgetitem4 = self.tableReaders.horizontalHeaderItem(4)
        ___qtablewidgetitem4.setText(QCoreApplication.translate("MainWindow", u"Tr\u1ea1ng th\u00e1i", None));
        self.label1.setText(QCoreApplication.translate("MainWindow", u"Hi\u1ec3n th\u1ecb 5 tr\u00ean 120 \u0111\u1ed9c gi\u1ea3", None))
        self.pageBtn.setText(QCoreApplication.translate("MainWindow", u"Tr\u01b0\u1edbc", None))
        self.pageActive.setText(QCoreApplication.translate("MainWindow", u"1", None))
        self.pageBtn1.setText(QCoreApplication.translate("MainWindow", u"Sau", None))
        self.boxTopReaders.setTitle(QCoreApplication.translate("MainWindow", u"TOP \u0110\u1ed8C GI\u1ea2", None))
        self.boxTopBooks.setTitle(QCoreApplication.translate("MainWindow", u"S\u00c1CH \u0110\u01af\u1ee2C M\u01af\u1ee2N NHI\u1ec0U", None))
        self.boxRecentActivity.setTitle(QCoreApplication.translate("MainWindow", u"HO\u1ea0T \u0110\u1ed8NG G\u1ea6N \u0110\u00c2Y", None))
        self.label2.setStyleSheet(QCoreApplication.translate("MainWindow", u"font-size:22px; font-weight:600;", None))
        self.label2.setText(QCoreApplication.translate("MainWindow", u"Danh s\u00e1ch \u0111\u1ed9c gi\u1ea3", None))
        self.label3.setStyleSheet(QCoreApplication.translate("MainWindow", u"color:gray;", None))
        self.label3.setText(QCoreApplication.translate("MainWindow", u"Qu\u1ea3n l\u00fd th\u00f4ng tin v\u00e0 tr\u1ea1ng th\u00e1i \u0111\u1ed9c gi\u1ea3", None))
        self.them_reader.setText(QCoreApplication.translate("MainWindow", u"+ Th\u00eam \u0111\u1ed9c gi\u1ea3", None))
        ___qtablewidgetitem5 = self.transferTable.horizontalHeaderItem(0)
        ___qtablewidgetitem5.setText(QCoreApplication.translate("MainWindow", u"id", None));
        ___qtablewidgetitem6 = self.transferTable.horizontalHeaderItem(1)
        ___qtablewidgetitem6.setText(QCoreApplication.translate("MainWindow", u"student_id", None));
        ___qtablewidgetitem7 = self.transferTable.horizontalHeaderItem(2)
        ___qtablewidgetitem7.setText(QCoreApplication.translate("MainWindow", u"book_id", None));
        ___qtablewidgetitem8 = self.transferTable.horizontalHeaderItem(3)
        ___qtablewidgetitem8.setText(QCoreApplication.translate("MainWindow", u"borrow_date", None));
        ___qtablewidgetitem9 = self.transferTable.horizontalHeaderItem(4)
        ___qtablewidgetitem9.setText(QCoreApplication.translate("MainWindow", u"due_date", None));
        ___qtablewidgetitem10 = self.transferTable.horizontalHeaderItem(5)
        ___qtablewidgetitem10.setText(QCoreApplication.translate("MainWindow", u"status", None));
        self.label_9.setText("")
        self.label_33.setText("")
        self.label_16.setText(QCoreApplication.translate("MainWindow", u"<html><head/><body><p><span style=\" color:#6cbbff;\">Overdue : 2</span></p></body></html>", None))
        self.label_11.setText("")
        self.label_14.setText(QCoreApplication.translate("MainWindow", u"<html><head/><body><p><span style=\" color:#a65170;\">Borrowing : 3</span></p></body></html>", None))
        self.label_13.setText("")
        self.label_17.setText(QCoreApplication.translate("MainWindow", u"<html><head/><body><p><span style=\" color:#60a4bf;\">Already returned : 3</span></p></body></html>", None))
        self.label_10.setText(QCoreApplication.translate("MainWindow", u"<html><head/><body><p><span style=\" font-size:14pt; font-weight:600;\">Kh\u00f4ng gian chia s\u1ebb s\u00e1ch c\u00e1 nh\u00e2n</span></p></body></html>", None))
        self.label_28.setText(QCoreApplication.translate("MainWindow", u"<html><head/><body><p><span style=\" font-size:10pt; font-style:italic;\">N\u01a1i sinh vi\u00ean c\u00f3 th\u1ec3 cho m\u01b0\u1ee3n v\u00e0 trao \u0111\u1ed5i s\u00e1ch c\u00e1 nh\u00e2n</span></p></body></html>", None))
        self.label_29.setText(QCoreApplication.translate("MainWindow", u"<html><head/><body><p><span style=\" font-size:12pt; font-weight:600;\">S\u00e1ch c\u1ed9ng \u0111\u1ed3ng m\u1edbi nh\u1ea5t</span></p></body></html>", None))
        self.btn_borrow.setText(QCoreApplication.translate("MainWindow", u"\u0110\u0103ng k\u00fd cho m\u01b0\u1ee3n s\u00e1ch", None))
        self.label_30.setText(QCoreApplication.translate("MainWindow", u"<html><head/><body><p><span style=\" font-size:10pt; font-weight:600;\">Lan t\u1ecfa tri th\u1ee9c</span></p></body></html>", None))
        self.label_31.setText(QCoreApplication.translate("MainWindow", u"<html><head/><body><p align=\"justify\">Chia s\u1ebb cu\u1ed1n s\u00e1ch t\u00e2m \u0111\u1eafc c\u1ee7a b\u1ea1n v\u1edbi <br/>c\u1ed9ng \u0111\u1ed3ng sinh vi\u00ean \u0111\u1ec3 c\u00f9ng nhau ph\u00e1t tri\u1ec3n.</p></body></html>", None))
        self.btn_share.setText(QCoreApplication.translate("MainWindow", u"B\u1eaft \u0111\u1ea7u chia s\u1ebb", None))
        self.label_4.setText("")
        self.lineEdit1.setPlaceholderText(QCoreApplication.translate("MainWindow", u"Search here....", None))
        self.label_5.setText(QCoreApplication.translate("MainWindow", u"Admin", None))
    # retranslateUi

