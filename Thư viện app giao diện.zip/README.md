
  # Thư viện app giao diện

  This is a code bundle for Thư viện app giao diện. The original project is available at https://www.figma.com/design/6SdQq0cmckKg5Yasoot3Gu/Th%C6%B0-vi%E1%BB%87n-app-giao-di%E1%BB%87n.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  