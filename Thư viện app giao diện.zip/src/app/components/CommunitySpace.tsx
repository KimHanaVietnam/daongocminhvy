import React from 'react';
import { Share2, Heart, MessageSquare, PlusCircle, User, ShieldCheck } from 'lucide-react';
import { motion } from 'motion/react';
import { ImageWithFallback } from './figma/ImageWithFallback';

const communityBooks = [
  { id: 1, title: 'Bí mật tư duy triệu phú', owner: 'Nguyễn Văn A', category: 'Phát triển bản thân', status: 'Available', cover: 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?q=80&w=1974&auto=format&fit=crop' },
  { id: 2, title: 'Đắc nhân tâm', owner: 'Trần Thị B', category: 'Kỹ năng sống', status: 'Requested', cover: 'https://images.unsplash.com/photo-1512820790803-83ca734da794?q=80&w=1974&auto=format&fit=crop' },
  { id: 3, title: 'Sapiens: Lược sử loài người', owner: 'Lê Văn C', category: 'Lịch sử', status: 'Available', cover: 'https://images.unsplash.com/photo-1532012197267-da84d127e765?q=80&w=1974&auto=format&fit=crop' },
];

export function CommunitySpace() {
  return (
    <div className="p-8 space-y-8 bg-blue-50/30 min-h-full">
      <div className="flex items-center justify-between">
        <div className="flex flex-col gap-1">
          <h2 className="text-2xl font-bold text-slate-900">Không gian chia sẻ sách cá nhân</h2>
          <p className="text-slate-500">Nơi sinh viên có thể cho mượn và trao đổi sách cá nhân.</p>
        </div>
        <button className="flex items-center gap-2 bg-blue-600 text-white px-5 py-2.5 rounded-xl font-medium hover:bg-blue-700 transition-colors shadow-sm">
          <PlusCircle size={20} />
          <span>Đăng ký cho mượn sách</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-6">
          <h3 className="text-lg font-bold text-slate-900">Sách cộng đồng mới nhất</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            {communityBooks.map((book, index) => (
              <motion.div 
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: index * 0.1 }}
                key={book.id} 
                className="bg-white rounded-2xl border border-blue-100 overflow-hidden shadow-sm hover:shadow-md transition-all flex h-48"
              >
                <div className="w-1/3 h-full">
                  <ImageWithFallback src={book.cover} alt={book.title} className="w-full h-full object-cover" />
                </div>
                <div className="w-2/3 p-4 flex flex-col justify-between">
                  <div>
                    <div className="flex items-center gap-1.5 mb-1">
                      <span className="text-[10px] font-bold text-blue-600 bg-blue-50 px-1.5 py-0.5 rounded uppercase">{book.category}</span>
                    </div>
                    <h4 className="font-bold text-slate-900 line-clamp-2 leading-snug">{book.title}</h4>
                    <div className="flex items-center gap-2 mt-2">
                      <div className="w-6 h-6 rounded-full bg-slate-100 flex items-center justify-center">
                        <User size={12} className="text-slate-500" />
                      </div>
                      <span className="text-xs text-slate-500">Chủ sách: <span className="font-semibold text-slate-700">{book.owner}</span></span>
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between mt-4">
                    <span className={`text-[10px] font-bold px-2 py-1 rounded-full ${
                      book.status === 'Available' ? 'bg-emerald-50 text-emerald-600' : 'bg-amber-50 text-amber-600'
                    }`}>
                      {book.status === 'Available' ? 'Sẵn sàng' : 'Đã được yêu cầu'}
                    </span>
                    <button className="text-xs font-bold text-blue-600 hover:underline">Mượn ngay</button>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        <div className="space-y-6">
          <h3 className="text-lg font-bold text-slate-900">Yêu cầu cần phê duyệt</h3>
          <div className="space-y-4">
            {[1, 2].map((i) => (
              <div key={i} className="bg-white p-4 rounded-2xl border border-blue-100 shadow-sm space-y-4">
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-full bg-blue-50 flex items-center justify-center text-blue-600 font-bold shrink-0">
                    SV
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-slate-900">Sinh viên Nguyễn Văn Nam</p>
                    <p className="text-xs text-slate-500">Muốn mượn: <span className="font-medium text-slate-700 italic">"Lược sử loài người"</span></p>
                    <p className="text-[10px] text-slate-400 mt-1">Gửi yêu cầu: 2 giờ trước</p>
                  </div>
                </div>
                <div className="flex gap-2">
                  <button className="flex-1 py-2 bg-blue-600 text-white text-xs font-bold rounded-lg hover:bg-blue-700 transition-colors flex items-center justify-center gap-1">
                    <ShieldCheck size={14} />
                    Phê duyệt
                  </button>
                  <button className="flex-1 py-2 bg-slate-100 text-slate-600 text-xs font-bold rounded-lg hover:bg-slate-200 transition-colors">
                    Từ chối
                  </button>
                </div>
              </div>
            ))}
          </div>

          <div className="bg-gradient-to-br from-blue-600 to-blue-800 p-6 rounded-2xl text-white shadow-lg shadow-blue-200">
            <Share2 size={32} className="mb-4 text-blue-200" />
            <h4 className="font-bold text-lg mb-2">Lan tỏa tri thức</h4>
            <p className="text-sm text-blue-100 leading-relaxed mb-4">Chia sẻ cuốn sách tâm đắc của bạn với cộng đồng sinh viên để cùng nhau phát triển.</p>
            <button className="w-full py-2.5 bg-white text-blue-600 rounded-xl font-bold text-sm hover:bg-blue-50 transition-colors">
              Bắt đầu chia sẻ
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
