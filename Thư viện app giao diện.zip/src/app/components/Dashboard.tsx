import React from 'react';
import { Book, Users, ClipboardList, Clock, TrendingUp } from 'lucide-react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  AreaChart, 
  Area 
} from 'recharts';
import { motion } from 'motion/react';

const data = [
  { name: 'Thứ 2', muon: 40, tra: 24 },
  { name: 'Thứ 3', muon: 30, tra: 13 },
  { name: 'Thứ 4', muon: 20, tra: 98 },
  { name: 'Thứ 5', muon: 27, tra: 39 },
  { name: 'Thứ 6', muon: 18, tra: 48 },
  { name: 'Thứ 7', muon: 23, tra: 38 },
  { name: 'CN', muon: 34, tra: 43 },
];

const stats = [
  { label: 'Tổng số sách', value: '12,450', icon: Book, color: 'bg-blue-500', trend: '+2.5%' },
  { label: 'Sinh viên đăng ký', value: '3,842', icon: Users, color: 'bg-emerald-500', trend: '+1.2%' },
  { label: 'Đang mượn', value: '458', icon: ClipboardList, color: 'bg-orange-500', trend: '-0.4%' },
  { label: 'Quá hạn', value: '24', icon: Clock, color: 'bg-red-500', trend: '+4.3%' },
];

export function Dashboard() {
  return (
    <div className="p-10 space-y-10 bg-white/50 min-h-full">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
          <h2 className="text-3xl font-black text-slate-900 tracking-tight">Chào buổi sáng, Alex!</h2>
          <p className="text-slate-500 font-medium mt-1">Hệ thống đang hoạt động ổn định. Dưới đây là báo cáo nhanh.</p>
        </div>
        <div className="flex gap-3">
          <button className="px-5 py-2.5 bg-white border border-slate-200 rounded-xl text-sm font-bold text-slate-600 hover:bg-slate-50 shadow-sm transition-all">
            Xuất báo cáo
          </button>
          <button className="px-5 py-2.5 bg-indigo-600 text-white rounded-xl text-sm font-bold hover:bg-indigo-700 shadow-lg shadow-indigo-100 transition-all">
            + Nhập sách mới
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            key={stat.label}
            className="group bg-white p-6 rounded-[2rem] border border-slate-100 shadow-sm hover:shadow-xl hover:shadow-indigo-50 transition-all duration-500 cursor-default relative overflow-hidden"
          >
            <div className="absolute -right-4 -top-4 size-24 bg-indigo-50 rounded-full group-hover:scale-150 transition-transform duration-700" />
            
            <div className="relative z-10">
              <div className={`size-12 rounded-2xl ${stat.color} text-white flex items-center justify-center mb-6 shadow-lg`}>
                <stat.icon size={22} />
              </div>
              <p className="text-sm font-bold text-slate-400 uppercase tracking-widest">{stat.label}</p>
              <div className="flex items-end gap-2 mt-1">
                <p className="text-3xl font-black text-slate-900">{stat.value}</p>
                <span className="text-emerald-500 text-xs font-bold mb-1">{stat.trend}</span>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-sm">
          <div className="flex items-center justify-between mb-8">
            <h3 className="text-lg font-bold text-slate-900">Lưu lượng mượn sách tuần này</h3>
            <select className="bg-slate-50 border-none rounded-lg text-xs font-bold text-slate-500 p-2 outline-none">
              <option>7 ngày qua</option>
              <option>30 ngày qua</option>
            </select>
          </div>
          <div className="h-[320px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={data}>
                <defs>
                  <linearGradient id="colorMuon" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#4f46e5" stopOpacity={0.15}/>
                    <stop offset="95%" stopColor="#4f46e5" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fill: '#94a3b8', fontSize: 12, fontWeight: 600 }} />
                <YAxis axisLine={false} tickLine={false} tick={{ fill: '#94a3b8', fontSize: 12, fontWeight: 600 }} />
                <Tooltip 
                  contentStyle={{ borderRadius: '20px', border: 'none', boxShadow: '0 20px 25px -5px rgb(0 0 0 / 0.1)', padding: '12px' }}
                />
                <Area 
                  type="monotone" 
                  dataKey="muon" 
                  stroke="#4f46e5" 
                  strokeWidth={4} 
                  fillOpacity={1} 
                  fill="url(#colorMuon)" 
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-slate-900 p-8 rounded-[2.5rem] text-white relative overflow-hidden">
          <div className="absolute top-0 right-0 size-40 bg-indigo-500/20 rounded-full blur-3xl" />
          <h3 className="text-lg font-bold mb-6 relative z-10">Yêu cầu mượn mới</h3>
          <div className="space-y-5 relative z-10">
            {[1, 2, 3].map(i => (
              <div key={i} className="flex items-center gap-4 group">
                <div className="size-10 rounded-full bg-white/10 flex items-center justify-center font-bold text-xs">SV</div>
                <div className="flex-1">
                  <p className="text-sm font-bold group-hover:text-indigo-300 transition-colors">Nguyễn Văn {i === 1 ? 'A' : i === 2 ? 'B' : 'C'}</p>
                  <p className="text-[11px] text-white/40">Yêu cầu: Harry Potter vol.{i}</p>
                </div>
                <button className="size-8 rounded-lg bg-indigo-600 flex items-center justify-center hover:bg-indigo-500 transition-colors">
                  <TrendingUp size={14} className="rotate-90" />
                </button>
              </div>
            ))}
          </div>
          <button className="w-full mt-8 py-3 bg-white/10 hover:bg-white/20 rounded-xl text-xs font-bold transition-all">
            Xem tất cả thông báo
          </button>
        </div>
      </div>
    </div>
  );
}
