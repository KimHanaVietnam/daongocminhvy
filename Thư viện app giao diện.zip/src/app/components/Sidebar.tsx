import React from 'react';
import { 
  LayoutDashboard, 
  BookOpen, 
  Users, 
  Calendar, 
  Share2, 
  LogOut,
  Library
} from 'lucide-react';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export function Sidebar({ activeTab, setActiveTab }: SidebarProps) {
  const menuItems = [
    { id: 'dashboard', icon: LayoutDashboard, label: 'Bảng điều khiển' },
    { id: 'catalog', icon: BookOpen, label: 'Kho tài liệu' },
    { id: 'students', icon: Users, label: 'Độc giả' },
    { id: 'loans', icon: Calendar, label: 'Giao dịch mượn' },
    { id: 'community', icon: Share2, label: 'Cộng đồng' },
  ];

  return (
    <aside className="w-72 bg-white border-r border-slate-200/60 flex flex-col h-screen sticky top-0 z-20">
      <div className="p-8 flex items-center gap-3">
        <div className="size-11 bg-indigo-600 rounded-xl flex items-center justify-center text-white shadow-lg shadow-indigo-200 ring-4 ring-indigo-50">
          <Library size={24} />
        </div>
        <div>
          <h1 className="font-extrabold text-slate-900 text-lg tracking-tight leading-none">Lumina</h1>
          <p className="text-[10px] font-bold text-indigo-500 uppercase tracking-[0.2em] mt-1">Library System</p>
        </div>
      </div>

      <nav className="flex-1 px-4 py-4 space-y-1">
        {menuItems.map((item) => {
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center gap-3.5 px-4 py-3.5 rounded-2xl transition-all duration-300 group ${
                isActive
                  ? 'bg-indigo-600 text-white shadow-xl shadow-indigo-100'
                  : 'text-slate-500 hover:bg-slate-50 hover:text-indigo-600'
              }`}
            >
              <item.icon size={20} className={isActive ? 'text-white' : 'text-slate-400 group-hover:text-indigo-500'} />
              <span className="font-semibold text-sm">{item.label}</span>
              {isActive && (
                <div className="ml-auto w-1.5 h-1.5 rounded-full bg-white/40" />
              )}
            </button>
          );
        })}
      </nav>

      <div className="p-6">
        <div className="bg-slate-50 rounded-2xl p-5 mb-4">
          <p className="text-xs font-bold text-slate-400 uppercase mb-2">Hạn ngạch bộ nhớ</p>
          <div className="h-1.5 w-full bg-slate-200 rounded-full overflow-hidden">
            <div className="h-full w-[65%] bg-indigo-500 rounded-full" />
          </div>
          <p className="text-[10px] text-slate-500 mt-2 font-medium">6.5 GB trên 10 GB đã dùng</p>
        </div>
        <button className="w-full flex items-center gap-3 px-4 py-3 rounded-2xl text-slate-500 hover:bg-red-50 hover:text-red-500 transition-all font-semibold text-sm group">
          <LogOut size={20} className="text-slate-400 group-hover:text-red-500" />
          <span>Đăng xuất</span>
        </button>
      </div>
    </aside>
  );
}
