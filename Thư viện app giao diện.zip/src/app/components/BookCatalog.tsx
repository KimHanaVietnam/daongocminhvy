import React, { useState } from 'react';
import { Search, Filter, Plus, Star, BookOpen, MoreVertical } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { motion } from 'motion/react';

const mockBooks = [
  { id: 1, title: "Lập trình React cơ bản", author: "Nguyễn Văn A", category: "Công nghệ", rating: 4.8, available: 12, total: 15, cover: "https://images.unsplash.com/photo-1633356122544-f134324a6cee?q=80&w=2070&auto=format&fit=crop" },
  { id: 2, title: "Tư duy thiết kế (Design Thinking)", author: "Trần Thị B", category: "Thiết kế", rating: 4.5, available: 5, total: 10, cover: "https://images.unsplash.com/photo-1586717791821-3f44a563eb4c?q=80&w=2070&auto=format&fit=crop" },
  { id: 3, title: "Kinh tế học vĩ mô", author: "Lê Văn C", category: "Kinh tế", rating: 4.2, available: 0, total: 8, cover: "https://images.unsplash.com/photo-1592487576049-361021c60f47?q=80&w=2070&auto=format&fit=crop" },
  { id: 4, title: "Dữ liệu lớn (Big Data)", author: "Phạm Văn D", category: "Công nghệ", rating: 4.9, available: 7, total: 7, cover: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?q=80&w=2070&auto=format&fit=crop" },
  { id: 5, title: "Tâm lý học hành vi", author: "Hoàng Thị E", category: "Xã hội", rating: 4.7, available: 3, total: 5, cover: "https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?q=80&w=2020&auto=format&fit=crop" },
  { id: 6, title: "Tiếng Anh chuyên ngành IT", author: "Vũ Văn F", category: "Ngoại ngữ", rating: 4.6, available: 20, total: 20, cover: "https://images.unsplash.com/photo-1456513080510-7bf3a84b82f8?q=80&w=1973&auto=format&fit=crop" },
];

export function BookCatalog() {
  const [searchTerm, setSearchTerm] = useState('');

  return (
    <div className="p-10 space-y-8 bg-white/50 min-h-full">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <h2 className="text-3xl font-black text-slate-900 tracking-tight">Kho tài liệu tri thức</h2>
          <p className="text-slate-500 font-medium mt-1">Quản lý và cập nhật danh mục sách trong hệ thống.</p>
        </div>
        <div className="flex gap-3">
          <button className="flex items-center gap-2 px-6 py-3 bg-indigo-50 text-indigo-600 rounded-2xl font-bold text-sm hover:bg-indigo-100 transition-all">
            <Filter size={18} />
            Bộ lọc nâng cao
          </button>
          <button className="flex items-center gap-2 px-6 py-3 bg-indigo-600 text-white rounded-2xl font-bold text-sm hover:bg-indigo-700 shadow-xl shadow-indigo-100 transition-all">
            <Plus size={20} />
            Thêm tài liệu mới
          </button>
        </div>
      </div>

      <div className="bg-white p-2 rounded-[2rem] border border-slate-100 shadow-sm flex items-center">
        <div className="flex-1 relative group">
          <Search className="absolute left-6 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-indigo-500 transition-colors" size={20} />
          <input 
            type="text" 
            placeholder="Tìm kiếm theo tiêu đề, tác giả, ISBN..." 
            className="w-full pl-16 pr-6 py-5 bg-transparent outline-none text-slate-700 font-medium"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </div>

      <div className="bg-white rounded-[2.5rem] border border-slate-100 shadow-sm overflow-hidden">
        <table className="w-full text-left">
          <thead>
            <tr className="bg-slate-50/50">
              <th className="px-8 py-6 text-[11px] font-black text-slate-400 uppercase tracking-[0.2em]">Thông tin sách</th>
              <th className="px-8 py-6 text-[11px] font-black text-slate-400 uppercase tracking-[0.2em]">Tác giả / Thể loại</th>
              <th className="px-8 py-6 text-[11px] font-black text-slate-400 uppercase tracking-[0.2em]">Trạng thái</th>
              <th className="px-8 py-6 text-[11px] font-black text-slate-400 uppercase tracking-[0.2em]">Số lượng</th>
              <th className="px-8 py-6"></th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-50">
            {mockBooks.map((book, index) => (
              <motion.tr 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
                key={book.id} 
                className="hover:bg-slate-50/50 transition-colors group"
              >
                <td className="px-8 py-5">
                  <div className="flex items-center gap-4">
                    <div className="size-14 rounded-xl overflow-hidden shadow-md group-hover:scale-110 transition-transform duration-500">
                      <ImageWithFallback src={book.cover} alt={book.title} className="w-full h-full object-cover" />
                    </div>
                    <div>
                      <p className="font-extrabold text-slate-900 group-hover:text-indigo-600 transition-colors">{book.title}</p>
                      <p className="text-xs font-bold text-slate-400 mt-0.5">BK-{book.id.toString().padStart(4, '0')}</p>
                    </div>
                  </div>
                </td>
                <td className="px-8 py-5">
                  <p className="text-sm font-bold text-slate-700">{book.author}</p>
                  <span className="text-[10px] font-black text-indigo-500 bg-indigo-50 px-2 py-0.5 rounded uppercase mt-1 inline-block">
                    {book.category}
                  </span>
                </td>
                <td className="px-8 py-5">
                  <div className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-[10px] font-black uppercase tracking-wider ${
                    book.available > 0 ? 'bg-emerald-50 text-emerald-600' : 'bg-rose-50 text-rose-600'
                  }`}>
                    <div className={`size-1.5 rounded-full ${book.available > 0 ? 'bg-emerald-500' : 'bg-rose-500'}`} />
                    {book.available > 0 ? 'Sẵn sàng' : 'Hết sách'}
                  </div>
                </td>
                <td className="px-8 py-5">
                  <div className="flex items-center gap-2">
                    <div className="flex-1 h-1.5 w-16 bg-slate-100 rounded-full overflow-hidden">
                      <div 
                        className={`h-full rounded-full ${book.available > 5 ? 'bg-indigo-500' : 'bg-orange-500'}`} 
                        style={{ width: `${(book.available / book.total) * 100}%` }} 
                      />
                    </div>
                    <span className="text-xs font-bold text-slate-600">{book.available}/{book.total}</span>
                  </div>
                </td>
                <td className="px-8 py-5 text-right">
                  <button className="p-2 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-xl transition-all">
                    <MoreVertical size={20} />
                  </button>
                </td>
              </motion.tr>
            ))}
          </tbody>
        </table>
        <div className="p-8 bg-slate-50/30 flex items-center justify-between">
          <p className="text-sm font-bold text-slate-400">Hiển thị 6 trên 1,240 tài liệu</p>
          <div className="flex items-center gap-2">
            {[1, 2, 3, '...', 12].map((p, i) => (
              <button 
                key={i}
                className={`size-9 flex items-center justify-center rounded-xl text-xs font-bold transition-all ${
                  p === 1 ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-100' : 'text-slate-500 hover:bg-white hover:shadow-sm'
                }`}
              >
                {p}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
