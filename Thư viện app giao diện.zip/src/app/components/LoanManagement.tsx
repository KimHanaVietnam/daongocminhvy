import React from 'react';
import { Clock, CheckCircle2, AlertCircle, Calendar, ArrowRight, User, BookOpen } from 'lucide-react';
import { motion } from 'motion/react';

const loans = [
  { id: 'L001', book: 'Lập trình React cơ bản', student: 'Nguyễn Văn Nam', loanDate: '01/02/2026', returnDate: '15/02/2026', status: 'In Progress' },
  { id: 'L002', book: 'Tư duy thiết kế', student: 'Trần Thị Thuỷ', loanDate: '28/01/2026', returnDate: '11/02/2026', status: 'In Progress' },
  { id: 'L003', book: 'Kinh tế học vĩ mô', student: 'Lê Minh Hiếu', loanDate: '15/01/2026', returnDate: '29/01/2026', status: 'Overdue' },
  { id: 'L004', book: 'Dữ liệu lớn', student: 'Phạm Hồng Nhung', loanDate: '05/02/2026', returnDate: '19/02/2026', status: 'In Progress' },
  { id: 'L005', book: 'Tâm lý học hành vi', student: 'Hoàng Quốc Bảo', loanDate: '10/01/2026', returnDate: '24/01/2026', status: 'Returned' },
];

export function LoanManagement() {
  return (
    <div className="p-8 space-y-8 bg-blue-50/30 min-h-full">
      <div className="flex flex-col gap-1">
        <h2 className="text-2xl font-bold text-slate-900">Quản lý mượn & trả sách</h2>
        <p className="text-slate-500">Theo dõi thời hạn và trạng thái mượn sách của sinh viên.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-2xl border border-blue-100 shadow-sm flex items-center gap-4">
          <div className="p-3 bg-amber-50 text-amber-600 rounded-xl">
            <Clock size={24} />
          </div>
          <div>
            <p className="text-sm font-medium text-slate-500">Đang mượn</p>
            <p className="text-xl font-bold text-slate-900">124 lượt</p>
          </div>
        </div>
        <div className="bg-white p-6 rounded-2xl border border-blue-100 shadow-sm flex items-center gap-4">
          <div className="p-3 bg-red-50 text-red-600 rounded-xl">
            <AlertCircle size={24} />
          </div>
          <div>
            <p className="text-sm font-medium text-slate-500">Quá hạn</p>
            <p className="text-xl font-bold text-slate-900">18 lượt</p>
          </div>
        </div>
        <div className="bg-white p-6 rounded-2xl border border-blue-100 shadow-sm flex items-center gap-4">
          <div className="p-3 bg-emerald-50 text-emerald-600 rounded-xl">
            <CheckCircle2 size={24} />
          </div>
          <div>
            <p className="text-sm font-medium text-slate-500">Đã trả (tháng này)</p>
            <p className="text-xl font-bold text-slate-900">342 lượt</p>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-blue-100 overflow-hidden">
        <div className="p-5 border-b border-blue-50 bg-slate-50/50">
          <h3 className="font-bold text-slate-900">Giao dịch gần đây</h3>
        </div>
        <div className="divide-y divide-slate-100">
          {loans.map((loan, index) => (
            <motion.div 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
              key={loan.id} 
              className="p-5 flex flex-col md:flex-row md:items-center justify-between gap-4 hover:bg-slate-50 transition-colors"
            >
              <div className="flex items-center gap-4 flex-1">
                <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center text-blue-600">
                  <BookOpen size={24} />
                </div>
                <div>
                  <h4 className="font-bold text-slate-900">{loan.book}</h4>
                  <div className="flex items-center gap-2 text-sm text-slate-500 mt-1">
                    <User size={14} />
                    <span>{loan.student}</span>
                  </div>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-8 md:gap-16">
                <div className="flex items-center gap-3">
                  <div className="text-right">
                    <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Ngày mượn</p>
                    <p className="text-sm font-semibold text-slate-700">{loan.loanDate}</p>
                  </div>
                  <ArrowRight size={16} className="text-slate-300" />
                  <div>
                    <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Hạn trả</p>
                    <p className="text-sm font-semibold text-slate-700">{loan.returnDate}</p>
                  </div>
                </div>

                <div className="min-w-[120px]">
                  <span className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold ${
                    loan.status === 'In Progress' ? 'bg-amber-50 text-amber-600' :
                    loan.status === 'Overdue' ? 'bg-red-50 text-red-600' :
                    'bg-emerald-50 text-emerald-600'
                  }`}>
                    {loan.status === 'In Progress' && <Clock size={14} />}
                    {loan.status === 'Overdue' && <AlertCircle size={14} />}
                    {loan.status === 'Returned' && <CheckCircle2 size={14} />}
                    {loan.status === 'In Progress' ? 'Đang mượn' :
                     loan.status === 'Overdue' ? 'Quá hạn' : 'Đã trả'}
                  </span>
                </div>

                <button className="text-sm font-bold text-blue-600 hover:text-blue-700 px-4 py-2 bg-blue-50 rounded-lg hover:bg-blue-100 transition-colors">
                  Chi tiết
                </button>
              </div>
            </motion.div>
          ))}
        </div>
        <div className="p-4 bg-slate-50/30 text-center">
          <button className="text-sm font-bold text-slate-500 hover:text-blue-600 transition-colors">
            Xem tất cả lịch sử giao dịch
          </button>
        </div>
      </div>
    </div>
  );
}
