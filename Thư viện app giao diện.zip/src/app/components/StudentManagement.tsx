import React from 'react';
import { Search, UserPlus, Mail, Phone, Calendar, ShieldCheck, MoreHorizontal } from 'lucide-react';
import { motion } from 'motion/react';

const students = [
  { id: 'SV001', name: 'Nguyễn Văn Nam', email: 'nam.nv@student.edu.vn', phone: '0987-123-456', joinDate: '12/10/2023', status: 'Active', major: 'CNTT' },
  { id: 'SV002', name: 'Trần Thị Thuỷ', email: 'thuy.tt@student.edu.vn', phone: '0912-456-789', joinDate: '05/09/2023', status: 'Active', major: 'Kinh tế' },
  { id: 'SV003', name: 'Lê Minh Hiếu', email: 'hieu.lm@student.edu.vn', phone: '0345-678-901', joinDate: '20/11/2023', status: 'Suspended', major: 'Thiết kế' },
  { id: 'SV004', name: 'Phạm Hồng Nhung', email: 'nhung.ph@student.edu.vn', phone: '0765-432-109', joinDate: '15/08/2023', status: 'Active', major: 'Ngôn ngữ Anh' },
  { id: 'SV005', name: 'Hoàng Quốc Bảo', email: 'bao.hq@student.edu.vn', phone: '0901-234-567', joinDate: '01/02/2024', status: 'Active', major: 'Luật' },
];

export function StudentManagement() {
  return (
    <div className="p-8 space-y-8 bg-blue-50/30 min-h-full">
      <div className="flex items-center justify-between">
        <div className="flex flex-col gap-1">
          <h2 className="text-2xl font-bold text-slate-900">Danh sách tài khoản sinh viên</h2>
          <p className="text-slate-500">Quản lý thông tin và quyền truy cập của sinh viên.</p>
        </div>
        <button className="flex items-center gap-2 bg-blue-600 text-white px-5 py-2.5 rounded-xl font-medium hover:bg-blue-700 transition-colors shadow-sm">
          <UserPlus size={20} />
          <span>Thêm sinh viên</span>
        </button>
      </div>

      <div className="bg-white rounded-2xl border border-blue-100 overflow-hidden shadow-sm">
        <div className="p-4 border-b border-blue-50 flex items-center justify-between gap-4">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
            <input 
              type="text" 
              placeholder="Tìm theo MSSV hoặc tên..." 
              className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-100 rounded-lg outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all"
            />
          </div>
          <div className="flex gap-2">
            <button className="px-4 py-2 text-sm font-medium text-slate-600 hover:bg-slate-50 rounded-lg transition-colors">Xuất Excel</button>
            <button className="px-4 py-2 text-sm font-medium text-slate-600 hover:bg-slate-50 rounded-lg transition-colors">Bộ lọc</button>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-slate-50/50 text-slate-500 text-xs font-bold uppercase tracking-wider">
                <th className="px-6 py-4">Sinh viên</th>
                <th className="px-6 py-4">MSSV</th>
                <th className="px-6 py-4">Khoa/Ngành</th>
                <th className="px-6 py-4">Ngày tham gia</th>
                <th className="px-6 py-4">Trạng thái</th>
                <th className="px-6 py-4 text-center">Hành động</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {students.map((student, index) => (
                <motion.tr 
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.05 }}
                  key={student.id} 
                  className="hover:bg-blue-50/20 transition-colors"
                >
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 font-bold text-xs">
                        {student.name.split(' ').pop()?.[0]}
                      </div>
                      <div>
                        <p className="font-semibold text-slate-900 text-sm">{student.name}</p>
                        <p className="text-xs text-slate-500">{student.email}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-sm text-slate-600 font-medium">{student.id}</td>
                  <td className="px-6 py-4 text-sm text-slate-600">{student.major}</td>
                  <td className="px-6 py-4 text-sm text-slate-600">{student.joinDate}</td>
                  <td className="px-6 py-4">
                    <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold ${
                      student.status === 'Active' ? 'bg-emerald-50 text-emerald-600' : 'bg-red-50 text-red-600'
                    }`}>
                      <span className={`w-1.5 h-1.5 rounded-full ${student.status === 'Active' ? 'bg-emerald-500' : 'bg-red-500'}`}></span>
                      {student.status === 'Active' ? 'Hoạt động' : 'Đình chỉ'}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-center">
                    <button className="p-2 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-all">
                      <MoreHorizontal size={18} />
                    </button>
                  </td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>
        
        <div className="p-4 border-t border-slate-100 flex items-center justify-between text-sm text-slate-500">
          <p>Hiển thị 5 trên 120 sinh viên</p>
          <div className="flex items-center gap-2">
            <button className="px-3 py-1 border border-slate-200 rounded-md hover:bg-slate-50 disabled:opacity-50">Trước</button>
            <button className="px-3 py-1 bg-blue-600 text-white rounded-md">1</button>
            <button className="px-3 py-1 border border-slate-200 rounded-md hover:bg-slate-50">2</button>
            <button className="px-3 py-1 border border-slate-200 rounded-md hover:bg-slate-50">Sau</button>
          </div>
        </div>
      </div>
    </div>
  );
}
