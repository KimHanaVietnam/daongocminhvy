import React, { useState } from 'react';
import { Sidebar } from './components/Sidebar';
import { Header } from './components/Header';
import { Dashboard } from './components/Dashboard';
import { BookCatalog } from './components/BookCatalog';
import { StudentManagement } from './components/StudentManagement';
import { LoanManagement } from './components/LoanManagement';
import { CommunitySpace } from './components/CommunitySpace';
import { Toaster } from 'sonner';
import { Library } from 'lucide-react';
import { motion } from 'motion/react';

export default function App() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const validateEmail = (email: string) => {
    return /\S+@\S+\.\S+/.test(email);
  };

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!validateEmail(email)) {
      setError('Vui lòng nhập đúng định dạng email (vd: abc@student.edu.vn)');
      return;
    }

    if (password.length < 6) {
      setError('Mật khẩu phải có ít nhất 6 ký tự');
      return;
    }

    setIsLoggedIn(true);
  };

  if (!isLoggedIn) {
    return (
      <div className="min-h-screen bg-[#0F172A] flex items-center justify-center p-6 relative overflow-hidden">
        {/* Background Decorative Elements */}
        <div className="absolute top-[-10%] right-[-10%] size-[500px] bg-indigo-600/20 rounded-full blur-[120px]" />
        <div className="absolute bottom-[-10%] left-[-10%] size-[500px] bg-violet-600/20 rounded-full blur-[120px]" />
        
        <div className="w-full max-w-[1100px] grid grid-cols-1 lg:grid-cols-2 bg-white/5 backdrop-blur-2xl border border-white/10 rounded-[2.5rem] overflow-hidden shadow-2xl relative z-10">
          {/* Left Side: Branding */}
          <div className="hidden lg:flex flex-col justify-between p-12 bg-gradient-to-br from-indigo-600 to-violet-700 text-white relative">
            <div className="absolute inset-0 opacity-10 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-white via-transparent to-transparent" />
            
            <div className="flex items-center gap-3 relative z-10">
              <div className="size-10 bg-white text-indigo-600 rounded-xl flex items-center justify-center shadow-lg">
                <Library size={24} />
              </div>
              <span className="text-xl font-black tracking-tighter uppercase">Lumina</span>
            </div>

            <div className="relative z-10">
              <h1 className="text-5xl font-black leading-tight tracking-tighter">Quản lý tri thức <br />theo cách hiện đại.</h1>
              <p className="mt-6 text-indigo-100 text-lg font-medium opacity-80 leading-relaxed max-w-sm">
                Nền tảng quản lý thư viện thông minh với trải nghiệm người dùng tối ưu.
              </p>
            </div>

            <div className="flex gap-8 relative z-10">
              <div>
                <p className="text-2xl font-black">12k+</p>
                <p className="text-[10px] font-bold uppercase tracking-widest text-indigo-200">Tài liệu</p>
              </div>
              <div>
                <p className="text-2xl font-black">4k+</p>
                <p className="text-[10px] font-bold uppercase tracking-widest text-indigo-200">Độc giả</p>
              </div>
            </div>
          </div>

          {/* Right Side: Form */}
          <div className="p-12 lg:p-16 flex flex-col justify-center bg-white">
            <div className="mb-10">
              <h2 className="text-3xl font-black text-slate-900 tracking-tight">Chào mừng trở lại</h2>
              <p className="text-slate-500 font-medium mt-2">Vui lòng đăng nhập để tiếp tục quản trị hệ thống.</p>
            </div>

            <form onSubmit={handleLogin} className="space-y-6">
              {error && (
                <motion.div 
                  initial={{ opacity: 0, x: -10 }} 
                  animate={{ opacity: 1, x: 0 }}
                  className="p-4 bg-rose-50 border border-rose-100 rounded-2xl text-rose-600 text-sm font-bold flex items-center gap-3"
                >
                  <div className="size-2 bg-rose-500 rounded-full animate-pulse" />
                  {error}
                </motion.div>
              )}

              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-400 uppercase tracking-widest ml-1">Tài khoản quản trị</label>
                <input 
                  type="text" 
                  className="w-full px-5 py-4 bg-slate-50 border border-slate-100 rounded-2xl outline-none focus:ring-4 focus:ring-indigo-50 focus:border-indigo-600 focus:bg-white transition-all text-slate-900 font-medium"
                  placeholder="admin@lumina.edu"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <div className="flex justify-between items-center ml-1">
                  <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">Mật khẩu</label>
                  <button type="button" className="text-xs font-bold text-indigo-600 hover:text-indigo-700">Quên mật khẩu?</button>
                </div>
                <input 
                  type="password" 
                  className="w-full px-5 py-4 bg-slate-50 border border-slate-100 rounded-2xl outline-none focus:ring-4 focus:ring-indigo-50 focus:border-indigo-600 focus:bg-white transition-all text-slate-900 font-medium"
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                />
              </div>

              <button 
                type="submit"
                className="w-full py-4 bg-indigo-600 text-white font-black rounded-2xl shadow-xl shadow-indigo-100 hover:bg-indigo-700 hover:shadow-indigo-200 active:scale-[0.98] transition-all text-lg mt-4"
              >
                Đăng nhập hệ thống
              </button>
            </form>

            <p className="mt-10 text-center text-sm text-slate-400 font-medium">
              Bạn gặp sự cố? <button className="text-indigo-600 font-bold hover:underline">Liên hệ kỹ thuật</button>
            </p>
          </div>
        </div>
      </div>
    );
  }

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return <Dashboard />;
      case 'catalog':
        return <BookCatalog />;
      case 'students':
        return <StudentManagement />;
      case 'loans':
        return <LoanManagement />;
      case 'community':
        return <CommunitySpace />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <div className="flex min-h-screen bg-slate-50 font-sans text-slate-900">
      <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} />
      
      <main className="flex-1 flex flex-col min-w-0 overflow-hidden">
        <Header />
        
        <div className="flex-1 overflow-y-auto scroll-smooth">
          {renderContent()}
        </div>
      </main>

      <Toaster position="top-right" closeButton richColors />
    </div>
  );
}
